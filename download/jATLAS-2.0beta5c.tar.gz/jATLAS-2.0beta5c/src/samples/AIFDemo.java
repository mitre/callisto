/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package samples;

import gov.nist.atlas.*;

import java.io.File;
import java.net.MalformedURLException;

/**
 * AIFDemo is a sample demo class which illustrates basic corpus loading and
 * IdentifiableATLASElement (except Corpus) retrieving.
 * The main method takes 2 parameters. The first one is the name of the AIF
 * file to load the corpus from, and the second one is the ID of the
 * IdentifiableATLASElement to retrieve.
 *
 * For example, to run the demo:
 * java AIFDemo /users/frodo/corpus.aif.xml region1
 *
 * @author Sylvain Pajot, Chris Laprun
 * @version $Revision: 1.6 $
 *
 */
public class AIFDemo {

  public static void main(String[] args) {

    if (args.length != 2) {
      System.err.println("Usage: java AIFDemo <AIF input file> <Id of the element to retrieve>");
      System.exit(-1);
    }

    String filename = new String(args[0]);
    String elementId = new String(args[1]);

    execute(filename, elementId);
  }

  private static void execute(String filename, String elementId) {
    /* Load the Corpus */
    Corpus c = null;
    try {
      c = CorporaManager.loadCorpus(new File(filename).toURL());
    } catch (MalformedURLException mue) {
      System.out.println(mue.getMessage());
    }

    /* First check that an ATLASElement with the given ID exists within the corpus */
    Id id = c.resolveIdFor(elementId);
    if (id == null)
      System.out.println("There is no element with the id '" + elementId + "' in file " + filename);

    /* If so, get the ATLASElement and prints it out */
    Analysis analysis = c.getAnalysisWithId(elementId);
    if (analysis != null)
      printElement(analysis);
    else {
      Anchor anchor = c.getAnchorWithId(elementId);
      if (anchor != null)
        printElement(anchor);
      else {
        Annotation annotation = c.getAnnotationWithId(elementId);
        if (annotation != null) {
          printElement(annotation);
        } else {
          Region region = c.getRegionWithId(elementId);
          if (region != null) {
            printElement(region);
          } else {
            Signal signal = c.getSignalWithId(elementId);
            if (signal != null) {
              printElement(signal);
            } else {
              /* Should never happen */
              System.err.println("Can't find the ATLASElement with the given ID");
            }
          }
        }
      }
    }
  }

  public static void printElement(ATLASElement element) {
    System.out.println(element.asAIFString());
    System.out.println("Parent: " + element.getParent());
    if (element instanceof ReusableATLASElement)
      System.out.println("Referents: " + ((ReusableATLASElement) element).getReferentElements());
  }

}
