/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.type.FeatureType;
import gov.nist.atlas.util.RoleIdentifiedFeature;
import gov.nist.atlas.util.RoleIdentifiedParameter;


/**
 * A class allowing the creation of structured content for Annotations.
 * Features define name-value pairs and can embed other Feature structures to
 * provide rich and complex ways to organize information in the context
 * of an Annotation.
 *
 * @version $Revision: 1.14 $
 * @author Christophe Laprun
 *
 * @see Parameter
 */
public interface Feature extends ATLASElement, FeaturesHolder, ParametersHolder {
  /**
   * <p>Initializes the content of subordinate elements to the specified
   * values. The specified parameters are
   * role-identified, this Feature's type is thus able to correctly assign
   * them to their proper subordinate. Some
   * validation is performed at this level since it is not possible to assign
   * an invalid ATLASElement to a given subordinate.</p>
   *
   * <p><strong>Notes:</strong></p> <ul>
   * <li>The final error mechanism hasn't been specified yet but this method
   * should be atomic: either all assignments are made or none.</li>
   * <li>The subordinates that are specified as arguments to this method are
   * element with FINITE cardinality.
   * Subordinates with undetermined cardinality are assigned using other,
   * appropriate methods.</li> </ul>
   *
   * @param features    the role-identified Features to be assigned
   * to this Feature, optional (pass <code>null</code> when not needed).
   * @param parameters the role-identified Parameters to be assigned
   * to this Feature, optional (pass <code>null</code> when not needed).
   *
   * @see gov.nist.atlas.util.RoleIdentifiedParameter
   * @see gov.nist.atlas.util.RoleIdentifiedFeature
   *
   * @deprecated Move to SPI
   */
  void initContainedElementsWith(RoleIdentifiedFeature[] features, RoleIdentifiedParameter[] parameters);

  /**
   * Returns this Feature's type as a FeatureType object.
   *
   * @return the FeatureType assigned to this Feature
   */
  FeatureType getFeatureType();

  /** @supplierCardinality 0..* */

  /*#Feature lnkFeature;*/

  /**
   * @supplierCardinality 0..*
   * @link aggregationByValue
   */

  /*#Parameter lnkParameter;*/
}

