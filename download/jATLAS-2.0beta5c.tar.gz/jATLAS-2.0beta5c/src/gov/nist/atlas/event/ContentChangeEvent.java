/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.event;

import java.util.EventObject;

/**
 * An event encapsulating information about a (potential) change on a
 * Parameter's subordinate set(s). Note that this event describes potential
 * changes as well as occured changes.
 *
 *
 * @version $Revision: 1.3 $
 * @author Nicolas Radde
 *
 * @see ContentChangeListener
 * @see ContentWillChangeListener
 * @see gov.nist.atlas.Parameter
 */
public class ContentChangeEvent extends EventObject {

  private Object newValue;
  private Object oldValue;

  /**
   * Creates a new ContentChangeEvent with the specified information.
   *
   * @param source the Object source of the event.
   * @param oldValue the current value of the source before the change
   * @param newValue the expected value of the source after the change
   */
  public ContentChangeEvent(Object source, Object oldValue, Object newValue) {
    super(source);
    this.oldValue = oldValue;
    this.newValue = newValue;
  }

  /**
   * Retrieves the value for the source object before change.
   *
   * @return the old value of the objet
   */
  public Object getOldValue() {
    return oldValue;
  }

  /**
   * Retrieves the expected new value for the source object after a potential
   * change. Note that if this event is used by a ContentWillChangeListener to
   * decide that the change is not allowed, this value change will actually
   * never occur.
   *
   * @return the expected new value of the objet
   */
  public Object getNewValue() {
    return newValue;
  }
}