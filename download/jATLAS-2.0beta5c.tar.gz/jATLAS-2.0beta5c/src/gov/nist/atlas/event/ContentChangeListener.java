/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.event;

import java.util.EventListener;

/**
 * <p>This interface defines the methods to implement to be able to be notified
 * <strong>after</strong> the subordinate set of a Validatable has changed.</p>
 *
 * <p>This ContentChangeListener can then be registered with the Validatable(s)
 * it is interested in monitoring and will then be notified after each
 * successful modification of the subordinate set(s) of the monitored
 * Validatable(s).</p>
 *
 * @version $Revision: 1.3 $
 * @author Nicolas Radde
 *
 * @see ContentChangeEvent
 * @see gov.nist.atlas.Validatable
 */
public interface ContentChangeListener extends EventListener {

  /**
   * This method is called whenever a change has happened on the subordinate set
   * of the monitored Validatable(s).
   *
   * @param event a ContentChangeEvent describing the change
   */
  public void contentChange(ContentChangeEvent event);
}