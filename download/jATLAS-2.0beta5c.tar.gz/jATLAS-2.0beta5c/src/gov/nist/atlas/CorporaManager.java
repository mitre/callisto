/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas;

import gov.nist.atlas.io.ATLASExport;
import gov.nist.atlas.io.ATLASImport;
import gov.nist.atlas.io.xml.AIFXMLExport;
import gov.nist.atlas.io.xml.AIFXMLImport;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.ATLASImplementationManager;
import gov.nist.atlas.util.ReferentManager;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


/**
 * CorporaManager is the class whose static methods are called to unload or
 * release corpora. It prevents from loading the same corpus into memory at
 * the same time.
 *
 * Note: do not use AIFXMLImport anymore, as it was intended in the previous
 * versions of jATLAS
 *
 * @version $Revision: 1.12 $
 * @author Sylvain Pajot, Chris Laprun
 */
public class CorporaManager {

  /**
   * Loads and registers the Corpus located at the given URL. Note that if such
   * a Corpus has already been loaded and registered, then it is not loaded
   * again. The Corpus is also fully loaded (as opposed to shallowly) and uses
   * the default ATLASImplementation.
   *
   `* @param url the URL that designates the corpus to load
   * @return the Corpus located at the given URL.
   */
  public static Corpus loadCorpus(URL url) {
    return loadCorpus(url, defaultImpl);
  }

  /**
   * Loads and registers the Corpus located at the given URL. Note that if such
   * a Corpus has already been loaded and registered, then it is not loaded
   * again. The Corpus is also fully loaded (as opposed to shallowly) and uses
   * the given ATLASImplementation.
   *
   * @param url the URL that designates the Corpus to load
   * @param implementation the ATLASImplementation to use for the Corpus
   * @return the Corpus located at the given URL.
   */
  public static Corpus loadCorpus(URL url, ATLASImplementation implementation) {
    return loadCorpus(url, new AIFXMLImport(url, implementation), false);
  }

  /**
   * Loads and registers the Corpus located at the specified URL, using the
   * specified import module. Note that if such a Corpus has already been loaded
   * and registered, then it is not loaded again. The corpus can be shallowly
   * loaded if needed.
   *
   * @param source the URL of the resource where the Corpus to be loaded is
   * @param importModule the ATLASImport implementation to use to load the
   *                     Corpus, if <code>null</code> the AIF importer is
   *                     used
   * @param shallowly <code>true</code> if the Corpus should be built shallowly,
   *                  <code>false</code> if the Corpus should be completely built
   * @return the Corpus located at the given URL
   *
   * @see gov.nist.atlas.io.ATLASImport#load(boolean)
   * @since 2.0 beta 5
   */
  public static Corpus loadCorpus(URL source, ATLASImport importModule, boolean shallowly) {
    Corpus corpus = (Corpus) corpora.get(source);
    if (corpus != null)
      return corpus; // Corpus is already loaded, return it!

    if (importModule == null)
      importModule = new AIFXMLImport(source, defaultImpl);

    corpus = importModule.load(shallowly);
    corpora.put(source, corpus);

    return corpus;
  }

  /**
   * Loads and registers the Corpus located at the URL specified by the given
   * String. Note that if such a Corpus has already been loaded and registered,
   * then it is not loaded again. The Corpus is also fully loaded (as opposed to
   * shallowly) and uses the given ATLASImplementation.
   *
   * @param urlAsString a String representing the URL where the Corpus to be
   *        loaded is located
   * @param implementation the ATLASImplementation to use for the Corpus
   * @return the Corpus located at the given URL.
   * @throws MalformedURLException If the String representing the URL where the
   *         Corpus is located is malformed
   */
  public static Corpus loadCorpus(String urlAsString, ATLASImplementation implementation) throws MalformedURLException {
    return loadCorpus(new URL(urlAsString), implementation);
  }

  /**
   * Loads and registers the Corpus located at the URL specified by the given
   * String. Note that if such a Corpus has already been loaded and registered,
   * then it is not loaded again. The Corpus is also fully loaded (as opposed to
   * shallowly) and uses the default ATLASImplementation.
   *
   * @param urlAsString a String representing the URL where the Corpus to be
   *        loaded is located
   * @return the Corpus located at the given URL.
   * @throws MalformedURLException If the String representing the URL where the
   *         Corpus is located is malformed
   */
  public static Corpus loadCorpus(String urlAsString) throws MalformedURLException {
    return loadCorpus(urlAsString, defaultImpl);
  }

  /**
   * Retrieves the previously registered Corpus located at the specified URL.
   *
   * @param urlAsString the location with which the Corpus to be retrieved has
   *        been registered
   * @return the Corpus registered with the given String or <code>null</code>
   *         if no Corpus has been registered with the specified String.
   */
  public static Corpus getRegisteredCorpusWith(String urlAsString) {
    try {
      return (Corpus) corpora.get(new URL(urlAsString));
    } catch (MalformedURLException e) {
      e.printStackTrace();
      return null;
    }
  }

  /**
   * Retrieves the previously registered Corpus located at the specified URL.
   *
   * @param url the location with which the Corpus to be retrieved has
   *        been registered
   * @return the Corpus registered with the given URL or <code>null</code>
   *         if no Corpus has been registered with the specified String.
   *
   * @since 2.0 beta 5
   */
  public static Corpus getRegisteredCorpusWith(URL url) {
    return (Corpus) corpora.get(url);
  }

  /**
   * Registers the given Corpus.
   *
   * @param corpus the Corpus to register
   */
  public static void registerCorpus(Corpus corpus) {
    if (corpus != null)
      corpora.put(corpus.getLocation(), corpus);
  }

  /**
   * Unregisters and destroys a given Corpus from the in-memory Corpora pool.
   *
   * @param corpus the Corpus to release
   */
  public static void releaseCorpus(Corpus corpus) {
    if (corpus == null)
      return; // FIX-ME: do something better probably!
    ReferentManager.releaseCorpus(corpus);
    corpora.remove(corpus.getLocation());
  }

  /**
   * Updates the location associated with the given Corpus to the given new
   * location. This is method needs to be called whenever a Corpus is saved.
   *
   * @param corpus the Corpus which location is to be updated
   * @param newLocation the new location for the Corpus
   */
  public static void updateLocationFor(Corpus corpus, URL newLocation) {
    if (corpus == null)
      return; // FIX-ME: do something better probably!
    URL oldLocation = corpus.getLocation();
    if (corpora.containsKey(oldLocation)) {
      corpora.remove(oldLocation);
      corpora.put(newLocation, corpus);
    }
  }

  /**
   * Saves the given Corpus to the given location.
   *
   * @param corpus the Corpus to save
   * @param location the location to save the corpus to
   */
  public static void saveCorpus(Corpus corpus, URL location) {
    saveCorpus(corpus, location, new AIFXMLExport(location));
  }

  /**
   * Saves the given Corpus to the given location.
   *
   * @param corpus the Corpus to save
   * @param location the location to save the corpus to
   * @param exportModule the ATLASExport to use, if <code>null</code> the AIF
   *                     exporter is used
   *
   * @since 2.0 beta 5
   */
  public static void saveCorpus(Corpus corpus, URL location,
                                ATLASExport exportModule) {
    updateLocationFor(corpus, location);
    if (exportModule == null)
      exportModule = new AIFXMLExport(location);
    exportModule.save(corpus);
  }

  /**
   * Loads the Corpus found at the specified source URL, using the specified
   * import module, and saves it to the specified destination URL, using the
   * specified export module, thus performing conversion of data found at the
   * source URL into the format specified by the export module.
   *
   * @param source the location of the input Corpus
   * @param destination the location where the converted Corpus should be saved,
   *                    if <code>null</code> the source corpus will be
   *                    over-written
   * @param importModule the import module able to handle data found at the
   *                     source URL, if <code>null</code> the AIF importer is
   *                     used
   * @param exportModule the export module able of exporting in the desired
   *                     output format, if <code>null</code> the AIF exporter is
   *                     used
   *
   * @since 2.0 beta 5
   */
  public static void convertCorpus(URL source, URL destination, ATLASImport importModule,
                                   ATLASExport exportModule) {
    Corpus corpus = loadCorpus(source, importModule, false);
    if (destination == null)
      destination = source;
    saveCorpus(corpus, destination, exportModule);
  }

  /**
   * Returns the registered Corpora that are in-memory at this time.
   *
   * @return a set containing the registered Corpora
   */
  public static Set getAllCorpora() {
    if (corpora.isEmpty())
      return Collections.EMPTY_SET;
    Set set = new HashSet(corpora.size());
    Iterator i = corpora.values().iterator();
    Corpus c;
    while (i.hasNext()) {
      c = (Corpus) i.next();
      set.add(c);
    }
    return set;
  }

  public static void main(String[] args) {
    switch (args.length) {
      case 0:
        System.out.println("Usage: CorporaManager source [destination] " +
            "[importModule] [exportModule] where:\n\t" +
            "- source: URL of source Corpus\n\t" +
            "- destination: URL where converted Corpus will be saved (optional)\n\t" +
            "- importModule: qualified class name for the import module to use (optional)\n\t" +
            "- exportModule: qualified class name for the export module to use (optional)");
        System.exit(-1);
      case 1:
        try {
          convertCorpus(new URL(args[0]), null, null, null);
        } catch (MalformedURLException e) {
          e.printStackTrace();
          System.exit(-1);
        }
      case 2:
        try {
          convertCorpus(new URL(args[0]), new URL(args[1]), null, null);
        } catch (MalformedURLException e) {
          e.printStackTrace();
          System.exit(-1);
        }
      case 3:
        try {
          URL source = new URL(args[0]);
          convertCorpus(source, new URL(args[1]),
              getImportModuleFrom(args[2], source), null);
        } catch (Exception e) {
          e.printStackTrace();
          System.exit(-1);
        }
      case 4:
        try {
          URL source = new URL(args[0]);
          URL destination = new URL(args[1]);
          convertCorpus(source, destination,
              getImportModuleFrom(args[2], source),
              getExportModuleFrom(args[3], destination));
        } catch (Exception e) {
          e.printStackTrace();
          System.exit(-1);
        }
    }
  }

  private static ATLASExport getExportModuleFrom(String className, URL destination) {
    ATLASExport exportModule = null;
    try {
      Class importModuleClass = Class.forName(className);
      exportModule = (ATLASExport) importModuleClass.newInstance();
      exportModule.setDestinationURL(destination);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return exportModule;
  }

  private static ATLASImport getImportModuleFrom(String className, URL source) {
    ATLASImport importModule = null;
    try {
      Class importModuleClass = Class.forName(className);
      importModule = (ATLASImport) importModuleClass.newInstance();
      importModule.setATLASImplementation(defaultImpl);
      importModule.setSourceURL(source);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return importModule;
  }

  private static Map corpora = new HashMap(); // FIX-ME: Corpora are currently registered with their URL: is that sufficient?
  private final static ATLASImplementation defaultImpl = ATLASImplementationManager.getDefaultImplementation();
}
