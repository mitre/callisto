/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.io.xml.AIFExportConstants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Provides type-safe constant for classes of ATLAS elements (Annotation,
 * Region, Anchor, etc...). For example, the class of Annotations is
 * represented by ATLASClass.ANNOTATION.
 *
 * @version $Revision: 1.23 $
 * @author Christophe Laprun
 */
final public class ATLASClass implements Comparable {
  /** ATLASClass representing Analysis elements. */
  public final static ATLASClass ANALYSIS = new ATLASClass(7, "Analysis", Analysis.class, AIFExportConstants.ANALYSIS);

  /** ATLASClass representing Anchor elements. */
  public final static ATLASClass ANCHOR = new ATLASClass(3, "Anchor", Anchor.class, AIFExportConstants.ANCHOR);

  /** ATLASClass representing Annotation elements. */
  public final static ATLASClass ANNOTATION = new ATLASClass(5, "Annotation", Annotation.class, AIFExportConstants.ANNOTATION);

  /** ATLASClass representing Children elements. */
  public final static ATLASClass CHILDREN = new ATLASClass(9, "Children", Children.class, AIFExportConstants.CHILDREN);

  /** ATLASClass representing Content elements. */
  public final static ATLASClass CONTENT = new ATLASClass(6, "Content", Content.class, AIFExportConstants.CONTENT);

  /** ATLASClass representing Corpus elements. */
  public final static ATLASClass CORPUS = new ATLASClass(9, "Corpus", Corpus.class, AIFExportConstants.CORPUS);

  /** ATLASClass representing Feature elements. */
  public final static ATLASClass FEATURE = new ATLASClass(9, "Feature", Feature.class, AIFExportConstants.FEATURE);

  /** ATLASClass representing Metadata elements. */
  public final static ATLASClass METADATA = new ATLASClass(1, "Metadata", Metadata.class, AIFExportConstants.METADATA);

  /** ATLASClass representing Parameter elements. */
  public final static ATLASClass PARAMETER = new ATLASClass(8, "Parameter", Parameter.class, AIFExportConstants.PARAMETER);

  /** ATLASClass representing Region elements. */
  public final static ATLASClass REGION = new ATLASClass(4, "Region", Region.class, AIFExportConstants.REGION);

  /** ATLASClass representing both SimpleSignal and SignalGroup elements. */
  public final static ATLASClass SIGNAL = new ATLASClass(2, "Signal", Signal.class, AIFExportConstants.SIGNAL);

  /**
   * <p>Compare this ATLASClass to another. The order that is defined on ATLASClass
   * is such that we try to respect the dependencies. This is used to ensure
   * by the AIF export module to ensure that elements are printed out
   * according to the order specified by the AIF DTD.</p>
   * <p>The order is specified so as to present the parser with the information
   * it needs in the order it needs it (as much as possible, at least).</p>
   * <p>In particular: <code>Anchor &lt; Region</code>.</p>
   */
  public int compareTo(Object other) {
    if (this == other)
      return 0;
    ATLASClass c = (ATLASClass) other;
    return ((hashCode - c.hashCode > 0) ? 1 : -1);
  }

  public final int hashCode() {
    return hashCode;
  }

  /**
   * <p>Returns the name of this ATLASClass.</p>
   * <p>For example, <code>ATLASClass.REGION.getName()</code> returns "Region".</p>
   */
  public final String getName() {
    return name;
  }

  public final String getAIFName() {
    return aifName;
  }

  public final String toString() {
    return CLASS + name;
  }

  /**
   * Returns a list containing the ATLASClasses of IdentifiableATLASElements,
   * in alphabetical order of their name.
   * @return a list containing the ATLASClasses of IdentifiableATLASElements
   *
   * @see IdentifiableATLASElement
   */
  public static List getIdentifiableClasses() {
    return Collections.unmodifiableList(identifiables);
  }

  /**
   * Returns a list containing the ATLASClasses of ReusableATLASElements, in
   * alphabetical order of their name.
   * @return a list containing the ATLASClasses of ReusableATLASElements
   *
   * @see ReusableATLASElement
   */
  public static List getReusableClasses() {
    return Collections.unmodifiableList(reusables);
  }

  /**
   * Determines if this ATLASClass represent IdentifiableATLASElements.
   * @return  <code>true</code> if ATLASElements member of this ATLASClass are
   * IdentifiableATLASElement, <code>false</code> otherwise.
   *
   * @see IdentifiableATLASElement
   */
  public final boolean isIdentifiable() {
    return identifiables.contains(this);
  }

  /**
   * Determines if this ATLASClass represent ReusableATLASElements.
   * @return  <code>true</code> if ATLASElements member of this ATLASClass are
   * ReusableATLASElements, <code>false</code> otherwise.
   *
   * @see ReusableATLASElement
   */
  public final boolean isReusable() {
    return reusables.contains(this);
  }

  /**
   * Returns the java interface associated with this ATLASClass.
   *
   * @return the java interface associated with this ATLASClass
   */
  public final Class getAssociatedClass() {
    return clazz;
  }

  /**
   * <p>Retrieves (if any) the ATLASClass associated with the specified ATLAS
   * interface (as a Class object).</p>
   * <p>Example: getATLASClassAssociatedWith(Region.class) would return
   * ATLASClass.REGION.</P>
   *
   * @param clazz the Class representing the interface associated with the
   *              ATLASClass to be retrieved
   * @return the ATLASClass associated with the specified Class
   * @throws IllegalArgumentException if no ATLASClass is associated with the
   * specified Class
   */
  public static ATLASClass getATLASClassAssociatedWith(Class clazz) {
    if (classToATLASClass.containsKey(clazz))
      return (ATLASClass) classToATLASClass.get(clazz);
    throw new IllegalArgumentException("No ATLASClass is associated with class: "
        + clazz.getName());
  }

  /**
   * Retrieves the ATLASClass associated with the specified name.
   *
   * @param name the name of the ATLASClass to be retrieved
   *
   * @return the ATLASCLass associated with the specified name
   * @throws IllegalArgumentException if no ATLASClass is associated with the
   * specified name
   *
   * @since 2.0 beta 5
   */
  public static ATLASClass forName(String name) {
    ATLASClass result = (ATLASClass) namesToATLASClass.get(name.toUpperCase());
    if (result != null)
      return result;
    throw new IllegalArgumentException("No ATLASClas is associated with name: "
        + name);
  }

  /**
   * Retrieves all the existing ATLASClasses.
   *
   * @return a List containing all the existing ATLASClasses
   * @since 2.0 Beta 6
   */
  public static List getAllATLASClasses() {
    return new ArrayList(namesToATLASClass.values());
  }

  /**
   * Private constructor. Should never be used, just there to prevent
   * default instantiation.
   */
  private ATLASClass() {
    this(-1, "", ATLASClass.class, "");
  }

  /**
   * Private constructor. Called only as part of the type-safe
   * constant pattern.
   * @param hash hash code assigned to this ATLASClass
   * @param name name assigned to this ATLASClass
   */
  private ATLASClass(int hash, String name, Class clazz, String aifName) {
    hashCode = hash;
    this.name = name;
    this.clazz = clazz;
    this.aifName = aifName;
  }

  /**
   * A Comparator to sort ATLASClasses alphabetically.
   *
   * @since 2.0 Beta 6
   */
  public static class AlphabeticalComparator implements Comparator {
    public int compare(Object o1, Object o2) {
      ATLASClass c1 = (ATLASClass) o1;
      ATLASClass c2 = (ATLASClass) o2;
      return c1.getName().compareTo(c2.getName());
    }
  }

  private final int hashCode;
  private final String name;
  private final String aifName;
  private final Class clazz;
  private final static String CLASS = "ATLASClass=";

  private final static List identifiables = new ArrayList(6);
  private final static List reusables = new ArrayList(4);
  private final static Map classToATLASClass = new HashMap(17);
  private final static Map namesToATLASClass = new HashMap(17);

  static {
    identifiables.add(ATLASClass.ANALYSIS);
    identifiables.add(ATLASClass.ANCHOR);
    identifiables.add(ATLASClass.ANNOTATION);
    identifiables.add(ATLASClass.CORPUS);
    identifiables.add(ATLASClass.REGION);
    identifiables.add(ATLASClass.SIGNAL);

    reusables.add(ATLASClass.ANCHOR);
    reusables.add(ATLASClass.ANNOTATION);
    reusables.add(ATLASClass.REGION);
    reusables.add(ATLASClass.SIGNAL);

    classToATLASClass.put(Analysis.class, ATLASClass.ANALYSIS);
    classToATLASClass.put(Anchor.class, ATLASClass.ANCHOR);
    classToATLASClass.put(Annotation.class, ATLASClass.ANNOTATION);
    classToATLASClass.put(Children.class, ATLASClass.CHILDREN);
    classToATLASClass.put(Content.class, ATLASClass.CONTENT);
    classToATLASClass.put(Corpus.class, ATLASClass.CORPUS);
    classToATLASClass.put(Feature.class, ATLASClass.FEATURE);
    classToATLASClass.put(Metadata.class, ATLASClass.METADATA);
    classToATLASClass.put(Parameter.class, ATLASClass.PARAMETER);
    classToATLASClass.put(Region.class, ATLASClass.REGION);
    classToATLASClass.put(Signal.class, ATLASClass.SIGNAL);

    namesToATLASClass.put("ANALYSIS", ATLASClass.ANALYSIS);
    namesToATLASClass.put("ANCHOR", ATLASClass.ANCHOR);
    namesToATLASClass.put("ANNOTATION", ATLASClass.ANNOTATION);
    namesToATLASClass.put("CHILDREN", ATLASClass.CHILDREN);
    namesToATLASClass.put("CONTENT", ATLASClass.CONTENT);
    namesToATLASClass.put("CORPUS", ATLASClass.CORPUS);
    namesToATLASClass.put("FEATURE", ATLASClass.FEATURE);
    namesToATLASClass.put("METADATA", ATLASClass.METADATA);
    namesToATLASClass.put("PARAMETER", ATLASClass.PARAMETER);
    namesToATLASClass.put("REGION", ATLASClass.REGION);
    namesToATLASClass.put("SIGNAL", ATLASClass.SIGNAL);
  }
}

