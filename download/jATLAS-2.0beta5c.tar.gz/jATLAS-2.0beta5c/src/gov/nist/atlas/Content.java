/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.type.ContentType;
import gov.nist.atlas.util.RoleIdentifiedFeature;
import gov.nist.atlas.util.RoleIdentifiedParameter;


/**
 * Content organizes the content of an Annotation and can be
 * defined as follows: <ol> <li>Basic Content can be defined via the use of
 * Parameter elements for atomic pieces of information.</li>
 * <li>Structured Content can be defined using Feature elements allowing the
 * definition of complex name/value hierarchies.</li>
 * <li>Part of the Content can be extracted from a Signal via the use of a
 * Region in that Signal. The corresponding Region is qualified as "aligned"
 * since the use of that mechanism is equivalent to aligning two signals. This
 * technique is especially useful when the aligned Content is to be found in a
 * text signal.</li> <li>A combination of the previous techniques can be used
 * to model complex annotation schemes.</li>
 * <li>Alternatively, Contents can be defined by referring to some of the
 * Children of the Annotation it is part of. Thus, in hierarchical annotation
 * schemes, the Content definition can be delegated to a lower level in the
 * hierarchy. For instance, the Content for a sentence Annotation can be
 * defined by the Content defined by the word children Annotations.</li> </ol>
 *
 * @version $Revision: 1.18 $
 * @author Christophe Laprun
 *
 * @see Annotation
 * @see Feature
 * @see Parameter
 * @see Children
 */
public interface Content extends ATLASElement, FeaturesHolder, ParametersHolder {
  /**
   * <p>Initializes the content of subordinates to the specified values. The
   * specified parameters are role-identified, this Content's type is thus
   * able to correctly assign them to their proper subordinate. Some
   * validation is performed at this level since it is not possible to assign
   * an invalid ATLASElement to a given subordinate.</p> <strong>Notes: <ul>
   * <li>The final error mechanism hasn't been specified yet but this method
   * should be atomic: either all assignments are made or none.</li>
   * <li>The subordinates that are specified as arguments to this method are
   * element with FINITE cardinality.
   * Subordinates with undetermined cardinality are assigned using other,
   * appropriate methods.</li> </ul> </strong>
   *
   * @param features    the role-identified Features to be assigned
   * to this Content, optional (pass <code>null</code> when not needed).
   * @param parameters the role-identified Parameters to be assigned
   * to this Content, optional (pass <code>null</code> when not needed).
   * @param alignedRegion the aligned Region associated with this Content,
   * optional (pass <code>null</code> when not needed).
   *
   * @see gov.nist.atlas.util.RoleIdentifiedParameter
   * @see gov.nist.atlas.util.RoleIdentifiedFeature
   * @see gov.nist.atlas.ref.RegionRef
   */
  void initContainedElementsWith(RegionRef alignedRegion, RoleIdentifiedParameter[] parameters, RoleIdentifiedFeature[] features);

  /**
   * Returns this Content's type as a ContentType object.
   *
   * @return the ContentType assigned to this Content
   */
  ContentType getContentType();

  /**
   * <p>Returns this Content's "aligned" Region. An "aligned" Region is used
   * when part of the Content of an Annotation can be extracted from a Signal.
   * In this case, the Annotation's Content references the area in the Signal
   * where some content is to be found using a Region.</p>
   *
   * <p>The "aligned" term comes from the fact that what is actually done in
   * such cases is an alignment between two Regions.</p>
   *
   * @return the aligned Region associated to this Content, or
   * <code>null</code> if no such Region exists
   */
  Region getAlignedRegion();

  /**
   * Sets this Content's aligned region.
   *
   * @param alignedRegion the new aligned Region
   * @return <code>true</code> if the new aligned Region was successfully set,
   *         <code>false</code> otherwise.
   *
   * @since 2.0 beta 4
   */
  boolean setAlignedRegion(Region alignedRegion);

  /**
   * @link aggregationByValue
   * @supplierCardinality 0..*
   */

  /*#Parameter lnkParameter;*/

  /**
   * @link aggregationByValue
   * @supplierCardinality 0..*
   */

  /*#Feature lnkFeature;*/

  /**
   * @label references
   * @supplierCardinality 0..1
   * @supplierRole alignedRegion
   */

  /*#Region lnkRegion;*/

  /**
   * @supplierCardinality 0..1
   * @label can be defined by
   */

  /*#AnnotationChildren lnkChildren;*/
}

