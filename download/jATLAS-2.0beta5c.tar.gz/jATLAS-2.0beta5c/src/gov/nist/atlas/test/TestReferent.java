/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.test;

import gov.nist.atlas.Anchor;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.CorporaManager;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Region;
import gov.nist.atlas.util.ReferentManager;

/**
 * TestReferent tests the ReferentManager class
 *
 * @author Sylvain Pajot
 */
public class TestReferent extends AbstractATLASTest {

  public TestReferent(String name) {
    super(name);
  }

  public void testGetReferentsFor() {
    Annotation ann = corpus.getAnnotationWithId(ANN1_ID);
    Anchor anc = corpus.getAnchorWithId(ANC_ID);
    assertTrue(ReferentManager.getReferentsFor(ann).size() == 1);
    assertTrue(ReferentManager.getReferentsFor(ann).contains(corpus.getAnnotationWithId(ANN2_ID)));
    assertTrue(ReferentManager.getReferentsFor(anc).size() == 2);
    assertTrue(ReferentManager.getReferentsFor(anc).contains(corpus.getRegionWithId(REG1_ID)));
    assertTrue(ReferentManager.getReferentsFor(anc).contains(corpus.getRegionWithId(REG2_ID)));
  }

  public void testRemoveReferentFrom() {
    Anchor anc = corpus.getAnchorWithId(ANC_ID);
    ReferentManager.removeReferentFrom(anc, corpus.getRegionWithId(REG2_ID));
    assertTrue(!ReferentManager.getReferentsFor(anc).contains(corpus.getRegionWithId(REG2_ID)));
  }

  public void testAddReferentTo() {
    Anchor anc = corpus.getAnchorWithId(ANC_ID);
    Region reg = corpus.getRegionWithId(REG3_ID);
    assertTrue(ReferentManager.getReferentsFor(anc).size() == 2);
    ReferentManager.addReferentTo(anc, reg);
    assertTrue(ReferentManager.getReferentsFor(anc).size() == 3);
    assertTrue(ReferentManager.getReferentsFor(anc).contains(corpus.getRegionWithId(REG1_ID)));
    assertTrue(ReferentManager.getReferentsFor(anc).contains(corpus.getRegionWithId(REG2_ID)));
    assertTrue(ReferentManager.getReferentsFor(anc).contains(corpus.getRegionWithId(REG3_ID)));

  }

  public void testGetParentFor() {
    Anchor anc = corpus.getAnchorWithId(ANC_ID);
    assertTrue(ReferentManager.getParentFor(anc) == corpus);
  }

  public void testReleaseCorpus() {
    ReferentManager.releaseCorpus(corpus);
    assertTrue(ReferentManager.getReferentsFor(corpus.getAnnotationWithId(ANN1_ID)).isEmpty());
    assertTrue(ReferentManager.getReferentsFor(corpus.getAnnotationWithId(ANN2_ID)).isEmpty());
    assertTrue(ReferentManager.getReferentsFor(corpus.getAnchorWithId(ANC_ID)).isEmpty());
    assertTrue(ReferentManager.getReferentsFor(corpus.getRegionWithId(REG1_ID)).isEmpty());
    assertTrue(ReferentManager.getReferentsFor(corpus.getRegionWithId(REG2_ID)).isEmpty());
    assertTrue(ReferentManager.getReferentsFor(corpus.getRegionWithId(REG3_ID)).isEmpty());
  }

  public void setUp() {
    super.setUp();
    corpus = loadCorpus(CORPUS_NAME);
  }

  public void tearDown() {
    super.tearDown();
    CorporaManager.releaseCorpus(corpus);
  }

  private Corpus corpus;

  private final static String CORPUS_NAME = "TestCorpus.aif.xml";
  private final static String ANN1_ID = "Ann1";
  private final static String ANN2_ID = "Ann6";
  private final static String ANC_ID = "Anc2";
  private final static String REG1_ID = "Reg1";
  private final static String REG2_ID = "Reg2";
  private final static String REG3_ID = "Reg3";
}