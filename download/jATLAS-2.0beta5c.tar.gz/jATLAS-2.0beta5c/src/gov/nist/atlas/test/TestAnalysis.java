/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.test;

import gov.nist.atlas.Analysis;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.CorporaManager;
import gov.nist.atlas.Corpus;

/**
 * TestAnalysis tests the Analysis interface
 *
 * @author Sylvain Pajot
 */
public class TestAnalysis extends AbstractATLASTest {

  public TestAnalysis(String name) {
    super(name);
  }

  public void setUp() {
    super.setUp();
    corpus = loadCorpus(CORPUS_NAME);
    analysis = corpus.getAnalysisWithId(ANALYSIS_ID);
  }

  public void testGetAnalysisType() {
    assertTrue(analysis.getAnalysisType().getName().equals(ANALYSIS_TYPE));
  }

  public void testGetAnnotationWithId() {
    Annotation annotation = analysis.getAnnotationWithId(ANNOTATION_ID);
    assertTrue(annotation != null);
  }

  public void tearDown() {
    super.tearDown();
    CorporaManager.releaseCorpus(corpus);
  }

  private Corpus corpus;
  private Analysis analysis;
  private final static String CORPUS_NAME = "TestCorpus.aif.xml";
  private final static String ANALYSIS_ID = "Ana1";
  private final static String ANALYSIS_TYPE = "sentences";
  private final static String ANNOTATION_ID = "Ann6";

}
