/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.test;


import gov.nist.atlas.Analysis;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.CorporaManager;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Region;
import gov.nist.atlas.ref.ATLASRef;
import gov.nist.atlas.ref.RegionRef;
import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * TestAnnotation tests the Annotation interface
 *
 * @author Sylvain Pajot
 */
public class TestAnnotation extends AbstractATLASTest {

  public TestAnnotation(String name) {
    super(name);
  }

  public void setUp() {
    super.setUp();
    corpus = loadCorpus(CORPUS_NAME);

    // Get a annotation to be able to init a new region
    Analysis analysis = corpus.getAnalysisWithId(ANALYSIS_ID);

    RegionRef region = ATLASRef.createRegionRef(
        "#" + REF_REGION_ID,
        corpus.getMAIAScheme().getRegionType("interval"),
        corpus,
        REF_REGION_ROLE
    );

    /*RegionRef alignedRegion = ATLASRef.createRegionRef(
            "#" + REF_ALIGNEDREGION_ID,
            corpus.getMAIAScheme().getRegionType("interval"),
            corpus,
            REF_ALIGNEDREGION_ROLE
    );
*/
    annotation = factory.createAnnotation(ANNOTATION_TYPE, analysis, region);
    /*Content content = annotation.getContent();
    content.setValueOfParameterWithRole(PARAMETER_VALUE, PARAMETER_ROLE);
    content.setAlignedRegion(alignedRegion);*/
  }

  public void testGetAnnotationType() {
    assertTrue(annotation.getAnnotationType().getName().equals(ANNOTATION_TYPE));
  }

  public void testGetRegion() {
    Region region = annotation.getRegion();
    assertTrue(region != null);
    assertTrue(region.getId().getAsString().equals(REF_REGION_ID));
  }

  public void testGetContent() {
    assertTrue(annotation.getContent() != null);
  }

  public static Test suite() {
    return new TestSuite(TestAnnotation.class);
  }

  public void tearDown() {
    super.tearDown();
    CorporaManager.releaseCorpus(corpus);
  }

  private Corpus corpus;
  private Annotation annotation;

  private final static String CORPUS_NAME = "TestCorpus.aif.xml";
  private final static String ANALYSIS_ID = "Ana2";
  private final static String ANNOTATION_TYPE = "word";
  private final static String REF_REGION_ID = "Reg2";
  private final static String REF_REGION_ROLE = "interval";
  private final static String REF_ALIGNEDREGION_ID = "reg3";
  private final static String REF_ALIGNEDREGION_ROLE = "headRegion";
  private final static String PARAMETER_TYPE = "string";
  private final static String PARAMETER_VALUE = "589";
  private final static String PARAMETER_ROLE = "string";

}
