/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.test;


import gov.nist.atlas.Anchor;
import gov.nist.atlas.CorporaManager;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Region;
import gov.nist.atlas.Signal;
import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * TestAnchor tests the Anchor interface
 *
 * @author Sylvain Pajot
 */
public class TestAnchor extends AbstractATLASTest {

  public TestAnchor(String name) {
    super(name);
  }

  public void setUp() {
    super.setUp();
    corpus = loadCorpus(CORPUS_NAME);
    // Get a region to be able to init a new anchor
    region = corpus.getRegionWithId(REGION_ID1);
    // Get a signal to be able to init a new anchor
    signal = corpus.getSignalWithId(SIGNAL_ID1);
    anchor = factory.createAnchor(ANCHOR_TYPE, corpus, signal);
  }


  /* Can't test initwith because we can't instantiate Ids */

  public void testGetAnchorType() {
    assertTrue(anchor.getAnchorType().getName().equals(ANCHOR_TYPE));
  }

  public void testGetSignal() {
    // Need to implement an equal method
    //assertTrue(anchor.getSignal() != null && signal == anchor.getSignal());
  }


  public static Test suite() {
    return new TestSuite(TestAnchor.class);
  }

  public void tearDown() {
    super.tearDown();
    CorporaManager.releaseCorpus(corpus);
  }

  private Corpus corpus;
  private Region region;
  private Anchor anchor;
  private Signal signal;

  private final static String CORPUS_NAME = "TestCorpus.aif.xml";
  private final static String ANCHOR_TYPE = "offset";
  private final static String REGION_ID1 = "Reg2";
  private final static String SIGNAL_ID1 = "Sig1";

}
