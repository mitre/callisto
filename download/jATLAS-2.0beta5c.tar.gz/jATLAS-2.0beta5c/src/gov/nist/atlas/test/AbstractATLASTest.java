/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.test;

import gov.nist.atlas.CorporaManager;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.util.ATLASElementFactory;
import gov.nist.atlas.util.ATLASImplementationManager;
import gov.nist.maia.MAIALoader;
import gov.nist.maia.MAIAScheme;
import junit.framework.TestCase;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * AbstractATLASTest serves as a base class for every ATLAS Test Class.
 * Inheriting from TestCase (JUnit framework), it sets up the common fixture
 * which is a corpus to work on, and each subclass of AbstractATLASTest
 * aims to test every method of a particular ATLASElement.
 *
 * To guarantee there is no interactions introducing conflicts from a test to
 * another, the corpus to work on is reloaded between each test by overriding
 * the setUp and tearDown methods.
 *
 * @author Sylvain Pajot, Nicolas Radde, Chris Laprun
 * @version $Revision: 1.13 $
 */
public abstract class AbstractATLASTest extends TestCase {

  public AbstractATLASTest(String name) {
    super(name);
  }

  public Corpus loadCorpus(String urlString) {
    Corpus corpus = null;
    URL url = null;
    try {
      url = new URL(urlString);
    } catch (MalformedURLException mue) {
      try {
        url = new File(urlString).toURL();
      } catch (MalformedURLException mue2) {
        fail("Cannot load Corpus from (" + urlString + ").");
      }
    }
    corpus = CorporaManager.loadCorpus(url);
    return corpus;
  }

  public MAIAScheme loadMAIADefinition(String fileName) {
    MAIALoader loader = new MAIALoader(ATLASImplementationManager.getDefaultImplementation());
    try {
      return loader.loadTypeDefinitionsFrom(new File(fileName).toURL());
    } catch (MalformedURLException e) {
      fail("Cannot load MAIA definition from (" + fileName + ").");
    }
    return null;
  }

  /**
   * Returns the default ATLASElementFactory
   * @return an ATLASElementFactory
   */
  public ATLASElementFactory getFactory() {
    return factory;
  }

  public void setUp() {
    factory = ATLASElementFactory.getFactoryFor(ATLASImplementationManager.getDefaultImplementation());
  }

  public void tearDown() {
  }

  protected ATLASElementFactory factory = null;
}
