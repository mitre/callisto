/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.test;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.Anchor;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.Children;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Id;
import gov.nist.atlas.Region;
import gov.nist.atlas.ref.ATLASRef;
import gov.nist.atlas.ref.AnchorRef;
import gov.nist.atlas.type.AnchorType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.maia.MAIAScheme;

/**
 * @author Chris Laprun
 * @version $Revision: 1.6 $
 */
public class ATLASElementTest extends AbstractATLASTest {
  public ATLASElementTest(String name) {
    super(name);
  }

  public void testGetATLASType() {
    assertEquals(scheme.getCorpusType(SIMPLE), corpus.getCorpusType());
    assertEquals(scheme.getRegionType(INTERVAL), interval.getRegionType());
  }

  public void testGetATLASClass() {
    assertSame(corpus.getATLASClass(), ATLASClass.CORPUS);
  }

  public void testGetDefiningCorpus() {
    assertSame(corpus.getDefiningCorpus(), corpus);
  }

  public void testGetParent() {
    assertNull(corpus.getParent());
    assertSame(interval.getParent(), corpus);
  }

  public void testSetSubordinateWithRole() {
    String start = "start";

    assertEquals(anc1, interval.getSubordinateWithRole(start));
    assertTrue(!interval.setSubordinateWithRole(anc1, start));
    assertTrue(interval.setSubordinateWithRole(anc2, start));
    assertEquals(interval.getSubordinateWithRole(start), anc2);
  }

  public void testGetSubordinateWithRole() {
    assertSame(interval, word.getSubordinateWithRole(INTERVAL));
    assertSame(word.getSubordinateWithRole(INTERVAL), word.getRegion());
  }

  public void testGetChildrenWithRole() {
    assertNotNull(children);
    assertEquals(children.getChildrenType(), scheme.getChildrenType("word"));
  }

  public void testGetSubordinateSet() {
    AnchorType anchorType = scheme.getAnchorType("offset");
    ATLASElementSet subordinateSet = corpus.getSubordinateSet(anchorType);
    assertNotNull(subordinateSet);
    assertEquals(subordinateSet.getComponentATLASType(), anchorType);
    assertTrue(subordinateSet.contains(anc1));
  }

  public void testAddToChildrenWithRole() {
    assertTrue(!sentence.addToChildrenWithRole(word, "words"));
    assertTrue(!children.addToSubordinateSet(word));
  }

  public void testRemoveFromChildrenWithRole() {
    assertTrue(sentence.removeFromChildrenWithRole(word, "words"));
    assertTrue(!children.getSubordinateSet(scheme.getAnnotationType("word")).contains(word));
  }

  public void testAddToSubordinateSet() {
    assertTrue(!corpus.addToSubordinateSet(interval));
    Region region = factory.createRegion("interval", corpus, null, null,
        new AnchorRef[]{ATLASRef.createAnchorRef(anc1, "start"),
                        ATLASRef.createAnchorRef(anc2, "end")});
    Id regionId = region.getId();
    corpus.addToSubordinateSet(region);
    assertEquals(region, corpus.getRegionWithId(regionId.getAsString()));
  }

  public void testRemoveFromSubordinateSet() {
    String intervalId = interval.getId().getAsString();
    assertTrue(corpus.removeFromSubordinateSet(interval));
    assertNull(corpus.getRegionWithId(intervalId));
  }

  public void setUp() {
    super.setUp();
    corpus = loadCorpus(TEST_CORPUS_FILE);
    scheme = loadMAIADefinition(TEST_MAIA_FILE);
    sentence = corpus.getAnnotationWithId(SENTENCE_ID);
    children = sentence.getChildrenWithRole("words");
    interval = corpus.getRegionWithId(INTERVAL_ID);
    word = corpus.getAnnotationWithId(WORD_ID);
    anc1 = corpus.getAnchorWithId("Anc1");
    anc2 = corpus.getAnchorWithId("Anc2");
  }

  private Corpus corpus;
  private MAIAScheme scheme;
  private Annotation sentence;
  private Children children;
  private Region interval;
  private Annotation word;
  private Anchor anc1;
  private Anchor anc2;


  private static final String TEST_CORPUS_FILE = "TestCorpus.aif.xml";
  private static final String TEST_MAIA_FILE = "TestCorpus.maia.xml";

  // types
  private static final String SIMPLE = "simple";
  private static final String INTERVAL = "interval";

  // ids
  private static final String SENTENCE_ID = "Ann6";
  private static final String INTERVAL_ID = "Reg1";
  private static final String WORD_ID = "Ann1";
}
