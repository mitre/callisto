/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import java.net.URL;


/**
 * <p>An abstraction for a source of annotatable data.
 * SimpleSignals provide such information as location or MIME type of the
 * signal being annotated.</p>
 *
 * <p>An ATLAS SimpleSignal is not necessarly mapped to a single
 * physical signal. A Signal as defined by ATLAS is a logical (as opposed to
 * physical) entity. It is therefore possible to create several ATLAS
 * SimpleSignals per physical signals (to isolate channels in a stereo file
 * for example). However, it is not possible to link an ATLAS SimpleSignal to
 * several physical signals since an ATLAS
 * SimpleSignal identifies a logical part of a physical signal (a channel for
 * example). An ATLAS SimpleSignal can thus reference either one part or the
 * entirety of a physical signal.</p>
 *
 * <p>Linking several physical SimpleSignals in a
 * single ATLAS-manageable entity is done via SignalGroups.</p>
 *
 * @version $Revision: 1.13 $
 * @author Christophe Laprun
 *
 * @see Signal
 * @see SignalGroup
 */
public interface SimpleSignal extends Signal {
  /**
   * Returns the physical location of this SimpleSignal.
   *
   * @return a URL representing the physical location of this SimpleSignal
   */
  URL getLocation();

  /**
   * Sets the physical location of this SimpleSignal.
   *
   * @param url a URL representing the physical location of this SimpleSignal
   *
   * @deprecated Move to SPI?
   */
  void setLocation(URL url);

  /**
   * Returns this SimpleSignal's encoding.
   *
   * @return this SimpleSignal's encoding
   *
   * @deprecated Move to SPI
   */
  String getEncoding();

  /**
   * Returns this SimpleSignal's track.
   *
   * @return this SimpleSignal's track
   */
  String getTrack();
}

