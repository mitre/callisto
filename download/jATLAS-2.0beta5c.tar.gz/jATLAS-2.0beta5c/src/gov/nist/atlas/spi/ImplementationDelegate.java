/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.spi;

import gov.nist.atlas.ATLASAccessException;
import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.MutableATLASElementSet;

import java.util.Map;

/**
 * FIX-ME: Needs clean-up!
 * @version $Revision: 1.5 $
 * @author Chris Laprun
 *
 * @since 2.0 beta 4
 */
public interface ImplementationDelegate {
  ATLASElementSet getAllChildrenWith(ATLASClass clazz);

  ATLASElementSet getAllChildrenWith(ATLASType type);

  boolean specificAddToChildrenWithRole(ATLASElement element, String role);

  boolean specificRemoveFromChildrenWithRole(ATLASElement element, String role);

  boolean specificSetSubordinateWithRole(ATLASElement element, String role);

  boolean isTypeValid(ATLASType type) throws IllegalArgumentException;

  ATLASElement getSubordinateWithRole(String role);

  ATLASImplementation getATLASImplementation();

  /**
   * @since 2.0 beta 5
   */
  public ATLASElementSet getAllSubordinatesFromSubordinateSetsWith(ATLASClass atlasClass);

  /**
   * <p>Returns an immutable Map containing the associations, for this
   * ATLASElement, between a role and a required child ATLASElement. The
   * returned Map records the association of a given role, as defined by this
   * ATLASElement's type, to the current value.</p>
   *
   * <p>Example:<br>
   * Let us consider a Region of type <code>interval</code> which is defined as
   * referencing two <code>offset</code> Anchors, one with the
   * <code>start</code> role and the other with the <code>end</code> role.</p>
   *
   * <p>We will then have for the resulting Map (assuming it is called
   * <code>map</code> and that the Anchor assigned to the <code>start</code>
   * (respectively <code>end</code>) role is <code>startAnchor</code>
   * (respectively <code>endAnchor</code>), the order for the results being
   * random):</p>
   * <code>
   * <ul>
   * <li>map.entrySet(): {"start"=startAnchor, "end"=endAnchor}</li>
   * <li>map.keySet(): {"start", "end"}</li>
   * <li>map.values(): {endAnchor, startAnchor}</li>
   * <li>startAnchor == (Anchor) map.get("start")</li>
   * <li>endAnchor == (Anchor) map.get("end")</li>
   * </ul>
   * </code>
   *
   * @return a Map containing the current role/required child associations for
   * this ATLASElement
   *
   * @since 2.0 beta 4
   */
  Map getRoleSubordinateAssociations();

  /**
   * <p>Returns an immutable Map containing the associations, for this
   * ATLASElement, between a role and a container for optional child
   * ATLASElements.</p>
   *
   * <p>Example:<br>
   * Let us consider a Region that contains
   * @return
   *
   * @since 2.0 beta 4
   */
  Map getTypeSubordinateSetsAssociations();

  boolean specificAddToSubordinate(ATLASElement subordinate) throws ATLASAccessException;

  boolean specificRemoveFromSubordinateSet(ATLASElement subordinate) throws ATLASAccessException;

  /**
   * <p>Returns the possibly empty ATLASElementSet containing the set of this
   * ATLASElement's optional subordinates with the specified type.</p>
   *
   * <p>Note that the return set only contains elements which are
   * <strong>not</strong> associated with a role.</p>
   *
   * @param containedSubordinateType the type of the elements contained in the
   *          subordinate set to retrieve
   *
   * @return the (possibly empty) ATLASElementSet containing the set of this
   *         ATLASElement's subordinate set containing elements with the specified
   *         ATLASType
   *
   * @since 2.0 beta 4
   */
  MutableATLASElementSet getSubordinateSet(ATLASType containedSubordinateType) throws ATLASAccessException;
}
