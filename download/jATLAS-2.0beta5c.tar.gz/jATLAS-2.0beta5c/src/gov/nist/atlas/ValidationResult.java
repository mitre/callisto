/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * ValidationResult encapsulates the results of a Validatable validation
 * process.
 *
 * @version $Revision: 1.11 $
 * @author Christophe Laprun
 *
 * @see Validatable
 */
public class ValidationResult {
  /** Default constructor. Package-visible to prevent direct instantiation. */
  ValidationResult() {
    errorMessages = Collections.EMPTY_LIST;
  }

  /**
   * Public constructor.
   *
   * @param success a boolean indicating the success of the validation
   * @param errorMessages a list of error messages associated to this
   * ValidationResult
   */
  public ValidationResult(boolean success, List errorMessages) {
    this.success = success;
    this.errorMessages = new ArrayList(errorMessages.size());
    this.errorMessages.addAll(errorMessages);
  }

  /**
   * Determines if the validation, which result this ValidationResult
   * encapsulates, was successful or not.
   *
   * @return <code>true</code> if the validation was successful,
   * <code>false</code> if the validation failed
   */
  public boolean wasValidationSucessful() {
    return success;
  }

  /**
   * Returns a list of the error messages associated with this
   * ValidationResult.
   *
   * @return a possibly empty list of error messages
   */
  public List getErrorMessages() {
    return errorMessages;
  }

  /**
   * Creates a new ValidationResult resulting of the merging of the specified
   * ValidationResults to consolidate them into a single one.
   *
   * @param results the array of ValidationResults to be consolidated
   * into a single one
   *
   * @return a new ValidationResult consolidating the specified
   * ValidationResults into a single one
   */
  public static ValidationResult merge(ValidationResult[] results) {
    if (results == null)
      return new ValidationResult();
    int length = results.length;
    List msgs = new ArrayList(length);
    boolean result = true;
    ValidationResult r = null;
    for (int i = 0; i < length; i++) {
      r = results[i];
      msgs.addAll(r.getErrorMessages());
      result |= r.wasValidationSucessful();
    }
    return new ValidationResult(result, msgs);
  }

  boolean success = false;
  List errorMessages;
}

