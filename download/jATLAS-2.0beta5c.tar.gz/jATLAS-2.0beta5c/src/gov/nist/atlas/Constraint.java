/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;


/**
 * <p>An abstraction for constraints that can be applied to ATLASTypes in the
 * context of a Corpus. Note that a given ATLASType can have a different set
 * of Constraints when used in different contexts.</p>
 *
 * <p>Not yet fully supported. Might be moved to the
 * gov.nist.atlas.type package.</p>
 *
 * @version $Revision: 1.9 $
 * @author Christophe Laprun
 *
 * @see gov.nist.atlas.type.ATLASType
 */
public interface Constraint {
  /**
   * Determines if the specified element is valid.
   *
   * @param element the Validatable element to be validated
   *
   * @return a ValidationResult object encapsulating the validation result
   *
   * @see ValidationResult
   */
  ValidationResult validate(Validatable element);

  /**
   * Returns the name of this Constraint.
   *
   * @return the name of this Constraint
   */
  String getName();
}

