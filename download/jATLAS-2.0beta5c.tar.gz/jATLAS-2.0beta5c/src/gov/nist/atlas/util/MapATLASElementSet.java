/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Id;
import gov.nist.atlas.IdentifiableATLASElement;
import gov.nist.atlas.type.ATLASType;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;


/**
 * An implementation of ATLASElementSet based on a Map, optimized for fast access
 * to elements via their Id.
 *
 *
 * @version $Revision: 1.15 $
 * @author Christophe Laprun, Sylvain Pajot
 *
 * @see java.util.Map
 */
public class MapATLASElementSet extends AbstractATLASElementSet implements ATLASElementSet, AccessById {

  /**
   * Constructs a new, empty MapATLASElementSet with a default guarding
   * ATLASType and capacity
   */
  public MapATLASElementSet(ATLASType type, int size) {
    this(type, size, null);
  }

  /**
   * Constructs a new, empty MapATLASElementSet with a default guarding
   * ATLASClass and capacity
   */
  public MapATLASElementSet(ATLASClass clazz, int size) {
    this(clazz, size, null);
  }

  public MapATLASElementSet(Object guard, int size, ATLASElementSetProperties properties) {
    super(guard, size, properties);
  }

  public void sort() {
    SortedMap sortedElements = new TreeMap(elements);
    elements = sortedElements;
  }

  public void sort(Comparator comparator) {
    SortedMap sortedElements = new TreeMap(comparator);
    sortedElements.putAll(elements);
    elements = sortedElements;
  }

  public Iterator iterator() {
    return elements.values().iterator();
  }

  public ATLASElement[] toArray() {
    return (ATLASElement[]) elements.values().toArray(new ATLASElement[elements.size()]);
  }

  public int size() {
    return elements.size();
  }

  public boolean isEmpty() {
    return elements.isEmpty();
  }

  public boolean contains(ATLASElement element) {
    if (!(element instanceof IdentifiableATLASElement))
      return false;
    return elements.containsKey(((IdentifiableATLASElement) element).getId());
  }

  public void clear() {
    elements.clear();
  }

  protected boolean isElementOK(ATLASElement element) {
    return super.isElementOK(element) && element instanceof IdentifiableATLASElement;
  }

  protected boolean specificAdd(ATLASElement element) {
    return elements.put(((IdentifiableATLASElement) element).getId(), element) == null;
  }

  protected boolean specificRemove(ATLASElement element) {
    return elements.remove(((IdentifiableATLASElement) element).getId()) == element;
  }

  public boolean contains(Id id) {
    return elements.containsKey(id);
  }

  public IdentifiableATLASElement get(Id id) {
    return (IdentifiableATLASElement) elements.get(id);
  }

  public Iterator iteratorOverIds() {
    return elements.keySet().iterator();
  }

  protected void initContainer(int size, ATLASElementSetProperties properties) {
    elements = new HashMap(size);
  }

  /** The Map containing the pair Id/IdentifiableATLASElement */
  protected Map elements;
}

