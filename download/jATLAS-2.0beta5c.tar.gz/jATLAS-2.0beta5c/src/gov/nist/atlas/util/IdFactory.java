/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import gov.nist.atlas.Id;
import gov.nist.atlas.type.ATLASType;

import java.util.HashMap;
import java.util.Map;


/**
 * IdFactory is a manager for Id creation and retrieval. This abstract
 * class handles Id storage and retrieval via its internal
 * repository. It needs to be extended to implement the Id creation methods,
 * thus allowing the subclasses to use their own templates regarding
 * Id creation.
 *
 * @version $Revision: 1.9 $
 * @author Christophe Laprun, Sylvain Pajot
 *
 * @deprecated Functionality might be moved to ATLASImplentation
 */
public abstract class IdFactory {
  /**
   * Gets the Id object from this factory's internal repository
   * for a given name
   *
   * @param stringId the Id as a string
   * @return the Id for the specified name
   */
  public final Id resolveIdFor(String stringId) {
    return (Id) ids.get(stringId);
  }

  /**
   * Returns a new Id for a given ATLASType.
   *
   * @param type The type to create the Id for
   * @return the new Id for the specified ATLASType
   */
  protected abstract Id createNewIdFor(ATLASType type);

  /**
   * Returns the Id corresponding to a given String. If such an Id exists
   * already, this method returns the existing Id.
   *
   * @param stringId the string from which to create the Id
   * @return the Id created (or retrieved) from the specified String
   */
  protected abstract Id createNewIdFor(String stringId);

  /**
   * Adds an Id to this factory's internal repository
   *
   * @param id The Id to add
   */
  protected final void addId(Id id) {
    ids.put(id.getAsString(), id);
  }


  /** The map which contains all the existing pair name/Id */
  private Map ids = new HashMap();
}

