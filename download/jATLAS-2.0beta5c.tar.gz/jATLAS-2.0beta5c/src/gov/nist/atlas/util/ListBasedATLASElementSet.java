/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import gov.nist.atlas.ATLASElement;

import java.util.ListIterator;


/**
 * ListBasedATLASElementSet is an ATLASElementSet based on a <CODE>List</CODE>.
 * <P>It is an ordered collection of ATLASElements which can be sorted (by
 * implementing the Comparable interface) and accessed by their integer index
 * (position in the list) or sequentially.
 * <BR>See {@link java.util.List} for further details.
 * <BR>Note that it is inspired from the java.util.List interface, but it does
 * not implement that interface. <P><B>Unlike the java.util.List,
 * ListBasedATLASElementSet does not allow duplicate ATLASElements</B>.
 *
 * @version $Revision: 1.10 $
 * @author Christophe Laprun, Sylvain Pajot
 * @see gov.nist.atlas.util.ATLASElementSet
 */
public interface ListBasedATLASElementSet extends ATLASElementSet {
  /**
   * Returns a list iterator of the elements in this ListBasedATLASElementSet
   * (in proper sequence).
   * @return a list iterator of the elements in this ListBasedATLASElementSet
   * (in proper sequence).
   */
  ListIterator listIterator();

  /**
   * Returns a list iterator of the elements in this list (in proper
   * sequence), starting at the specified position in this list.  The
   * specified index indicates the first element that would be returned by
   * an initial call to the <tt>next</tt> method.  An initial call to
   * the <tt>previous</tt> method would return the element with the
   * specified index minus one.
   * @param index index of first element to be returned from the
   * list iterator (by a call to the <tt>next</tt> method).
   * @return a list iterator of the elements in this list (in proper
   * sequence), starting at the specified position in this list.
   * @throws IndexOutOfBoundsException if the index is out of range (index
   * &lt; 0 || index &gt; size()).
   */
  ListIterator listIterator(int index);

  /**
   * Returns the element at the specified position in this list.
   *
   * @param index index of element to return.
   * @return the element at the specified position in this list.
   *
   * @throws IndexOutOfBoundsException if the index is out of range (index
   * &lt; 0 || index &gt;= size()).
   */
  ATLASElement get(int index);
}


