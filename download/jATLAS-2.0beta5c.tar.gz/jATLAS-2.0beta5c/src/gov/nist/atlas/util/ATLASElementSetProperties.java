/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * A set of properties passed to ATLASElementSetFactories to decide which
 * ATLASElementSet implementation to use.
 *
 * @author Chris Laprun
 * @version $Revision: 1.1 $
 *
 * @since 2.0 beta 5
 */
public class ATLASElementSetProperties {
  public final static String ACCESS_BY_ID = "accessById".intern();
  public final static String ACCESS_BY_INDEX = "accessByIndex".intern();
  public final static String HEAVY_COUNT_CHANGES = "heavyCountChanges".intern();
  public final static String HEAVY_REORDERINGS = "heavyReorderings".intern();

  public final static ATLASElementSetProperties SAME_AS_LINKED_LIST = new ATLASElementSetProperties();

  static {
    SAME_AS_LINKED_LIST.setBooleanProperty(ACCESS_BY_INDEX, true);
    SAME_AS_LINKED_LIST.setBooleanProperty(HEAVY_COUNT_CHANGES, true);
    SAME_AS_LINKED_LIST.setBooleanProperty(HEAVY_REORDERINGS, true);
  }

  public final static ATLASElementSetProperties SAME_AS_GROWABLE_ARRAY = new ATLASElementSetProperties();

  static {
    SAME_AS_GROWABLE_ARRAY.setBooleanProperty(ACCESS_BY_INDEX, true);
    SAME_AS_GROWABLE_ARRAY.setBooleanProperty(HEAVY_REORDERINGS, true);
  }

  public final static ATLASElementSetProperties FAST_ID_ACCESS_UNSORTABLE = new ATLASElementSetProperties();

  static {
    FAST_ID_ACCESS_UNSORTABLE.setBooleanProperty(ACCESS_BY_ID, true);
    FAST_ID_ACCESS_UNSORTABLE.setBooleanProperty(HEAVY_COUNT_CHANGES, true);
  }

  public final static ATLASElementSetProperties FAST_ID_ACCESS_SORTABLE = new ATLASElementSetProperties();

  static {
    FAST_ID_ACCESS_SORTABLE.setBooleanProperty(ACCESS_BY_ID, true);
    FAST_ID_ACCESS_SORTABLE.setBooleanProperty(HEAVY_COUNT_CHANGES, true);
    FAST_ID_ACCESS_SORTABLE.setBooleanProperty(HEAVY_REORDERINGS, true);
  }

  public ATLASElementSetProperties() {
  }

  /**
   *
   * @param propertyName
   * @return
   */
  public boolean isBooleanPropertySet(String propertyName) {
    Object value = properties.get(propertyName);
    if (value instanceof Boolean)
      return ((Boolean) value).booleanValue();
    else
      return false;
  }

  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj instanceof ATLASElementSetProperties) {
      ATLASElementSetProperties properties = (ATLASElementSetProperties) obj;
      return properties.equals(properties.properties);
    }
    return false;
  }

  public void setBooleanProperty(String propertyName, boolean value) {
    if (propertyName != null && propertyName.length() != 0)
      properties.put(propertyName, (value ? Boolean.TRUE : Boolean.FALSE));
    else
      throw new IllegalArgumentException("A valid property name must be given");
  }

  public void setProperty(String propertyName, Object value) {
    if (propertyName != null && value != null)
      properties.put(propertyName, value);
    else
      throw new IllegalArgumentException("A valid name and value must be given");
  }

  public Object getProperty(String propertyName) {
    return properties.get(propertyName);
  }

  public Map getAllProperties() {
    return Collections.unmodifiableMap(properties);
  }

  private Map properties = new HashMap(7);
}


