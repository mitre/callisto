/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * <p>Manages known implementations of the API that are used by an ATLAS application.
 * It is possible to register, unregister and  retrieve ATLASImplementations.
 * Access to a default ATLASImplementation is also provided.</p>
 *
 * <P>ATLASImplementationManager is never instantiated and is only accessible
 * via its static methods (Singleton pattern).</p>
 *
 * @version $Revision: 1.14 $
 * @author Christophe Laprun, Sylvain Pajot
 * @see ATLASImplementation
 */
abstract public class ATLASImplementationManager {

  /**
   * Unregisters the ATLASImplementation with a given name.
   *
   * @param implementationName the name of the
   * ATLASImplementation to unregister
   *
   * @throws IllegalArgumentException if no implementation has been registered
   *         with this name
   */
  public static void unregisterImplementation(String implementationName) throws IllegalArgumentException {
    if (!implementations.containsKey(implementationName))
      throw new IllegalArgumentException("No implementation was registered with the '" + implementationName + "' name.");
    implementations.remove(implementationName);
  }

  /**
   * Registers the given ATLASImplementation with the given name.
   *
   * @param implementationName the name of the ATLASImplementation to register
   * @param implementation the ATLASImplementation to register
   *
   * @throws IllegalArgumentException if the specified ATLASImplementation has
   * already been registered or if one of the arguments is null
   */
  public static void registerImplementation(String implementationName, ATLASImplementation implementation) throws IllegalArgumentException {
    if (implementation == null || implementationName == null || implementationName.equals(""))
      throw new IllegalArgumentException("Valid name and implementation must be given!");

    if (implementations.containsKey(implementationName))
      throw new IllegalArgumentException("An implementation is already registered with the '" + implementationName + "' name.");

    implementations.put(implementationName, implementation);
  }


  /**
   * Gets the ATLASImplementation registered with the given name.
   *
   * @param name the name of the ATLASImplementation to retrieve
   * @return the ATLASImplementation for the specified name or <code>null</code>
   *         if no implementation has been registered with this name.
   */
  public static ATLASImplementation getImplementation(String name) {
    return (ATLASImplementation) implementations.get(name);
  }

  /**
   * Gets the default ATLASImplementation.
   *
   * @return the default ATLASImplementation
   */
  public static ATLASImplementation getDefaultImplementation() {
    if (defaultImplementation == null)
      defaultImplementation = getImplementation(DEFAULT);
    return defaultImplementation;
  }

  /**
   * Lists all the registered mappings (name, implementation) as a Set of
   * Map.Entry elements.
   *
   * @return a Set of Map.Entry representing the registered mappings
   *
   * @see java.util.Map.Entry
   */
  public static Set listAllImplementations() {
    return implementations.entrySet();
  }

  public final static String DEFAULT = "__default__";
  private static Map implementations = new HashMap(11);
  private static ATLASImplementation defaultImplementation;

  /* Need to force ATLASImplementationImpl class loading for static block to be executed... */
  static {
    try {
      Class.forName("gov.nist.atlas.impl.ATLASImplementationImpl");
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    }
  }
}

