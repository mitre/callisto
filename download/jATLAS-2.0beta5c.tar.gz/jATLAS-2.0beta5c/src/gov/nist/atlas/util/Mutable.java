/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import gov.nist.atlas.ATLASElement;

import java.util.Iterator;

/**
 * Interface specifying the behavior for classes which set of subordinates
 * can be modified.
 *
 * @author Christophe Laprun
 * @version $Revision: 1.5 $
 *
 * @since 2.0 beta 2
 */
public interface Mutable {
  /**
   * Adds the specified ATLASElement to this Mutable if it can be contained
   * in this Mutable. If the element cannot be contained or is already present,
   * it is not added.
   *
   * @param element the ATLASElement to add
   * @return <code>true</code> if the ATLASElement has been added,
   *         <code>false</code> if it is either already present in this Mutable
   *         or the operation is not allowed on this Mutable.
   */
  boolean add(ATLASElement element);

  /**
   * Adds the elements contained in the specified ATLASElementSet to this
   * Mutable if such an operation is allowed and/or possible. Before addition,
   * each ATLASElement of the given ATLASElementSet is checked to determine if
   * it can be contained in this Mutable and is only added if appropriate. If
   * any element proposed for addition cannot be contained or is already present,
   * the complete operation is aborted and this Mutable is left intact.
   *
   * @param elements an ATLASElementSet containing the elements to be added
   * @return <code>true</code> if the entire specified ATLASElementSet has been
   *         added, <code>false</code> if the operation was cancelled.
   */
  boolean addAll(ATLASElementSet elements);

  /**
   * Adds the elements iterated over by the specified Iterator to this
   * Mutable if such an operation is allowed and/or possible. Before addition,
   * each element of the given Iterator is checked to determine if
   * it can be contained in this Mutable and is only added if appropriate. If
   * any element proposed for addition cannot be contained or is already present,
   * the complete operation is aborted and this Mutable is left intact.
   *
   * @param elements an Iterator over the elements to be added
   * @param numberOfElements a hint over the number of elements to be added,
   *        that can be used by implementations to properly dimension containers
   * @return <code>true</code> if the entire specified ATLASElementSet has been
   *         added, <code>false</code> if the operation was cancelled.
   *
   * @since 2.0 beta 4
   */
  boolean addAll(Iterator elements, int numberOfElements);

  /**
   * Removes the specified ATLASElement to this Mutable if it can be removed
   * from this Mutable. If the element cannot be removed or is not present,
   * it is not removed.
   *
   * @param element the ATLASElement to remove
   * @return <code>true</code> if the ATLASElement has been removed,
   *         <code>false</code> if it is either absent from this Mutable
   *         or the operation is not allowed on this Mutable.
   */
  boolean remove(ATLASElement element);

  /**
   * Removes the elements contained in the specified ATLASElementSet from this
   * Mutable if such an operation is allowed and/or possible. Before removal,
   * each ATLASElement of the given ATLASElementSet is checked to determine if
   * it can be removed from this Mutable and is only removed if appropriate. If
   * any element proposed for removal cannot be removed or is absent from this
   * Mutable, the complete operation is aborted and this Mutable is left intact.
   *
   * @param elements an ATLASElementSet containing the elements to be removed
   * @return <code>true</code> if the entire specified ATLASElementSet has been
   *         removed, <code>false</code> if the operation was cancelled.
   */
  boolean removeAll(ATLASElementSet elements);

  /**
   * Removes all ATLASElements contained in this Mutable.
   */
  void clear();

  /**
   * Sets the name to use when this Mutable is printed as AIF (if possible).
   * This operation should only be called with precaution because it can create
   * problems with AIF if misused.
   *
   * @param name the name to use when this Mutable is printed to AIF
   *
   * @since 2.0 beta 4
   */
  void setAIFName(String name);
}
