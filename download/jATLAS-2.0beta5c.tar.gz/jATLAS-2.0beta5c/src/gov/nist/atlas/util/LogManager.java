/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Category;
import org.apache.log4j.Priority;

import java.util.HashMap;

/**
 * Manages logging in ATLAS. Might be replaced by aspects in a future revision.
 * See <a href='http://aspectj.org/'>http://aspectj.org</a> for more details.
 *
 * @version $Revision: 1.4 $
 * @author Christophe Laprun, Sylvain Pajot
 */
public class LogManager {

  private LogManager() {
    setVerboseLevel(WARNING);
  };

  private void registerCategory(Object category) {
    categories.put(category, Category.getInstance(category.getClass().getName()));
  }

  private boolean isRegisteredCategory(Object category) {
    if (!categories.containsKey(category) || categories.get(category) == null)
      return false;
    return true;
  }

  public static void log(Object category, int priority, Object message) {
    if (!instance.isRegisteredCategory(category))
      instance.registerCategory(category);
    Category c = (Category) instance.categories.get(category);
    c.log(Priority.toPriority(priority), message);
  }

  public static void setVerboseLevel(int vl) {
    if ((vl != DEBUG) && (vl != INFO) && (vl != WARNING) && (vl != ERROR) && (vl != FATAL))
      throw new IllegalArgumentException("Verbose level out of range");
    Category.getRoot().setPriority(Priority.toPriority(vl));
  }

  public final static int DEBUG = Priority.DEBUG_INT;
  public final static int INFO = Priority.INFO_INT;
  public final static int WARNING = Priority.WARN_INT;
  public final static int ERROR = Priority.ERROR_INT;
  public final static int FATAL = Priority.FATAL_INT;

  private static LogManager instance = new LogManager();

  static {
    BasicConfigurator.configure(); // must always been done for Log4J
  }

  private HashMap categories = new HashMap(17);

}