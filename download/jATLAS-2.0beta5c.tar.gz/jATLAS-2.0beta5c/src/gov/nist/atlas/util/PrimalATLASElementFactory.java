/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import gov.nist.atlas.*;
import gov.nist.atlas.impl.AnnotationInitializer;
import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.ref.SignalRef;
import gov.nist.atlas.type.*;

import java.net.URL;


/**
 * PrimalATLASElementFactory is the top level abstract class for ATLASElement
 * creation purposes. It provides all the methods needed to instantiate the
 * ATLASElement in their most basic form, as needed for some purposes (for
 * example AIF importing). It is also able to manage Id creation for its own
 * purpose, by delegating it to an IdFactory.
 *
 * @version $Revision: 1.31 $
 * @author Christophe Laprun, Sylvain Pajot
 */
abstract public class PrimalATLASElementFactory {
  protected PrimalATLASElementFactory(ATLASImplementation implementation) {
    this.implementation = implementation;
  }

  /**
   * Gets the ATLASImplementation to which this factory is attached`
   *
   * @return the ATLASImplementation to which this factory is attached
   */
  public final ATLASImplementation getImplementation() {
    return implementation;
  }

  /**
   * Resolves and returns the ATLASType object for a given pair of
   * ATLASClass/name in the context of the MAIAScheme associated with the given
   * Corpus.
   *
   * @param clazz the ATLASClass to which the ATLASType to get corresponds
   * @param strType the name of the ATLASType
   *
   * @return the ATLASType matching the specified pair ATLASClass/name
   */
  protected ATLASType resolveTypeFor(ATLASClass clazz, String strType, Corpus definingCorpus) {
    if (strType == null) // check that strType is a single word?
      throw new IllegalArgumentException(">" + strType + "< is not a valid type name.");
    ATLASType type = definingCorpus.getMAIAScheme().getATLASType(clazz, strType);
    if (type == null)
      throw new IllegalArgumentException("There is no " + clazz.getName() + " type named " + strType);
    return type;
  }

  /**
   * Resolves ans returns the Id object for a given name.
   *
   * @param stringId the Id as a string
   *
   * @return the Id for the specified name
   */
  public Id resolveIdFor(String stringId) {
    return implementation.resolveIdFor(stringId);
  }

  /**
   * <p>Resolves and returns the Unit object for a given name</p>
   *
   * <p><strong>NOT YET IMPLEMENTED.</strong></p>
   *
   * @param unitName the Unit as a string
   *
   * @return the Unit for the specified name
   */
  public Unit resolveUnitFor(String unitName) {
    return null;
  }


  /**
   * Returns a new Id for a given ATLASType. Should this method be public?
   *
   * @param type the type to create the Id for
   *
   * @return the new Id for the specified ATLASType
   */
  public final Id createNewIdFor(ATLASType type) {
    return implementation.createNewIdFor(type);
  }

  /**
   * Returns the Id corresponding to a given String. If such an Id already
   * exists, this method returns the existing Id. Should this method be public?
   *
   * @param stringId the string from which to create the Id
   *
   * @return the Id created (or retrieved) from the specified String
   */
  public final Id createNewIdFor(String stringId) {
    return implementation.createNewIdFor(stringId);
  }

  /**
   * Creates an empty Analysis from the only mandatory information. The
   * created Analysis does not contain any Annotation.
   *
   * @param type the type of the Analysis to create
   * @param parent the parent Corpus to define the analysis in
   * @param id the Id of the Analysis to create
   *
   * @return a new, empty Analysis with the mandatory specified information
   *
   * @see gov.nist.atlas.Analysis
   */
  public Analysis createEmptyAnalysis(ATLASType type, ATLASElement parent, Id id) {
    if (type instanceof AnalysisType) {
      Analysis analysis = parent.getDefiningCorpus().getAnalysisWithId(id.getAsString());
      if (analysis == null || !analysis.getATLASType().equals(type)) { // FIX-ME: this is a hack!!!
        analysis = implementation.newAnalysis(type, parent, id);
//        analysis.initWith((AnalysisType) type, parent, id);
      }
      return analysis;
    }
    throw new IllegalArgumentException("An invalid analysis type was given.");
  }

  /**
   * <p>Creates an empty Anchor from the only mandatory information. The
   * created Anchor does not contain any of the
   * Parameters it is supposed to, according to its type.</p>
   *
   * <p><strong>The Anchor thus created is not valid!</strong></p>
   *
   * @param type the type of the Anchor to create
   * @param parent the parent Region to add the anchor to
   * @param id the Id of the Anchor to create
   * @param signal the SignalRef to which the anchor refers
   *
   * @return a new, empty Anchor with the mandatory specified information
   *
   * @see gov.nist.atlas.Anchor
   */
  public Anchor createEmptyAnchor(ATLASType type, ATLASElement parent, Id id, SignalRef signal) {
    if (type instanceof AnchorType) {
      Anchor anchor = parent.getDefiningCorpus().getAnchorWithId(id.getAsString());
      if (anchor == null) {
        anchor = implementation.newAnchor(type, parent, id, signal);
//        anchor.initWith((AnchorType) type, parent, id, signal);
      }
      return anchor;
    }
    throw new IllegalArgumentException("An invalid anchor type was given.");
  }

  /**
   * <p>Creates an empty Annotation from the only mandatory information. The
   * created Annotation does not contain some of the
   * children elements (that is Content, Children) it is supposed to,
   * according to its type.</p>
   *
   * <p><strong>The Annotation thus created is not valid!</strong></p>
   *
   * @param type the type of the Annotation to create
   * @param parent the parent Analysis to define the annotation in
   * @param id the Id of the Annotation to create
   * @param region the RegionRef to which the annotation refers
   *
   * @return a new, empty Annotation with the mandatory specified information
   *
   * @see gov.nist.atlas.Annotation
   * @deprecated will be replaced by createPrimalAnnotation
   */
  public Annotation createEmptyAnnotation(ATLASType type, ATLASElement parent, Id id, RegionRef region) {
    return createPrimalAnnotation(type, parent, id, region);
  }

  /**
   * <p>Creates an empty Annotation from the only mandatory information. The
   * created Annotation does not contain some of the
   * children elements (that is Content, Children) it is supposed to,
   * according to its type.</p>
   *
   * <p><strong>The Annotation thus created is not valid!</strong></p>
   *
   * @param type the type of the Annotation to create
   * @param parent the parent Analysis to define the annotation in
   * @param id the Id of the Annotation to create
   * @param region the RegionRef to which the annotation refers
   *
   * @return a new, empty Annotation with the mandatory specified information
   *
   * @see gov.nist.atlas.Annotation
   */
  public Annotation createPrimalAnnotation(ATLASType type, ATLASElement parent, Id id, RegionRef region) {
    if (type instanceof AnnotationType) {
      Annotation annotation = parent.getDefiningCorpus().getAnnotationWithId(id.getAsString());
      if (annotation == null) {
        annotation = implementation.newAnnotation(type, parent, id, AnnotationInitializer.getInitializer(region));
//        annotation.initWith((AnnotationType) type, parent, id, region);
      }
      return annotation;
    }
    throw new IllegalArgumentException("An invalid annotation type was given.");
  }

  /**
   * <p>Creates an empty Annotation from the only mandatory information. The
   * created Annotation does not contain some of the
   * children elements (that is Content, Children) it is supposed to,
   * according to its type.</p>
   *
   * <p><strong>The Annotation thus created is not valid!</strong></p>
   *
   * @param type the type of the Annotation to create
   * @param parent the parent Analysis to define the annotation in
   * @param id the Id of the Annotation to create
   * @param regionDefiningAnnotations an ATLASElementSet containing the
   *        Region-defining subordinates for this Annotation
   * @param contentDefiningAnnotations an ATLASElementSet containing the
   *        Content-defining subordinates for this Annotation
   *
   * @return a new, empty Annotation with the mandatory specified information
   *
   * @see gov.nist.atlas.Annotation
   */
  public Annotation createPrimalAnnotation(ATLASType type, ATLASElement parent, Id id, ATLASElementSet regionDefiningAnnotations, ATLASElementSet contentDefiningAnnotations) {
    if (type instanceof AnnotationType) {
      Annotation annotation = parent.getDefiningCorpus().getAnnotationWithId(id.getAsString());
      if (annotation == null) {
        annotation = implementation.newAnnotation(type, parent, id, AnnotationInitializer.getInitializer(regionDefiningAnnotations, contentDefiningAnnotations));
//        annotation.initWith((AnnotationType) type, parent, id, regionDefiningAnnotations, contentDefiningAnnotations);
      }
      return annotation;
    }
    throw new IllegalArgumentException("An invalid annotation type was given.");
  }

  /**
   * <p>Creates an empty Annotation from the only mandatory information. The
   * created Annotation does not contain some of the
   * children elements (that is Content, Children) it is supposed to,
   * according to its type.</p>
   *
   * <p><strong>The Annotation thus created is not valid!</strong></p>
   *
   * @param type the type of the Annotation to create
   * @param parent the parent Analysis to define the annotation in
   * @param id the Id of the Annotation to create
   * @param regionDefiningAnnotations an ATLASElementSet containing the
   *        Region-defining subordinates for this Annotation
   *
   * @return a new, empty Annotation with the mandatory specified information
   *
   * @see gov.nist.atlas.Annotation
   * @since 2.0 beta 2
   */
  public Annotation createPrimalAnnotation(ATLASType type, ATLASElement parent, Id id, ATLASElementSet regionDefiningAnnotations) {
    if (type instanceof AnnotationType) {
      Annotation annotation = parent.getDefiningCorpus().getAnnotationWithId(id.getAsString());
      if (annotation == null) {
        annotation = implementation.newAnnotation(type, parent, id, AnnotationInitializer.getInitializer(regionDefiningAnnotations));
//        annotation.initWith((AnnotationType) type, parent, id, regionDefiningAnnotations);
      }
      return annotation;
    }
    throw new IllegalArgumentException("An invalid annotation type was given.");
  }

  /**
   *
   * @param type
   * @param parent
   * @return
   *
   * @since 2.0 beta 4
   */
  public Children createEmptyChildren(ATLASType type, ATLASElement parent) {
    if (type instanceof ChildrenType) {
      Children children = implementation.newChildren((ChildrenType) type, parent);
      return children;
    }
    throw new IllegalArgumentException("An invalid children type was given.");
  }

  /**
   * Creates an empty Content from the only mandatory information. The created
   * Content does not contain any of the
   * children elements (that is RegionRef, Parameter, Feature) it is supposed
   * to, according to its type.
   *
   * @param type the type of the Content to create
   * @param parent the parent Annotation to define the content in
   *
   * @return a new, empty Content with the mandatory specified information
   *
   * @see gov.nist.atlas.Content
   */
  public Content createEmptyContent(ATLASType type, ATLASElement parent) {
    if (type instanceof ContentType) {
      Content content = implementation.newContent(type, parent);
//      content.initWith((ContentType) type, parent);
      return content;
    }
    throw new IllegalArgumentException("An invalid content type was given.");
  }

  /**
   * Creates an empty Corpus from the only mandatory information. The created
   * Corpus does not contain any of the
   * children elements (that is Analysis, Region, Anchor, Signal) it is
   * supposed to, according to its type.
   *
   * @param type the type of the Corpus to create
   * @param id the Id of the Corpus to create
   * @param location the location of the Corpus as an URL
   *
   * @return An empty Corpus with the mandatory specified information
   *
   * @see gov.nist.atlas.Corpus
   */
  public Corpus createEmptyCorpus(ATLASType type, Id id, URL location) {
    if (type instanceof CorpusType) {
      Corpus corpus = implementation.newCorpus(type, id, location);
//      corpus.initWith((CorpusType) type, id, getImplementation(), location);
      CorporaManager.registerCorpus(corpus);
      return corpus;
    }
    throw new IllegalArgumentException("An invalid corpus type was given.");
  }

  /**
   * Creates an empty Feature from the only mandatory information. The created
   * Feature does not contain any of the
   * children elements (that is Feature, Parameter) it is supposed to,
   * according to its type.
   *
   * @param type the type of the Feature to create
   * @param parent the parent ATLASElement (that is Feature, Content) to
   * define the feature in
   *
   * @return a new, empty Feature with the mandatory specified information
   *
   * @see gov.nist.atlas.Feature
   */
  public Feature createEmptyFeature(ATLASType type, ATLASElement parent) {
    if (type instanceof FeatureType) {
      Feature feature = implementation.newFeature(type, parent);
//      feature.initWith((FeatureType) type, parent);
      return feature;
    }
    throw new IllegalArgumentException("An invalid feature type was given.");
  }

  /**
   * Creates a Parameter from given information.
   *
   * @param type the type of the Parameter to create
   * @param parent the parent ATLASElement (that is Anchor, Content, Feature)
   * to define the parameter in
   * @param unit the Unit of the Parameter to create
   *
   * @return a new, empty Parameter with the mandatory specified information
   *
   * @see gov.nist.atlas.Parameter
   */
  public Parameter createParameter(ATLASType type, ATLASElement parent, Unit unit, String value) {
    if (type instanceof ParameterType) {
      // needs more work: try to see if datatype library could be used
      Parameter parameter = implementation.newParameter(type, parent, unit, value);
//      parameter.initWith((ParameterType) type, parent, unit, value);
      return parameter;
    }
    throw new IllegalArgumentException("An invalid parameter type was given.");
  }

  /**
   * Creates an empty Metadata from the only mandatory information.
   *
   * @param type the type of the Metadata to create
   * @param parent the parent ATLASElement (that is Corpus, Analysis) to
   * define the metadata in
   *
   * @return a new, empty Metadata with the mandatory specified information
   *
   * @see gov.nist.atlas.Metadata
   */
  public Metadata createEmptyMetadata(ATLASType type, ATLASElement parent) {
    if (type instanceof MetadataType) {
      Metadata metadata = implementation.newMetadata(type, parent);
//      metadata.initWith((MetadataType) type, parent);
      return metadata;
    }
    throw new IllegalArgumentException("An invalid metadata type was given.");
  }

  /**
   * Creates an empty Region from the only mandatory information. The created
   * Region does not contain any of the
   * anchors it is supposed to, according to its type.
   *
   * @param type the type of the Region to create
   * @param parent the parent Corpus to define the region in
   * @param id the Id of the Region to create
   *
   * @return a new, empty Region with the mandatory specified information
   *
   * @see gov.nist.atlas.Region
   */
  public Region createEmptyRegion(ATLASType type, ATLASElement parent, Id id) {
    if (type instanceof RegionType) {
      Region region = parent.getDefiningCorpus().getRegionWithId(id.getAsString());
      if (region == null) {
        region = implementation.newRegion(type, parent, id);
//        region.initWith((RegionType) type, parent, id);
      }
      return region;
    }
    throw new IllegalArgumentException("An invalid region type was given.");
  }

  /**
   * Creates an SimpleSignal from given information.
   *
   * @param type the type of the SimpleSignal to create
   * @param parent the parent Corpus to define the region in
   * @param id the Id of the SimpleSignal to create
   * @param mimeClass the MIMEClass of the Signal to create
   * @param mimeType the MIME type of the Signal to create
   * @param encoding the encoding type of the Signal to create
   * @param track the track to which the SimpleSignal to create is related
   * @param url the URL locating the physical signal to which the SimpleSignal
   * to create is associated
   *
   * @return a new, empty SimpleSignal with the mandatory
   * specified information
   *
   * @see gov.nist.atlas.SimpleSignal
   */
  public SimpleSignal createSimpleSignal(ATLASType type, ATLASElement parent, Id id, MIMEClass mimeClass, String mimeType, String encoding, String track, URL url) {
    if (type instanceof SignalType) {
      Signal temp = parent.getDefiningCorpus().getSignalWithId(id.getAsString());
      if (temp != null && !(temp instanceof SimpleSignal))
        throw new IllegalArgumentException("An element with id " + id + " already exists and is not a SimpleSignal. Was: " + temp);
      SimpleSignal signal = (SimpleSignal) temp;
      if (signal == null) {
        signal = implementation.newSimpleSignal(type, parent, id, url, track);
//        signal.initWith((SignalType) type, parent, id, null, mimeClass, mimeType, encoding, track, url); // FIX-ME : do something about size!
        parent.getDefiningCorpus().addSignal(signal); // FIX-ME: NEED to handle addition to SignalGroup if parent instanceof SignalGroup!!!!
      }
      return signal;
    }
    throw new IllegalArgumentException("An invalid SimpleSignal type was given.");
  }

  /**
   * Creates an empty SignalGroup from the only mandatory information. The
   * created SignalGroup does not contain any of the
   * children elements (that is SimpleSignal, SignalGroup, Metadata) it is
   * supposed to, according to its type.
   *
   * @param type the type of the SignalGroup to create
   * @param parent the parent Corpus to define the SignalGroup in
   * @param id the Id of the SignalGroup to create
   *
   * @return a new, empty SignalGroup with the mandatory specified information
   *
   * @see gov.nist.atlas.SignalGroup
   */
  public SignalGroup createEmptySignalGroup(ATLASType type, ATLASElement parent, Id id) {
    if (type instanceof SignalType) {
      Signal temp = parent.getDefiningCorpus().getSignalWithId(id.getAsString());
      if (temp != null && !(temp instanceof SignalGroup))
        throw new IllegalArgumentException("An element with id " + id + " already exists and is not a SignalGroup. Was: " + temp);
      SignalGroup sgi = (SignalGroup) temp;
      if (sgi == null) {
        sgi = implementation.newSignalGroup(type, parent, id);
//        sgi.initWith((SignalType) type, parent, id);
        parent.getDefiningCorpus().addSignal(sgi);
      }
      return sgi;
    }
    throw new IllegalArgumentException("An invalid SignalGroup type was given.");
  }

  /**
   * The undelying ATLASImplementation associated with this ATLASElementFactory.
   */
  protected ATLASImplementation implementation;
}



