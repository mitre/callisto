/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import gov.nist.atlas.AIFSerializable;
import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Id;
import gov.nist.atlas.IdentifiableATLASElement;
import gov.nist.atlas.type.ATLASType;

import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;


/**
 * <p>ATLASElementSet is a collection of ATLASElements that contains no duplicate
 * ATLASElements. More formally, ATLASElementSets contain no pair of
 * ATLASElements ae1 and ae2 such that ae1.equals(ae2). As implied by its name,
 * this interface models the mathematical
 * <code>set</code> abstraction.</p>
 *
 * <P>To ensure that an ATLASElementSet contains only
 * ATLASElements, it is "guarded" by an object that is either an
 * ATLASType or an ATLASClass (at least). Thus, within a given
 * ATLASElementSet, every ATLASElements have either the same ATLASType or the
 * same ATLASClass, depending on the guarding object.</p>
 *
 * <P>Note that it is inspired from the java.util.Set interface, but it does
 * not implement that interface.</p>
 *
 * @version $Revision: 1.12 $
 * @author Christophe Laprun, Sylvain Pajot
 *
 * @see gov.nist.atlas.AIFSerializable
 * @see java.lang.Comparable
 */

public interface ATLASElementSet extends AIFSerializable, Comparable, Sortable {

  /**
   * Gets the ATLASType of every ATLASElements within this ATLASElementSet. This
   * is a method that is only implemented by type-guarded ATLASElementSets.
   *
   * @return the contained ATLASType of this ATLASElementSet
   *
   * @throws UnsupportedOperationException if this ATLASElementSet is not
   *         type-guarded
   */
  ATLASType getComponentATLASType();

  /**
   * Gets the type of element contained in this ATLASElementSet.
   *
   * @return a Class object representing this set's element type.
   */
  ATLASClass getComponentATLASClass();

  /**
   * Retrieves the Object by which this ATLASElementSet is guarded.
   *
   * @return the Object by which this ATLASElementSet is guarded
   *
   * @since 2.0 beta 5
   */
  Object getGuard();

  /**
   * Returns an Iterator over the ATLASElements in this ATLASElementSet. The
   * ATLASElements are returned in no particular order (unless this
   * ATLASElementSet is an instance of some class that provides a guarantee).
   *
   * @return an Iterator over the ATLASElements in this ATLASElementSet
   */
  Iterator iterator();

  /**
   * <p>Returns a ListIterator over the ATLASElements in this ATLASElementSet, in the
   * order defined by the provided Comparator.</p>
   *
   * <p>Note that this method is computationally intensive.</p>
   *
   * @param comparator a Comparator object defining the order in which the Iterator
   *        will iterate over the elements
   *
   * @return an Iterator over the ordered ATLASElements in this ATLASElementSet
   *
   * @since 2.0 beta 4
   */
  ListIterator orderedIterator(Comparator comparator);

  /**
   * Returns an ATLASElement array containing all of the ATLASElements in this
   * ATLASElementSet
   *
   * @return an array containing all of the ATLASElements in this
   * ATLASElementSet
   */
  ATLASElement[] toArray();

  /**
   * Returns the number of ATLASElements in this ATLASElementSet (its
   * cardinality). If this ATLASElementSet contains more that
   * Integer.MAX_VALUE ATLASElements, it returns Integer.MAX_VALUE.
   *
   * @return the number of ATLASElements in this ATLASElementSet
   */
  int size();

  /**
   * Returns true if this ATLASElementSet contains no ATLASElements.
   *
   * @return true if this ATLASElementSet contains no ATLASElements
   */
  boolean isEmpty();

  /**
   * Returns true if this ATLASElementSet contains the specified ATLASElement.
   *
   * @param element ATLASElement whose presence in this ATLASElementSet
   * is to be tested
   * @return true if this ATLASElementSet contains the specified ATLASElement
   */
  boolean contains(ATLASElement element);

  /**
   * Returns true if this ATLASElementSet contains every of the specified
   * ATLASElementSet's ATLASElements.
   *
   * @param set the ATLASElementSet from which every ATLASElements have to be
   * in this ATLASElementSet to return true
   * @return true if this ATLASElementSet contains the specified ATLASElement
   */
  boolean containsAll(ATLASElementSet set);

  /**
   * Returns a boolean, depending on the Class by which this
   * ATLASElementSet is guarded.
   *
   * @return true if this ATLASElementSet is guarded by an ATLASType, false if
   * it is guarded by an ATLASClass
   */
  boolean isTypeGuarded();

  /**
   * Checks if this ATLASElementSet contains the element
   * identified by the given Id.
   *
   * @return true this ATLASElementSet contains the element
   * identified by the specified Id
   *
   * @since 2.0 beta 5 (was in IdentifiedATLASElementSet)
   */
  boolean contains(Id id);

  /**
   * Returns the IdentifiedATLASElement associated to the given Id if
   * contained in this ATLASElementSet, null otherwise.
   *
   * @return the ATLASElement with the specified Id if contained,
   * <code>null</code> otherwise
   *
   * @since 2.0 beta 5 (was in IdentifiedATLASElementSet)
   */
  IdentifiableATLASElement get(Id id);

  /**
   * Returns an iterator over the Ids of the ATLASElements contained
   * in this ATLASElementSet.
   *
   * @return an iterator over the Ids of the ATLASElements contained in this
   * ATLASElementSet
   *
   * @since 2.0 beta 5 (was in IdentifiedATLASElementSet)
   */
  Iterator iteratorOverIds();

  /**
   * Determines if this ATLASElementSet contains IdentifiedATLASElements.
   *
   * @return <code>true</code> if this ATLASElementSet contains
   *         IdentifiedATLASElements, <code>false</code> otherwise
   *
   * @since 2.0 beta 5
   */
  boolean containsIdentifiableElements();

  /**
   * Retrieves the properties object associated with this ATLASElementSet.
   *
   * @return the associated ATLASElementSetProperties or <code>null</code> if none is
   *         associated with this ATLASElementSet.
   *
   * @since 2.0 beta 5
   */
  ATLASElementSetProperties getProperties();
}

