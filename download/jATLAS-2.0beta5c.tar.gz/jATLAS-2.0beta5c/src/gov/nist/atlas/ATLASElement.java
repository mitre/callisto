/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASElementSet;


/**
 * <p>ATLASElement is the root interface that defines the
 * behavior expected of all ATLAS elements. It defines the basic services that
 * must be provided by any element that is to be considered as part of the
 * ATLAS framework. ATLASElement records the needed information to the
 * insertion of a particular object in the ATLAS framework, in particular:</p>
 * <ul> <li>type information recorded via a reference to an ATLASType</li>
 * <li>defining Corpus information, the defining Corpus being the one in which
 * the element has been defined as opposed to the Corpus it is currently
 * contained in (which might or might not be the same)</li>
 * <li>subordinate information (see below)</li> </ul>
 *
 * <p>Subordinate elements are ATLASElements that ATLASElements can contain or
 * reference, as defined by the data model. A given subordinate is identified
 * by an ATLASClass and a role.</p>
 *
 * @version $Revision: 1.19 $
 * @author Christophe Laprun
 *
 * @see gov.nist.atlas.type.ATLASType
 * @see ATLASClass
 * @see Corpus
 */
public interface ATLASElement extends Validatable, Comparable {
  /**
   * Returns this ATLASElement's ATLASType.
   *
   * @return the ATLASType of this ATLASElement
   *
   * @see gov.nist.atlas.type.ATLASType
   */
  ATLASType getATLASType();

  /**
   * Returns this ATLASElement's ATLASClass.
   *
   * @return the ATLASClass of this ATLASElement
   *
   * @see ATLASClass
   *
   * @since 2.0 beta 4
   */
  ATLASClass getATLASClass();

  /**
   * Returns the Corpus in which this ATLASElement has been defined.
   *
   * @return the defining Corpus
   *
   * @see Corpus
   */
  Corpus getDefiningCorpus();

  /**
   * Returns the structural parent of this ATLASElement, i.e. the ATLASElement
   * this ATLASElement is defined in.
   *
   * @return the ATLASElement in which this ATLASElement has been defined
   *
   * @since 2.0 beta 4
   */
  ATLASElement getParent();

  /**
   * Sets the subordinate ATLASElement identified with the specified
   * role to the specified ATLASElement if such an operation is allowed by this
   * ATLASElement's ATLASType.
   *
   * @param element the new value for the subordinate element
   * @param role    the role of subordinate element to be set, if no role has
   *                been specified in the MAIA definition for this ATLASElement's
   *                ATLASType, the ATLASType.NULL_ROLE constant should be used
   *
   * @return  <code>true</code> if the subordinate element has been sucessfully
   * set, <code>false</code> otherwise meaning that the specified
   * element cannot be assigned to the subordinate identified with
   * the given role
   *
   * @see gov.nist.atlas.type.ATLASType#canSetSubordinateWithRole(ATLASElement,String)
   *
   * @since 2.0 beta 4 (renamed, was setElementWithRole)
   */
  boolean setSubordinateWithRole(ATLASElement element, String role) throws ATLASAccessException;

  /**
   * Gets the subordinate identified with the specified role.
   *
   * @param role the role identifying the subordinate to be retrieved, if no role has
   *             been specified in the MAIA definition for this ATLASElement's
   *             ATLASType, the ATLASType.NULL_ROLE constant should be used
   *
   * @return  the corresponding subordinate or null if there is no subordinate
   * associated with the specified arguments. Note that in future
   * versions of the API, this method might throw an exception.
   *
   * @see gov.nist.atlas.type.ATLASType#NULL_ROLE
   *
   * @since 2.0 beta 4 (renamed, was getElementWithRole)
   */
  ATLASElement getSubordinateWithRole(String role) throws ATLASAccessException;

  /**
   * Returns the Children element (if any exists), contained in this
   * ATLASElement, identified with the specified role.
   *
   * @param role the role of the Children element to retrieve
   * @return the Children associated with the specified role if any exists
   * @throws ATLASAccessException (to be detailed later)
   *
   * @since 2.0 beta 4
   */
  Children getChildrenWithRole(String role) throws ATLASAccessException;

  /**
   * Adds (if possible) the specified child to the Children element contained
   * in this ATLASElement and identified with the specified role.
   *
   * @param child the ATLASElement to add to the specified Children
   * @param role the role identifying in which Children to add the new child
   * @return <code>true</code> if the identified Children has been successfully
   *         modified, <code>false</code> otherwise.
   * @throws ATLASAccessException (to be detailed later)
   *
   * @since 2.0 beta 4
   */
  boolean addToChildrenWithRole(ATLASElement child, String role) throws ATLASAccessException;

  /**
   * Removes (if possible) the specified child from the Children element contained
   * in this ATLASElement and identified with the specified role.
   *
   * @param child the ATLASElement to remove from the specified Children
   * @param role the role identifying from which Children to remove the child
   * @return <code>true</code> if the identified Children has been successfully
   *         modified, <code>false</code> otherwise.
   * @throws ATLASAccessException (to be detailed later)
   *
   * @since 2.0 beta 4
   */
  boolean removeFromChildrenWithRole(ATLASElement child, String role) throws ATLASAccessException;

  /**
   * Retrieves the subordinate set contained in this ATLASElement and that gathers
   * subordinate with the specified type.
   *
   * @param containedSubordinateType the type of the subordinates contained
   *        in the ATLASElementSet to be retrieved
   * @return
   * @throws ATLASAccessException (to be detailed later)
   *
   * @since 2.0 beta 4
   */
  ATLASElementSet getSubordinateSet(ATLASType containedSubordinateType) throws ATLASAccessException;

  /**
   * Add (if possible) the specified subordinate to this ATLASElement's
   * subordinate set.
   *
   * @param subordinate the subordinate to be added
   * @return <code>true</code> if the subordinate set has been successfully
   *         modified, <code>false</code> otherwise.
   * @throws ATLASAccessException (to be detailed later)
   *
   * @since 2.0 beta 4
   */
  boolean addToSubordinateSet(ATLASElement subordinate) throws ATLASAccessException;

  /**
   * Remove (if possible) the specified subordinate from this ATLASElement's
   * subordinate set.
   *
   * @param subordinate the subordinate to be removed
   * @return <code>true</code> if the subordinate set has been successfully
   *         modified, <code>false</code> otherwise.
   * @throws ATLASAccessException (to be detailed later)
   *
   * @since 2.0 beta 4
   */
  boolean removeFromSubordinateSet(ATLASElement subordinate) throws ATLASAccessException;

  /**
   * Retrieves (if possible) all the subordinates with the specified ATLASClass. Note that
   * <strong>ONLY</strong> the subordinates found in subordinate sets are retrieved in this
   * manner.
   *
   * @param atlasClass the ATLASClass of the subordinates to be retrieved
   * @return a (possibly empty) ATLASElementSet containing this ATLASElement's subordinates
   *         with the specified ATLASClass.
   * @throws ATLASAccessException (to be detailed later)
   *
   * @since 2.0 beta 5
   */
  ATLASElementSet getAllSubordinatesInSubordinateSetsWith(ATLASClass atlasClass) throws ATLASAccessException;

  Object getApplicationDelegateWith(String name);

  boolean setApplicationDelegate(String name, Object applicationDelegate);

  /*
  ATLASElementSet getAllRequiredSubordinatesWith(ATLASClass atlasClass) throws ATLASAccessException;

  ATLASElementSet getAllChildrenWith(ATLASClass atlasClass) throws ATLASAccessException;

  ATLASElementSet getAllSubordinatesWith(ATLASClass atlasClass) throws ATLASAccessException;
  */
}

