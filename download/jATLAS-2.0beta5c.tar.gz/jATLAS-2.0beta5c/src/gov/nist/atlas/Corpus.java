/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.CorpusType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.maia.MAIAScheme;

import java.net.URL;


/**
 * <p>A Corpus is an ATLAS abstraction for a linguistic corpus and consists of
 * a collection of annotations and related information. In ATLAS, the act of
 * linguistic annotation is performed by building Annotation elements.
 * Annotations are built by associating information, via Content elements, to
 * a region, via Region elements, in a signal represented via a
 * Signal element.</p>
 *
 * <p>A Corpus gathers Annotations via the use of Analysis elements, while
 * signal and regions information is defined by the Signal,
 * Region and Anchor elements which Corpus objects directly manage.</p>
 *
 * @author Christophe Laprun
 * @author Sylvain Pajot
 * @version $Revision: 1.32 $
 *
 * @see Analysis
 * @see Annotation
 * @see Content
 * @see Region
 * @see Signal
 */
public interface Corpus extends MetadataHolder, IdentifiableATLASElement, SignalsHolder {
  /**
   * Retrieves the MAIAScheme via which the types used in this Corpus were
   * defined.
   *
   * @return the MAIAScheme containing the type definitions used in this Corpus.
   *
   * @see gov.nist.maia.MAIAScheme
   *
   * @since 2.0 beta 4
   */
  MAIAScheme getMAIAScheme();

  /**
   * Determines wether this Corpus is shallow.
   *
   * @return <code>true</code if this Corpus is shallow, <code>false</code> otherwise
   *
   * @since 2.0 beta 4
   *
   * @deprecated Move to SPI
   */
  boolean isShallow();

  /**
   * Specifies whether this Corpus is shallow or not.
   *
   * @param shallow <code>true</code> to specify that this Corpus is shallow,
   *                <code>false</code> otherwise
   *
   * @return the previous shallownes of this Corpus
   *
   * @since 2.0 beta 4
   *
   * @deprecated Move to SPI
   */
  boolean setShallow(boolean shallow);

  /**
   * Assigns a new location to this Corpus. This method is called when a Corpus
   * is first serialized.
   *
   * @param location a URL specifying the new location for this Corpus
   *
   * @since 2.0 beta 4
   *
   * @deprecated Move to SPI?
   */
  void setLocation(URL location);

  /**
   * Returns this Corpus' type as an CorpusType object.
   *
   * @return the CorpusType assigned to this Corpus
   */
  CorpusType getCorpusType();

  /**
   * Returns the location from which this Corpus was loaded.
   *
   * @return the URL representing the location from which this
   * Corpus was loaded, <code>null</code> if this Corpus was created in memory
   * and not yet saved
   */
  URL getLocation();

  /**
   * Returns the AIF version associated with this Corpus. The AIF version
   * corresponds to the version the ATLAS data model followed by this Corpus.
   *
   * @return the AIF version associated with this Corpus
   */
  String getAIFVersion();

  /**
   * Assigns the specified Analysis to the subordinate
   * identified with the given role.
   *
   * @param analysis the new value for the subordinate
   * @param role the role identifying the Analysis subordinate to be set
   *
   * @return <code>true</code> if the assignement was correctly done,
   * <code>false</code> otherwise
   */
  boolean setAnalysisWithRole(Analysis analysis, String role);

  /**
   * Returns the Analysis subordinate identified with the specified role.
   *
   * @param role the role identifying the Analysis to retrieve
   *
   * @return the Analysis subordinate identified with the specified role,
   * <code>null</code> if no such Analysis is contained in this Corpus
   */
  Analysis getAnalysisWithRole(String role);

  /**
   * Returns the Analysis subordinate identified with the specified id.
   *
   * @param id a String representation of the id of the Analysis
   * to be retrieved
   *
   * @return the Analysis subordinate identified with the specified id,
   * <code>null</code> if no such Analysis is contained in this Corpus
   */
  Analysis getAnalysisWithId(String id);

  /**
   * Returns all the Analysis subordinates contained in this Corpus.
   *
   * @return a possibly empty ATLASElementSet containing this Corpus'
   * Analysis subordinates
   */
  ATLASElementSet getAllAnalyses();

  /**
   * Returns the Anchor identified with the specified id.
   *
   * @param id a String representation of the id of the Anchor to be retrieved
   *
   * @return the Anchor identified with the specified id,
   * <code>null</code> if no such Anchor is contained in this Corpus
   */
  Anchor getAnchorWithId(String id);

  /**
   * Retrieves all the Anchors contained in this Corpus.
   *
   * @return a (possibly empty) ATLASElementSet containing this Corpus' Anchors.
   *
   * @since 2.0 beta 5
   */
  ATLASElementSet getAllAnchors();

  /**
   * Returns the Annotation identified with the specified id.
   *
   * @param id a String representation of the id of the Annotation
   * to be retrieved
   *
   * @return the Annotation identified with the specified id,
   * <code>null</code> if no such Annotation is contained in this Corpus
   */
  Annotation getAnnotationWithId(String id);

  /**
   * Retrieves all the Annotations contained in this Corpus.
   *
   * @return a (possibly empty) ATLASElementSet containing this Corpus' Annotations.
   *
   * @since 2.0 beta 5
   */
  ATLASElementSet getAllAnnotations();

  /**
   * Returns the Region identified with the specified id.
   *
   * @param id a String representation of the id of the Region to be retrieved
   *
   * @return the Region identified with the specified id,
   * <code>null</code> if no such Region is contained in this Corpus
   */
  Region getRegionWithId(String id);

  /**
   * Retrieves all the Regions contained in this Corpus.
   *
   * @return a (possibly empty) ATLASElementSet containing this Corpus' Regions.
   *
   * @since 2.0 beta 5
   */
  ATLASElementSet getAllRegions();

  /**
   * Adds the specified Anchor to this Corpus.
   *
   * @param anchor the Anchor to be added
   *
   * @return <code>true</code> if the addition was correctly done,
   * <code>false</code> otherwise
   */
  boolean addAnchor(Anchor anchor);

  /**
   * Removes the specified Anchor to this Corpus.
   *
   * @param anchor the Anchor to be removed
   *
   * @return <code>true</code> if the removal was correctly done,
   * <code>false</code> otherwise
   */
  boolean removeAnchor(Anchor anchor);

  /**
   * Adds the specified Region to this Corpus.
   *
   * @param region the Region to be added
   *
   * @return <code>true</code> if the addition was correctly done,
   * <code>false</code> otherwise
   */
  boolean addRegion(Region region);

  /**
   * Removes the specified Region to this Corpus.
   *
   * @param region the Region to be removed
   *
   * @return <code>true</code> if the removal was correctly done,
   * <code>false</code> otherwise
   */
  boolean removeRegion(Region region);

  /**
   * Returns the Signal identified with the specified id if it is contained
   * in this Corpus.
   *
   * @param id a String representation of the id of the Signal to be retrieved
   *
   * @return the Signal identified with the specified id,
   * <code>null</code> if no such Signal is contained in this Corpus
   */
  Signal getSignalWithId(String id);

  /**
   * Retrieves the ATLASType of the specified ATLASClass and with the
   * specified name.
   *
   * @param clazz the ATLASClass of the ATLASType to be retrieved
   * @param typeName the name of the ATLASType to be retrieved
   *
   * @return the ATLASType of the specified ATLASClass and with the specified
   * name, <code>null</code> if no ATLASType exists with the given
   * ATLASClass and name
   */
  ATLASType resolveTypeFor(ATLASClass clazz, String typeName);

  /**
   * Retrieves the Id object associated to the specified String identifier if
   * such an Id is associated to an identified ATLASElement contained
   * in this Corpus.
   *
   * @param stringId the String identifier corresponding to the Id
   * to be retrieved
   *
   * @return the Id associated to the specified String identifier,
   * <code>null</code> if no ATLASElement contained in this Corpus has
   * an Id corresponding to the specified identifier
   */
  Id resolveIdFor(String stringId);

  /**
   * Determines if this Corpus contains a ReusableATLASElement with the specified identifier.
   *
   * @param stringId the String identifier corresponding to the identifier
   *        of the potentially contained element
   *
   * @return <code>true</code> if such an element is contained in this Corpus,
   *         <code>false</code> otherwise
   *
   * @since 2.0 beta 6
   */
  boolean containsReusableElementWith(String stringId);

  /**
   * Determines if this Corpus contains a ReusableATLASElement with the specified ATLASClass and
   * identifier.
   *
   * @param aClass the ATLASClass of the potentially contained element
   * @param stringId the String identifier corresponding to the identifier
   *        of the potentially contained element
   *
   * @return <code>true</code> if such an element is contained in this Corpus,
   *         <code>false</code> otherwise
   *
   * @since 2.0 beta 4
   */
  boolean containsReusableElementWith(ATLASClass aClass, String stringId);

  /**
   * Retrieves the ReusableATLASElement associated with the given ATLASClass and
   * identifier, if such an element is contained in this Corpus.
   *
   * @param aClass  the ATLASClass of the element to be retrieved
   * @param stringId a String representation of the identifier
   *
   * @return the retrieved ReusableATLASElement, <code>null</code> if the element
   * is not contained (yet) in this Corpus. Should we return a ref when the
   * element has not been created yet?
   *
   * @since 2.0 beta 4
   */
  ReusableATLASElement getReusableElementWith(ATLASClass aClass, String stringId);

  /**
   * <p>Retrieves the ReusableATLASElement associated with the specified identifier if such an
   * element is contained in this Corpus.</p>
   *
   * <p>Note that if the class of the ReusableATLASElement to be retrieved is known,
   * getReusableElementWith(ATLASClass, String) will perform better.</p>
   *
   * @param stringId a String representation of the identifier
   * @return the retrieved ReusableATLASElement, <code>null</code> otherwise.
   *
   * @since 2.0 Beta 6
   */
  ReusableATLASElement getReusableElementWith(String stringId);

  /**
   * Tests if this Corpus contains an IdentifiableATLASElement with the specified identifier.
   *
   * @param stringId the String identifier corresponding to the identifier
   *        of the potentially contained element
   *
   * @return <code>true</code> if such an element is contained in this Corpus,
   *         <code>false</code> otherwise
   *
   * @since 2.0 beta 6
   */
  boolean containsIdentifiableElementWith(String stringId);

  /**
   * Retrieves the IdentifiableATLASElement associated with the given ATLASClass and
   * identifier, if such an element is contained in this Corpus.
   *
   * @param aClass  the ATLASClass of the element to be retrieved
   * @param stringId a String representation of the identifier
   *
   * @return the retrieved IdentifiableATLASElement, <code>null</code> if the element
   * is not contained (yet) in this Corpus. Should we return a ref when the
   * element has not been created yet?
   *
   * @since 2.0 beta 6
   */
  IdentifiableATLASElement getIdentifiableElementWith(ATLASClass aClass, String stringId);

  /**
   * <p>Retrieves the IdentifiableATLASElement associated with the specified identifier if such an
   * element is contained in this Corpus.</p>
   *
   * <p>Note that if the class of the IdentifiableATLASElement to be retrieved is known,
   * getIdentifiableElementWith(ATLASClass, String) will perform better.</p>
   *
   * @param stringId a String representation of the identifier
   * @return the retrieved IdentifiableATLASElement, <code>null</code> otherwise.
   *
   * @since 2.0 Beta 6
   */
  IdentifiableATLASElement getIdentifiableElementWith(String stringId);
  /*
    Maybe we should introduce a method to create elements if possible (directed building)
    @param createIfPossible <code>true</code> to create the element now if it
                            hasn't been created yet (reference expansion),
                            <code>false</code> otherwise (should we return a ref then?)
  */

  /**
   * <p>Returns the ATLASImplementation associated to this Corpus. A Corpus is
   * associated to an ATLASImplementation object that controls which
   * implementation of the ATLAS interfaces are used in the context of this
   * Corpus. See ATLASImplementation for more details.</p>
   *
   * @return the ATLASImplementation associated to this Corpus
   *
   * @see gov.nist.atlas.util.ATLASImplementation
   */
  ATLASImplementation getATLASImplementation();

  /**
   * Returns the set of non-validated ATLASElements contained in this Corpus.
   * <strong>NOT YET SUPPORTED</strong>
   *
   * @return a possibly empty ATLASElementSet containing the
   * non-validated ATLASElements
   *
   * @see Validatable
   *
   * @deprecated Will either be removed or return a Set instead of an ATLASElementSet
   */
  ATLASElementSet getNonValidatedElements();

  /**
   * @link aggregationByValue
   * @supplierCardinality 0..*
   * @supplierRole RegionSet
   */

  /*#Region lnkRegion;*/

  /**
   * @link aggregationByValue
   * @supplierCardinality 0..*
   */

  /*#Signal lnkSignalGroup;*/

  /**
   * @link aggregationByValue
   * @supplierCardinality 0..*
   * @supplierRole AnchorSet
   */

  /*#Anchor lnkAnchor;*/

  /**
   * @link aggregationByValue
   * @supplierCardinality 1..*
   */

  /*#Analysis lnkAnalysis;*/
}


