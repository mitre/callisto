/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.io.xml;

import gov.nist.atlas.Corpus;
import gov.nist.atlas.io.AbstractATLASImport;
import gov.nist.atlas.io.ImportedCorpusBuilder;
import gov.nist.atlas.io.ImportedElement;
import gov.nist.atlas.io.ImportedElementBuilderFactory;
import gov.nist.atlas.util.ATLASImplementation;

import java.io.File;
import java.net.URL;


/**
 * AIFXMLImport is the implementation of the ATLASImport to build a Corpus
 * from an AIF file.
 *
 * <P>Note that a corpus that has just been imported doesn't necessarily
 * complies with its MAIA definition. It means that once the <CODE>load</CODE>
 * method has been called, the validation - if wanted - has to be performed
 * explicitely (call to the <CODE>validate</CODE> method).
 *
 * @author Sylvain Pajot
 * @version $Revision: 1.30 $
 *
 * @see gov.nist.atlas.io.AbstractATLASImport
 */
public class AIFXMLImport extends AbstractATLASImport {
  public AIFXMLImport() {
  }

  public AIFXMLImport(URL url, ATLASImplementation impl /*boolean validate*/) {
    super(new XMLImportedElementLoader(url, null), impl);
  }

  public AIFXMLImport(File file, ATLASImplementation impl /*boolean validate*/) {
    super(new XMLImportedElementLoader(file, null), impl);
  }

  protected Corpus buildCorpus(ImportedElement ieCorpus) {
    return ImportedElementBuilderFactory.getFactoryFor(implementation).getImportedCorpusBuilder().buildCorpus(ieCorpus, importedElementLoader.getURL(), false);
  }

  protected Corpus buildCorpus(ImportedElement ieCorpus, boolean shallowly) {
    ImportedCorpusBuilder builder =
        ImportedElementBuilderFactory.getFactoryFor(implementation).getImportedCorpusBuilder();
    return builder.buildCorpus(ieCorpus, importedElementLoader.getURL(), shallowly);
  }

  public void setSourceURL(URL source) {
    importedElementLoader = new XMLImportedElementLoader(source, null);
  }
}

