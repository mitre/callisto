/*
    ATLAS [Architecture and Tools for Linguistic Analysis Systems]
    Object-oriented architecture and component framework for linguistic
    application development.
    Copyright (C) 2000 Christophe Laprun for NIST

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.io.xml;

import gov.nist.atlas.Corpus;
import gov.nist.atlas.io.ATLASExport;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;


/**
 * This class is the XML oriented skeletal implementation of the
 * ATLASExport interface. It implements the inherited <CODE>save</CODE> method
 * in a generic manner (in a file, see below paragraph) but still does not
 * handle the storage format in which the corpus has to be written (for example,
 * AIF).
 *
 * <P>XMLExport's current constructors (based on a File and a URL) obviously
 * tends it (and all its subclasses as well) to focus on file-oriented
 * storage means, AIF being the most common way to store corpora. It means that
 * to export a corpus to anything but a file (a relational database for
 * instance), a complete implementation of the ATLASExport interface has to be
 * written.
 *
 * To implement an ATLASExport generating an XML file, the user needs only to
 * extend this class and to implement the context specific <CODE>write</CODE>
 * method which depends on the contained type (the storage format) to export.
 *
 * @author Sylvain Pajot, Chris Laprun
 * @version $Revision: 1.11 $
 */
public abstract class XMLExport implements ATLASExport {


  /** Constructs an ATLASExport for the specified output file to export to. */
  public XMLExport(File destination) {
    try {
      url = destination.toURL();
    } catch (MalformedURLException e) {
      System.out.println(e.toString());
    }
  }

  /**
   * Constructs an ATLASExport for the specified URL locating the input
   * file to export to.
   */
  public XMLExport(URL url) {
    this.url = url;
  }

  public void setDestinationURL(URL destination) {
    this.url = destination;
  }

  // FIX-ME: Still needs work: improve error handling, perform validation
  public void save(Corpus corpus) {
//    if(corpus.isValid()) {
    File out = new File(url.getFile());
    File backup = null;

    // Let's backup first if the file already exists!
    if (out.isFile()) {
      backup = new File(out.getAbsolutePath() + ".old");
      out.renameTo(backup);
    }

    try {
      PrintWriter writer = new PrintWriter(new BufferedOutputStream(new FileOutputStream(out)));
      write(corpus, writer);
      writer.flush();
      writer.close();
      corpus.setLocation(url);
    } catch (Exception e) {
      e.printStackTrace();
      backup.renameTo(out); // restore from backup
    }
//  }
  }

  /**
   * Writes the given corpus into this XMLExport's associated output file,
   * using the specified writer
   * This method is used by the <CODE>save</CODE> method
   *
   * @param corpus - The Corpus to export
   * @param writer - The Writer to use
   */
  protected abstract void write(Corpus corpus, Writer writer);


  protected URL url;
}



