/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.io;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.Anchor;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Id;
import gov.nist.atlas.Parameter;
import gov.nist.atlas.Region;
import gov.nist.atlas.io.xml.AIFConstants;
import gov.nist.atlas.ref.ATLASRef;
import gov.nist.atlas.ref.SignalRef;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.AnchorType;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.RoleIdentifiedParameter;
import gov.nist.atlas.util.RoleWrapper;

import java.util.Iterator;
import java.util.List;

/**
 * ImportedAnchorBuilder builds an Anchor from a matching ImportedElement
 *
 * Note that the ImportedElement well-defining the Anchor to create is a prerequisite.
 * If the ImportedElement is not eligible for creating an Anchor, an IllegalArgumentException is
 * raised.
 *
 * @author Sylvain Pajot
 * @see ImportedElementBuilder
 */
public class ImportedAnchorBuilder extends ImportedElementBuilder {

  public ImportedAnchorBuilder(ATLASImplementation implementation, ImportedElementBuilderFactory parentFactory) {
    super(implementation, parentFactory);
  }

  public Anchor buildAnchor(ImportedElement ieAnchor, Corpus definingCorpus) {
    Anchor anchor;
    String anchorID = ieAnchor.getAttributeValue(AIFConstants.ID),
        anchorType = ieAnchor.getAttributeValue(AIFConstants.TYPE);
    if (anchorID == null)
      throw new IllegalArgumentException("Can't find id attribute in Anchor element");
    if (anchorType == null)
      throw new IllegalArgumentException("Can't find type attribute in Anchor element");
    /*if (!anchorType.equals(type))
      throw new IllegalArgumentException("Incompatible AnchorSet/Anchor type");*/

    // signal
    ImportedElement ieTemp = ieAnchor.getChild(AIFConstants.SIGNALREF);
    if (ieTemp == null)
      throw new IllegalArgumentException("Can't find SignalRef element in anchor element");
    AnchorType at = (AnchorType) definingCorpus.resolveTypeFor(ATLASClass.ANCHOR, anchorType);
    SignalRef signal = getBuilderFactory().getImportedSignalBuilder().getSignalFromSignalRef(ieTemp, definingCorpus, at.getSignalType());

    Id id = getATLASElementFactory().resolveIdFor(anchorID);
    if (id == null) id = getATLASElementFactory().createNewIdFor(anchorID);
    anchor = getATLASElementFactory().createEmptyAnchor(definingCorpus.resolveTypeFor(ATLASClass.ANCHOR, anchorType), definingCorpus, id, signal);

    // create at least one anchor
    List list = ieAnchor.getChildren(AIFConstants.PARAMETER);
    int nb = list.size();
    if (nb == 0)
      throw new IllegalArgumentException("Can't find Parameter element in Anchor element");
    Iterator i = list.iterator();
    Parameter param;
    RoleIdentifiedParameter[] params = new RoleIdentifiedParameter[nb];
    String role;
    nb = 0;
    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      param = getBuilderFactory().getImportedParameterBuilder().buildParameter(ieTemp, anchor);
      role = ieTemp.getAttributeValue(AIFConstants.ROLE);
      if (role == null)
        throw new IllegalArgumentException("Can't find role attribute in parameter element");
      params[nb] = RoleWrapper.createRoleIdentifiedParameter(param, role);
      nb++;
    }

    anchor.initContainedElementsWith(params);

    return anchor;
  }


  public Anchor getAnchorFromAnchorRef(ImportedElement ieAnchorRef, Corpus corpus, ATLASType anchorType) {
    String href = ieAnchorRef.getAttributeValueWithNamespace(AIFConstants.XLINKHREF, AIFConstants.XLINK);
    if (href == null)
      throw new IllegalArgumentException("Can't find href attribute in RegionRef element");
    if (href.equals(""))
      throw new IllegalArgumentException("Found empty href attribute in RegionRef element");
    String role = ieAnchorRef.getAttributeValue(AIFConstants.ROLE);
    if (role == null)
      throw new IllegalArgumentException("Can't find role attribute in RegionRef element");
    // FIX-ME : test for empty role ?
    return ATLASRef.createAnchorRef(href, anchorType, corpus, role);
  }

  public void addAnchorsFromAnchorRefSetTo(Region parentRegion, ImportedElement ieAnchorRefSet) {
    Anchor anchor;
    List list = ieAnchorRefSet.getChildren(AIFConstants.ANCHORREF);
    if (list.size() == 0)
      throw new IllegalArgumentException("Can't find AnchorRef elements in AnchorRefSet element");
    Iterator i = list.iterator();
    ImportedElement ieTemp;
    String role;
    String type = ieAnchorRefSet.getAttributeValue(AIFConstants.CONTAINEDTYPE);
    if (type == null)
      throw new IllegalArgumentException("Can't find containedType attribute in AnchorRefSet element");
    if (type.equals(""))
      throw new IllegalArgumentException("Found empty type attribute in AnchorRefSet element");
    ATLASType t = parentRegion.getDefiningCorpus().resolveTypeFor(ATLASClass.ANCHOR, type);

    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      role = ieTemp.getAttributeValue(AIFConstants.ROLE);
      if (role == null)
        throw new IllegalArgumentException("Can't find role attribute in AnchorRef element");
      anchor = getAnchorFromAnchorRef(ieTemp, parentRegion.getDefiningCorpus(), t);
      if (!(anchor.getATLASType().equals(t)))
        throw new IllegalArgumentException("Incompatible type for AnchorRefSet/Anchor");
      if (!parentRegion.addAnchor(anchor))
        throw new IllegalArgumentException("Can't add anchor from AnchorRefSetto region");

    }
  }

}
