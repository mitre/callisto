/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.io;

import gov.nist.atlas.util.ATLASImplementation;

import java.util.HashMap;
import java.util.Map;

/**
 * ImportedElementBuilderFactory provides access to the ImportedElementBuilder
 * that are needed to build a Corpus <I>from an AIF data source</I>.
 * It is associated to an ATLASImplementation, allowing the users to use their own
 * ImportedElementBuilderFactories for this implementation by registering them first.
 *
 * Note that ImportedElementBuilderFactory is intended to solely deal with AIF
 * files, because some other ImportedElementBuilder may be needed if dealing
 * with another type of input data (the mapping with the format and the ATLAS
 * core ontologies may require other processes anc may not be a 1 to 1 mapping).
 *
 * @author Sylvain Pajot
 */
public abstract class ImportedElementBuilderFactory {

  /**
   * Returns the ImportedElementBuilderFactory associated the given ATLASImplementation.
   * If none has been registered for this ATLASImplementation yet, then a
   * DefaultImportedElementBuilderFactory is registered and is returned.
   * @param implementation the ATLASImplementation to make the selection on
   * @return the corresponding ImportedElementBuilderFactory
   */
  public final static ImportedElementBuilderFactory getFactoryFor(ATLASImplementation implementation) {
    ImportedElementBuilderFactory factory = (ImportedElementBuilderFactory) factories.get(implementation);
    if (factory == null) {
      factory = new DefaultImportedElementBuilderFactory(implementation);
      factories.put(implementation, factory);
    }
    return factory;
  }

  /**
   * TODO: currently allows to instanciate an ImportedElementBuilderFactory with a given
   * ATLASImplementation, and to register it with another... weakness ?
   *
   * Registers an ImportedElementBuilderFactory for the given ATLASImplementation
   * @param implementation the ATLASImplementation to register <CODE>factory</CODE> to
   * @param factory the ImportedElementBuilderFactory to register
   * @return true if the factory has been registered, false instead (another factory has
   *         previously been registered for this factory)
   */
  public final static boolean registerFactory(
      ATLASImplementation implementation,
      ImportedElementBuilderFactory factory) {
    if (factories.get(implementation) == null) {
      factories.put(implementation, factory);
      return true;
    } else
      return false;
  }

  /**
   * Returns the ImportedParameterBuilder for this factory
   * @return the ImportedParameterBuilder for this factory
   */
  public abstract ImportedParameterBuilder getImportedParameterBuilder();

  /**
   * Returns the ImportedAnchorBuilder for this factory
   * @return the ImportedAnchorBuilder for this factory
   */
  public abstract ImportedAnchorBuilder getImportedAnchorBuilder();

  /**
   * Returns the ImportedSignalBuilder for this factory
   * @return the ImportedSignalBuilder for this factory
   */
  public abstract ImportedSignalBuilder getImportedSignalBuilder();

  /**
   * Returns the ImportedRegionBuilder for this factory
   * @return the ImportedRegionBuilder for this factory
   */
  public abstract ImportedRegionBuilder getImportedRegionBuilder();

  /**
   * Returns the ImportedAnnotationBuilder for this factory
   * @return the ImportedAnnotationBuilder for this factory
   */
  public abstract ImportedAnnotationBuilder getImportedAnnotationBuilder();

  /**
   * Returns the ImportedFeatureBuilder for this factory
   * @return the ImportedFeatureBuilder for this factory
   */
  public abstract ImportedFeatureBuilder getImportedFeatureBuilder();

  /**
   * Returns the ImportedMetadataBuilder for this factory
   * @return the ImportedMetadataBuilder for this factory
   */
  public abstract ImportedMetadataBuilder getImportedMetadataBuilder();

  /**
   * Returns the ImportedAnalysisBuilder for this factory
   * @return the ImportedAnalysisBuilder for this factory
   */
  public abstract ImportedAnalysisBuilder getImportedAnalysisBuilder();

  /**
   * Returns the ImportedCorpusBuilder for this factory
   * @return the ImportedCorpusBuilder for this factory
   */
  public abstract ImportedCorpusBuilder getImportedCorpusBuilder();


  /** The map that keeps track of the registered ImportedElementBuilderFactories */
  private final static Map factories = new HashMap(7);
}
