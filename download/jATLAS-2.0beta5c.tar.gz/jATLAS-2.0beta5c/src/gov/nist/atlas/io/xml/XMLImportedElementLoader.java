/*
 * Created by IntelliJ IDEA.
 * User: pajot
 * Date: Apr 12, 2002
 * Time: 6:07:12 PM
 * To change template for new class use
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package gov.nist.atlas.io.xml;

import gov.nist.atlas.io.ImportedElement;
import gov.nist.atlas.io.ImportedElementLoader;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.net.URL;

/**
 * XMLImportedElementLoader turns data from valid XML documents into a hierarchy of
 * ImportedElements.
 * It is associated with an XML document whose root element is intended to be turned
 * into a Corpus. Sub-element retrieval is not yet supported but should be in a next
 * release. As a consequence, it only returns the ImportedElement corresponding to a
 * Corpus from the XML resource for no, replacing the former XMLImport abstract class
 * (in previous versions of jATLAS).
 *
 * Note: the parsing process is handled using the Dom4J parser (http://www.dom4j.org).
 *
 * @see gov.nist.atlas.io.ImportedElementLoader
 */
public class XMLImportedElementLoader extends ImportedElementLoader {

  public XMLImportedElementLoader(URL url, String namespace) {
    super(url);
    this.namespace = namespace;
  }

  public XMLImportedElementLoader(File file, String namespace) {
    super(file);
    this.namespace = namespace;
  }


  public ImportedElement getImportedCorpus() {
    Document document;
    try {
      SAXReader reader = new SAXReader();
      document = reader.read(getURL());
      Element eCorpus = document.getRootElement();
      namespace = eCorpus.getNamespace().getPrefix();
      XMLImportedElement.setNamespace(eCorpus.getNamespacePrefix(), namespace);
      return new XMLImportedElement(eCorpus);
    } catch (DocumentException de) {
      System.out.println(de.getMessage());
      return null;
    }
  }

  /** Default namespace */
  protected String namespace;

}
