/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.io;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Feature;
import gov.nist.atlas.Parameter;
import gov.nist.atlas.io.xml.AIFConstants;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.RoleIdentifiedFeature;
import gov.nist.atlas.util.RoleIdentifiedParameter;
import gov.nist.atlas.util.RoleWrapper;

import java.util.Iterator;
import java.util.List;

/**
 * ImportedFeatureBuilder builds a Feature from a matching ImportedElement.
 *
 * Note that the ImportedElement well-defining the Feature to create is a prerequisite.
 * If the ImportedElement is not eligible for creating a Feature, an IllegalArgumentException is
 * raised.
 *
 * @author Sylvain Pajot
 * @see ImportedElementBuilder
 */
public class ImportedFeatureBuilder extends ImportedElementBuilder {

  public ImportedFeatureBuilder(ATLASImplementation implementation, ImportedElementBuilderFactory parentFactory) {
    super(implementation, parentFactory);
  }


  public Feature buildFeature(ImportedElement ieFeature, ATLASElement parent) {
    String featureType = ieFeature.getAttributeValue(AIFConstants.TYPE);
    if (featureType == null)
      throw new IllegalArgumentException("Cant' find type attribute in Feature element");
    if (featureType.equals(""))
      throw new IllegalArgumentException("Found empty type attribute in Feature element");
    Feature feature = getATLASElementFactory().createEmptyFeature(parent.getDefiningCorpus().resolveTypeFor(ATLASClass.FEATURE, featureType), parent);
    if (feature == null)
      throw new IllegalArgumentException("Can't create Feature");


    ImportedElement ieTemp;
    String role;
    // FIX-ME : shared code with initContentOfAnnotation

    // Features
    List list = ieFeature.getChildren(AIFConstants.FEATURE);
    int nb = list.size();
    RoleIdentifiedFeature[] features = null;
    Iterator i;
    if (nb > 0) {
      features = new RoleIdentifiedFeature[nb];
      i = list.iterator();
      nb = 0;
      Feature feat;
      while (i.hasNext()) {
        ieTemp = (ImportedElement) i.next();
        feat = buildFeature(ieTemp, feature);
        role = ieTemp.getAttributeValue(AIFConstants.ROLE);
        if (role == null)
          throw new IllegalArgumentException("Can't find role attribute in Feature element");
        features[nb++] = RoleWrapper.createRoleIdentifiedFeature(feat, role);
      }
    }

    // Parameters
    list = ieFeature.getChildren(AIFConstants.PARAMETER);
    nb = list.size();
    RoleIdentifiedParameter[] params = null;
    if (nb > 0) {
      params = new RoleIdentifiedParameter[nb];
      i = list.iterator();
      nb = 0;
      Parameter parameter;
      while (i.hasNext()) {
        ieTemp = (ImportedElement) i.next();
        parameter = getBuilderFactory().getImportedParameterBuilder().buildParameter(ieTemp, feature);
        role = ieTemp.getAttributeValue(AIFConstants.ROLE);
        if (role == null)
          throw new IllegalArgumentException("Can't find role attribute in Parameter element");
        params[nb++] = RoleWrapper.createRoleIdentifiedParameter(parameter, role);
      }
    }

    feature.initContainedElementsWith(features, params);

    return feature;
  }

}
