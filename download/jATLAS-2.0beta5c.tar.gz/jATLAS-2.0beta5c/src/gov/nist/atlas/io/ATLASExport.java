/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.io;

import gov.nist.atlas.Corpus;

import java.net.URL;


/**
 * <p>ATLASExport is responsible for Corpora exporting mechanism to persistent
 * data.</p>
 * <p>An ATLASExport implementation is responsible for persisting an ATLAS Corpus
 * to a given URL, no matter what the persistence modality
 * (XML files, RDBMS...) and format (such as AIF or any other proprietary
 * formats) are.<p>
 * <p>NOTE: Implementations <strong>MUST</strong> provide a public no-argument
 * constuctor so that the export module can be dynamically loaded.</p>
 *
 * @author Sylvain Pajot, Chris Laprun
 * @version $Revision: 1.6 $
 * @see gov.nist.atlas.io.xml.XMLExport
 */
public interface ATLASExport {
  /**
   * Saves a corpus to the persitent storage associated to this ATLASExport.
   *
   * @param corpus - The corpus to be saved in the ouput associated to this
   * ATLASExport.
   */
  void save(Corpus corpus);

  /**
   * Sets the destination URL for this ATLASExport.
   *
   * @param destination the URL where Corpora will be exported
   *
   * @since 2.0 beta 5
   */
  void setDestinationURL(URL destination);

  // Should it be added?
  //void save(Corpus corpus, URL location);
}



