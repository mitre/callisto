/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.io;

import gov.nist.atlas.Corpus;
import gov.nist.atlas.util.ATLASImplementation;


/**
 * AbstractATLASImport is a skeletal implementation of the ATLASImport
 * interface.
 *
 * <P>It introduces a two-phase mechanism to load a corpus from the data
 * it is associated to. First, the root node of an <CODE>ImportedElement</CODE> tree representing
 * the data (to build a corpus from) is retrieved. Then, the logic is recursively
 * performed on that tree to build the corresponding corpus.
 *
 * <P>AbstractATLASImport delegates the ImportedElement tree generation to an
 * ImportedElementLoader instance which has been specifically implemented for a specific
 * persistence modality...
 *
 * @author Sylvain Pajot, Chris Laprun
 * @version $Revision: 1.13 $
 *
 * @see gov.nist.atlas.io.ATLASImport
 * @see gov.nist.atlas.io.ImportedElement
 * @see gov.nist.atlas.io.ImportedElementLoader
 */
public abstract class AbstractATLASImport implements ATLASImport {
  public AbstractATLASImport() {
  }

  /**
   * Constructs an ATLASImport for the specified input file to import from,
   * using the given ATLASImplementation to build the corpus via the
   * correct factory.
   */
  public AbstractATLASImport(ImportedElementLoader loader, ATLASImplementation impl /*boolean validate*/) {
    importedElementLoader = loader;
    implementation = impl;
  }

  public void setATLASImplementation(ATLASImplementation implementation) {
    this.implementation = implementation;
  }

  public Corpus load() {
    ImportedElement ieRoot = getImportedCorpus();
    corpus = buildCorpus(ieRoot);
    return corpus;
  }

  public Corpus load(boolean shallowly) {
    corpus = buildCorpus(getImportedCorpus(), shallowly);
    return corpus;
  }

  /**
   * Extracts the corpus as an ImportedElement hierarchy from the file
   * associated to this ATLASImport.
   * It returns the root node a browsable hierarchy of ImportedElements
   * representing the corpus
   *
   * FIX-ME: should it really be there ?
   *
   * @return the ImportedElement corresponding to the root level of the corpus
   */
  protected ImportedElement getImportedCorpus() {
    return importedElementLoader.getImportedCorpus();
  }

  /**
   * Builds a <CODE>Corpus</CODE> from an ImportedElement tree defining it
   * (commonly provided by the <CODE>getImportedCorpus</CODE> method).
   * This method deals with the input format (that is, AIF, etc...) and has to
   * be implemented depending on it
   *
   * @param ieCorpus - The ImportedElement defining a corpus element
   * @return The corpus as an ATLASElement.
   */
  protected abstract Corpus buildCorpus(ImportedElement ieCorpus);

  protected abstract Corpus buildCorpus(ImportedElement ieCorpus, boolean shallowly);


  /** the module which is responsible for returning the root ImportedElement */
  protected ImportedElementLoader importedElementLoader;

  /** Associated corpus element */
  protected Corpus corpus;

  protected ATLASImplementation implementation;
}

