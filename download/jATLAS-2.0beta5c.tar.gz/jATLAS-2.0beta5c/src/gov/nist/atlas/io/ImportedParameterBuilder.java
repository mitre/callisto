/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.io;

import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Parameter;
import gov.nist.atlas.io.xml.AIFConstants;
import gov.nist.atlas.util.ATLASImplementation;

/**
 * ImportedParameterBuilder builds a Parameter from a matching ImportedElement
 *
 * Note that the ImportedElement well-defining the Parameter to create well is a prerequisite.
 * If the ImportedElement is not eligible for creating a Parameter, an IllegalArgumentException is
 * raised.
 *
 * @author Sylvain Pajot
 * @see ImportedElementBuilder
 */
public class ImportedParameterBuilder extends ImportedElementBuilder {

  public ImportedParameterBuilder(ATLASImplementation implementation, ImportedElementBuilderFactory parentFactory) {
    super(implementation, parentFactory);
  }

  public Parameter buildParameter(ImportedElement ieParameter, ATLASElement parent) {
    String parameterType = ieParameter.getAttributeValue(AIFConstants.TYPE),
        parameterUnit = ieParameter.getAttributeValue(AIFConstants.UNIT);
    if (parameterType == null)
      throw new IllegalArgumentException("Can't find type attribute in parameter element");
    if (parameterUnit == null)
      throw new IllegalArgumentException("Can't find unit attribute in parameter element");


    Parameter param = getATLASElementFactory().createParameter(parameterType, parent, parameterUnit, ieParameter.getTextTrim());

    if (param == null)
      throw new IllegalArgumentException("Can't create parameter");
    return param;
  }

}
