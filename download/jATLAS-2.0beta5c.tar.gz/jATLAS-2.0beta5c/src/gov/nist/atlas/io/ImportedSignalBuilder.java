/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.io;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Id;
import gov.nist.atlas.MIMEClass;
import gov.nist.atlas.Signal;
import gov.nist.atlas.SignalGroup;
import gov.nist.atlas.SimpleSignal;
import gov.nist.atlas.io.xml.AIFConstants;
import gov.nist.atlas.ref.ATLASRef;
import gov.nist.atlas.ref.SignalRef;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASImplementation;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

/**
 * ImportedSignalBuilder builds a Signal from a matching ImportedElement
 *
 * Note that the ImportedElement well-defining the Signal to create well is a prerequisite.
 * If the ImportedElement is not eligible for creating a Signal, an IllegalArgumentException is
 * raised.
 *
 * @author Sylvain Pajot
 * @see ImportedElementBuilder
 */
public class ImportedSignalBuilder extends ImportedElementBuilder {

  public ImportedSignalBuilder(ATLASImplementation implementation, ImportedElementBuilderFactory parentFactory) {
    super(implementation, parentFactory);
  }

  public SignalRef getSignalFromSignalRef(ImportedElement ieSignalRef, Corpus corpus, ATLASType signalType) {
    String href = ieSignalRef.getAttributeValueWithNamespace(AIFConstants.XLINKHREF, AIFConstants.XLINK);
    if (href == null)
      throw new IllegalArgumentException("Can't find href attribute in RegionRef element");
    if (href.equals(""))
      throw new IllegalArgumentException("Found empty href attribute in RegionRef element");
    String role = ieSignalRef.getAttributeValue(AIFConstants.ROLE);
    if (role == null)
      throw new IllegalArgumentException("Can't find role attribute in RegionRef element");
    return ATLASRef.createSignalRef(href, signalType, corpus, role);
  }


  public SignalGroup buildSignalGroup(ImportedElement ieSignalGroup, Corpus definingCorpus) {

    SignalGroup signalGroup;
    String signalGroupType = ieSignalGroup.getAttributeValue(AIFConstants.TYPE),
        signalGroupID = ieSignalGroup.getAttributeValue(AIFConstants.ID);

    if (signalGroupID == null)
      throw new IllegalArgumentException("Can't find id attribute in SignalGroup element");
    if (signalGroupType == null)
      throw new IllegalArgumentException("Can't find type attribute in SignalGroup element");


    Id tempId = getATLASElementFactory().resolveIdFor(signalGroupID);
    if (tempId == null) tempId = getATLASElementFactory().createNewIdFor(signalGroupID);
    signalGroup = getATLASElementFactory().createEmptySignalGroup(definingCorpus.resolveTypeFor(ATLASClass.SIGNAL, signalGroupType), definingCorpus, tempId);
    if (signalGroup == null)
      throw new IllegalArgumentException("Can't create SignalGroup");

    // create optional Metadata
    ImportedElement ieTemp = ieSignalGroup.getChild(AIFConstants.METADATA);
    //YOUHOU if (ieTemp != null) signalGroup.setMetadata(buildMetadata(ieTemp));
    if (ieTemp != null) signalGroup.setMetadata(getBuilderFactory().getImportedMetadataBuilder().buildMetadata(ieTemp));

    // reference signals
    List list = ieSignalGroup.getChildren(AIFConstants.SIGNALREF);
    if (list.size() == 0)
      throw new IllegalArgumentException("Can't find SignalRef elements in Signal Groups element");
    Iterator i = list.iterator();
    Signal signal;
    String signalRole;
    ATLASType t;
    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      signalRole = ieTemp.getAttributeValue(AIFConstants.ROLE);
      t = signalGroup.getATLASType().getTypeOfSubordinateWith(signalRole);
      if (signalRole == null)
        throw new IllegalArgumentException("Can't find role attribute in SignalRef element");
      //YOUHOU signalGroup.setSignalWithRole(getSignalFromSignalRef(ieTemp, definingCorpus, t), signalRole);
      signalGroup.setSignalWithRole(getBuilderFactory().getImportedSignalBuilder().getSignalFromSignalRef(ieTemp, definingCorpus, t), signalRole);
    }


    return signalGroup;
  }


  public SimpleSignal buildSimpleSignal(ImportedElement ieSimpleSignal, Corpus definingCorpus) {
    SimpleSignal simpleSignal;
    String simpleSignalType = ieSimpleSignal.getAttributeValue(AIFConstants.TYPE),
        simpleSignalID = ieSimpleSignal.getAttributeValue(AIFConstants.ID),
        simpleSignalMimeClass = ieSimpleSignal.getAttributeValue(AIFConstants.MIMECLASS),
        simpleSignalMimeType = ieSimpleSignal.getAttributeValue(AIFConstants.MIMETYPE),
        simpleSignalEncoding = ieSimpleSignal.getAttributeValue(AIFConstants.ENCODING),
        simpleSignalTrack = ieSimpleSignal.getAttributeValue(AIFConstants.TRACK),
        simpleSignalXlinkHref = ieSimpleSignal.getAttributeValueWithNamespace(AIFConstants.XLINKHREF, AIFConstants.XLINK);
    // FIX-ME : is it necessary ?
    //simpleSignalXlinkType =
    // ieSimpleSignal.getAttributeValueWithNamespace(TOKEN_ATTRIBUTE_SIMPLESIGNAL_XLINKTYPE,
    // NAMESPACE_XLINK);

    if (simpleSignalType == null)
      throw new IllegalArgumentException("Can't find type attribute in SimpleSignal element");
    if (simpleSignalID == null)
      throw new IllegalArgumentException("Can't find id attribute in SimpleSignal element");
    if (simpleSignalMimeClass == null)
      throw new IllegalArgumentException("Can't find mimeClass attribute in SimpleSignal element");
    if (simpleSignalMimeType == null)
      throw new IllegalArgumentException("Can't find mimeType attribute in SimpleSignal element");
    if (simpleSignalEncoding == null)
      throw new IllegalArgumentException("Can't find encoding attribute in SimpleSignal element");
    if (simpleSignalTrack == null)
      throw new IllegalArgumentException("Can't find track attribute in SimpleSignal element");
    // FIX-ME
    if (simpleSignalXlinkHref == null)
      throw new IllegalArgumentException("Can't find xlink:href attribute in SimpleSignal element");
    //if (simpleSignalXlinkType == null) throw
    // IllegalArgumentException("Can't find xlink:type attribute in SimpleSignal element");

    Id tempId = getATLASElementFactory().resolveIdFor(simpleSignalID);
    if (tempId == null) tempId = getATLASElementFactory().createNewIdFor(simpleSignalID);
    URL url;
    try {
      url = new URL(simpleSignalXlinkHref);
    } catch (MalformedURLException mue) {
      System.out.println("Malformed URL format [ImportedSignalBuilder]");
      // need more effective error handling
      return null;
    }
    MIMEClass mimeClass = MIMEClass.getMIMEClassFor(simpleSignalMimeClass);

    simpleSignal = getATLASElementFactory().createSimpleSignal(definingCorpus.resolveTypeFor(ATLASClass.SIGNAL, simpleSignalType), definingCorpus, tempId, mimeClass, simpleSignalMimeType, simpleSignalEncoding, simpleSignalTrack, url);

    // FIX-ME
    if (simpleSignal == null) throw new IllegalArgumentException("Can't create signal");

    // create optional Metadata
    ImportedElement tempMetadata = ieSimpleSignal.getChild(AIFConstants.METADATA);
    if (tempMetadata != null)
    //YOUHOU simpleSignal.setMetadata(buildMetadata(tempMetadata));
      simpleSignal.setMetadata(getBuilderFactory().getImportedMetadataBuilder().buildMetadata(tempMetadata));

    return simpleSignal;
  }

}
