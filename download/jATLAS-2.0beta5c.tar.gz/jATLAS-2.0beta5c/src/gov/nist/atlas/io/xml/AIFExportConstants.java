/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.io.xml;


/**
 * This interface wraps the used tags for AIF exporting.
 *
 * @author Chris Laprun, Sylvain Pajot
 * @version $Revision: 1.9 $
 */
public interface AIFExportConstants extends AIFConstants {
  String LT = "<";
  String GT = ">";
  String SLASH = "/";
  String EQ = "='";
  String QUOTE = "'";
  String SPACE = " ";
  String INDENT = "  ";
  String BR = "\n";
  String BR2 = "\n\n";
  String CLOSE_NOBR = QUOTE + GT; // '>
  String CLOSE = CLOSE_NOBR + BR;
  String EMPTY_CLOSE = QUOTE + SLASH + GT + BR; // '/>\n

  // Tag start
  String ANALYSIS_S = LT + ANALYSIS + SPACE + ID + EQ; // <Analysis id='
  String ANCHOR_S = LT + ANCHOR + SPACE + ID + EQ; // <Anchor id='
  String ANNOTATION_S = LT + ANNOTATION + SPACE + ID + EQ; // <Annotation id='
  String CONTENT_S = LT + CONTENT + SPACE + TYPE + EQ; // <Content type='
  String CORPUS_S = LT + CORPUS + SPACE + ID + EQ; // <Corpus id='
  String FEATURE_S = LT + FEATURE + SPACE + TYPE + EQ; // <Feature type='
  String METADATA_S = LT + METADATA + SPACE + TYPE + EQ; // <Metadata type='
  String PARAMETER_S = LT + PARAMETER + SPACE + TYPE + EQ; // <Parameter type='
  String REGION_S = LT + REGION + SPACE + ID + EQ; // <Region id='
  String SIMPLESIGNAL_S = LT + SIMPLESIGNAL + SPACE + ID + EQ; // <SimpleSignal id='
  String SIGNALGROUP_S = LT + SIGNALGROUP + SPACE + ID + EQ; // <SignalGroup id='

  String REGION_DEF_CHILDREN = LT + REGIONDEFINEDBYCHILDREN + SPACE
      + WITHCONTAINEDTYPE + EQ;
  String CONTENT_DEF_CHILDREN = LT + CONTENTDEFINEDBYCHILDREN + SPACE
      + WITHCONTAINEDTYPE + EQ;

  String EMPTY_METADATA = LT + METADATA + SLASH + GT + BR;

  // Tag end
  String ANALYSIS_E = LT + SLASH + ANALYSIS + GT + BR; // </Analysis>\n
  String ANCHOR_E = LT + SLASH + ANCHOR + GT + BR;
  String ANNOTATION_E = LT + SLASH + ANNOTATION + GT + BR;
  String CONTENT_E = LT + SLASH + CONTENT + GT + BR;
  String CORPUS_E = LT + SLASH + CORPUS + GT + BR;
  String FEATURE_E = LT + SLASH + FEATURE + GT + BR;
  String METADATA_E = LT + SLASH + METADATA + GT + BR;
  String PARAMETER_E = LT + SLASH + PARAMETER + GT + BR;
  String REGION_E = LT + SLASH + REGION + GT + BR;
  String SIMPLESIGNAL_E = LT + SLASH + SIMPLESIGNAL + GT + BR;
  String SIGNALGROUP_E = LT + SLASH + SIGNALGROUP + GT + BR;

  String AIFVERSION_ATT = QUOTE + SPACE + AIFVERSION + EQ; // ' aifVersion='
  String TYPE_ATT = QUOTE + SPACE + TYPE + EQ; // ' type='
  String SCHEMELOC_ATT = QUOTE + SPACE + SCHEMELOC + EQ; // ' schemeLocation='
  String ROLE_ATT = QUOTE + SPACE + ROLE + EQ; // ' role='
  String WITH_ROLE = QUOTE + SPACE + WITHROLE + EQ; // ' withRole='
  String UNIT_ATT = QUOTE + SPACE + UNIT + EQ; // ' unit='
  String TRACK_ATT = QUOTE + SPACE + TRACK + EQ; // ' track='
  String LOCATION_ATT = "' xlink:href='";

  String XML_INFO = "<?xml version='1.0'?>\n<!DOCTYPE Corpus SYSTEM 'http://www.nist.gov/speech/atlas/aif.dtd'>\n\n";
  String NAMESPACE_INFO = "' xmlns='http://www.nist.gov/speech/atlas' xmlns:xlink='http://www.w3.org/1999/xlink'>\n\n";
}



