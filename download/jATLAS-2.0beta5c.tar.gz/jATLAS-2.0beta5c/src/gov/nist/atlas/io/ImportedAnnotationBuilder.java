/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.io;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.Analysis;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Feature;
import gov.nist.atlas.Id;
import gov.nist.atlas.Parameter;
import gov.nist.atlas.Region;
import gov.nist.atlas.io.xml.AIFConstants;
import gov.nist.atlas.ref.ATLASRef;
import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.AnnotationType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.RoleIdentifiedFeature;
import gov.nist.atlas.util.RoleIdentifiedParameter;
import gov.nist.atlas.util.RoleWrapper;

import java.util.Iterator;
import java.util.List;

/**
 * ImportedAnnotationBuilder builds an Annotation from a matching ImportedElement
 *
 * Note that the ImportedElement well-defining the Annotation to create is a prerequisite.
 * If the ImportedElement is not eligible for creating an Annotation, an IllegalArgumentException is
 * raised.
 *
 * @author Sylvain Pajot, Chris Laprun
 * @version $Revision: 1.13 $
 * @see ImportedElementBuilder
 */
public class ImportedAnnotationBuilder extends ImportedElementBuilder {

  public ImportedAnnotationBuilder(ATLASImplementation implementation, ImportedElementBuilderFactory parentFactory) {
    super(implementation, parentFactory);
  }


  public Annotation buildAnnotation(ImportedElement ieAnnotation, Analysis parentAnalysis) {
    Annotation annotation;
    String annotationID = ieAnnotation.getAttributeValue(AIFConstants.ID),
        annotationType = ieAnnotation.getAttributeValue(AIFConstants.TYPE);
    if (annotationID == null)
      throw new IllegalArgumentException("Can't find id attribute in Annotation Element");
    if (annotationID.equals(""))
      throw new IllegalArgumentException("Found empty id attribute in Annotation Element");
    if (annotationType == null)
      throw new IllegalArgumentException("Can't find type attribute in Annotation Element");
    /*if (!annotationType.equals(type))
      throw new IllegalArgumentException("Incompatible types AnnotationSet/Annotation");*/

    // Region
    boolean bRegionDefinedByChildren = false;
    String xlink = null;
    String role = null;
    ImportedElement ieTemp = ieAnnotation.getChild(AIFConstants.REGIONREF);
    if (ieTemp != null) {
      xlink = ieTemp.getAttributeValueWithNamespace(AIFConstants.XLINKHREF, AIFConstants.XLINK);
      if (xlink == null)
        throw new IllegalArgumentException("Can't find href attribute in RegionRef element");
      if (xlink.equals(""))
        throw new IllegalArgumentException("Found empty href attribute in RegionRef element");
      role = ieTemp.getAttributeValue(AIFConstants.ROLE);
      if (role == null)
        throw new IllegalArgumentException("Can't find role attribute in RegionRef element");
      if (role.equals(""))
        throw new IllegalArgumentException("Found empty role attribute in RegionRef element");
    } else {
      ieTemp = ieAnnotation.getChild(AIFConstants.REGIONDEFINEDBYCHILDREN);
      if (ieTemp == null)
        throw new IllegalArgumentException("Neither RegionRef nor RegionDefinedByChildren were found in Annotation Element");
      bRegionDefinedByChildren = true;
    }

    // Content
    boolean bContentDefinedByChildren = false;
    ieTemp = ieAnnotation.getChild(AIFConstants.CONTENT);
    if (ieTemp == null) {
      ieTemp = ieAnnotation.getChild(AIFConstants.CONTENTDEFINEDBYCHILDREN);
      if (ieTemp == null)
        throw new IllegalArgumentException("Neither Content nor ContentDefinedByChildren were found in Annotation Element");
      bContentDefinedByChildren = true;
    }

    Id tempId = getATLASElementFactory().resolveIdFor(annotationID); // FIX ME
    if (tempId == null) tempId = getATLASElementFactory().createNewIdFor(annotationID);
    ATLASType tempType = parentAnalysis.getDefiningCorpus().resolveTypeFor(ATLASClass.ANNOTATION, annotationType);

    if (bRegionDefinedByChildren)
      if (bContentDefinedByChildren)
        annotation = getATLASElementFactory().createPrimalAnnotation(tempType, parentAnalysis, tempId, null, null);
      else
        annotation = getATLASElementFactory().createPrimalAnnotation(tempType, parentAnalysis, tempId, (ATLASElementSet) null);
    else {
      ATLASType at = parentAnalysis.getDefiningCorpus().resolveTypeFor(ATLASClass.ANNOTATION, annotationType);
      ATLASType rt = at.getTypeOfSubordinateWith(role);
      annotation = getATLASElementFactory().createEmptyAnnotation(tempType, parentAnalysis, tempId, ATLASRef.createRegionRef(xlink, rt, parentAnalysis.getDefiningCorpus(), role));
    }

    if (annotation == null)
      throw new IllegalArgumentException("Can't create Annotation");

    // Content initialization
    // ieTemp still references the Content ImportedElement then
    if (!bContentDefinedByChildren)
      initContentOfAnnotation(annotation, ieTemp);
    else
      annotation.replaceContentByChildrenContent();

    if (bRegionDefinedByChildren)
      annotation.replaceRegionByChildrenRegion();

    // Children
    Iterator i = ieAnnotation.getChildren(AIFConstants.CHILDREN).iterator();
    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      addAnnotationsFromChildrenTo(annotation, ieTemp);
    }


    return annotation;
  }


  public Annotation getAnnotationFromAnnotationRef(ImportedElement ieAnnotationRef, Corpus corpus, ATLASType annotationType) {
    String href = ieAnnotationRef.getAttributeValueWithNamespace(AIFConstants.XLINKHREF, AIFConstants.XLINK);
    if (href == null)
      throw new IllegalArgumentException("Can't find href attribute in RegionRef element");
    if (href.equals(""))
      throw new IllegalArgumentException("Found empty href attribute in RegionRef element");
    String role = ieAnnotationRef.getAttributeValue(AIFConstants.ROLE);
    if (role == null)
      throw new IllegalArgumentException("Can't find role attribute in RegionRef element");
    // FIX-ME : test for empty role ?
    return ATLASRef.createAnnotationRef(href, annotationType, corpus, role);
  }


  public void addAnnotationsFromAnnotationRefSetTo(Region parentRegion, ImportedElement ieAnnotationRefSet) {
    Annotation annotation;
    List list = ieAnnotationRefSet.getChildren(AIFConstants.ANNOTATIONREF);
    if (list.size() == 0)
      //throw new IllegalArgumentException("Can't find AnnotationRef elements in AnnotationRefSet element");
      return; // changed by RobynK
    Iterator i = list.iterator();
    ImportedElement ieTemp;
    String role;
    String type = ieAnnotationRefSet.getAttributeValue(AIFConstants.CONTAINEDTYPE);
    if (type == null)
      throw new IllegalArgumentException("Can't find containedType attribute in AnnotationRefSet element");
    if (type.equals(""))
      throw new IllegalArgumentException("Found empty type attribute in AnnotationRefSet element");
    ATLASType t = parentRegion.getDefiningCorpus().resolveTypeFor(ATLASClass.ANNOTATION, type);

    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      role = ieTemp.getAttributeValue(AIFConstants.ROLE);
      if (role == null)
        throw new IllegalArgumentException("Can't find role attribute in AnnotationRef element");
      annotation = getAnnotationFromAnnotationRef(ieTemp, parentRegion.getDefiningCorpus(), t);
      if (!(annotation.getATLASType().equals(t)))
        throw new IllegalArgumentException("Incompatible type for AnnotationRefSet/Annotation");
      // FIX-ME : name of addition method ("withRole" ??)
      if (!parentRegion.addAnnotation(annotation))
        throw new IllegalArgumentException("Can't add AnnotationRef to Region");

    }
  }


  private void initContentOfAnnotation(Annotation parentAnnotation, ImportedElement ieContent) {

    String role;
    RegionRef regionRef = null;

    // RegionRef
    ImportedElement ieTemp = ieContent.getChild(AIFConstants.REGIONREF);
    if (ieTemp != null) {
      String xlink = ieTemp.getAttributeValueWithNamespace(AIFConstants.XLINKHREF, AIFConstants.XLINK);
      if (xlink == null)
        throw new IllegalArgumentException("Can't find href attribute in RegionRef element (from Content)");
      if (xlink.equals(""))
        throw new IllegalArgumentException("Found empty href attribute in RegionRef element (from Content)");
      role = ieTemp.getAttributeValue(AIFConstants.ROLE);
      if (role == null)
        throw new IllegalArgumentException("Can't find role attribute in RegionRef element (from Content)");
      AnnotationType parentType = parentAnnotation.getAnnotationType();
      ATLASType rt = parentType
          .getTypeOfSubordinateWith(parentType.getRoleForContent())
          .getTypeOfSubordinateWith(role);
      regionRef = ATLASRef.createRegionRef(xlink, rt, parentAnnotation.getDefiningCorpus(), role);
    }

    // Features
    List list = ieContent.getChildren(AIFConstants.FEATURE);
    int nb = list.size();
    RoleIdentifiedFeature[] features = null;
    Iterator i;
    if (nb > 0) {
      features = new RoleIdentifiedFeature[nb];
      i = list.iterator();
      nb = 0;
      Feature feature;
      while (i.hasNext()) {
        ieTemp = (ImportedElement) i.next();
        feature = getBuilderFactory().getImportedFeatureBuilder().buildFeature(ieTemp, parentAnnotation.getContent());
        role = ieTemp.getAttributeValue(AIFConstants.ROLE);
        if (role == null)
          throw new IllegalArgumentException("Can't find role attribute in Feature element");
        features[nb++] = RoleWrapper.createRoleIdentifiedFeature(feature, role);
      }
    }

    // Parameters
    list = ieContent.getChildren(AIFConstants.PARAMETER);
    nb = list.size();
    RoleIdentifiedParameter[] params = null;
    if (nb > 0) {
      params = new RoleIdentifiedParameter[nb];
      i = list.iterator();
      nb = 0;
      Parameter parameter;
      while (i.hasNext()) {
        ieTemp = (ImportedElement) i.next();
        //YOUHOU parameter = buildParameter(ieTemp, parentAnnotation.getContent());
        parameter = getBuilderFactory().getImportedParameterBuilder().buildParameter(ieTemp, parentAnnotation.getContent());
        role = ieTemp.getAttributeValue(AIFConstants.ROLE);
        if (role == null)
          throw new IllegalArgumentException("Can't find role attribute in Parameter element");
        params[nb++] = RoleWrapper.createRoleIdentifiedParameter(parameter, role);
      }
    }

    parentAnnotation.initContentWith(features, params, regionRef);
  }


  private void addAnnotationsFromChildrenTo(Annotation parentAnnotation, ImportedElement ieChildren) {
    Annotation annotation;
    Iterator i = ieChildren.getChildren(AIFConstants.ANNOTATIONREF).iterator();
    ImportedElement ieTemp;
    String role;
    String type = ieChildren.getAttributeValue(AIFConstants.CONTAINEDTYPE);
    if (type == null)
      throw new IllegalArgumentException("Can't find containedType attribute in Children element");
    if (type.equals(""))
      throw new IllegalArgumentException("Found empty type attribute in Children element");
    ATLASType t = parentAnnotation.getDefiningCorpus().resolveTypeFor(ATLASClass.ANNOTATION, type);

    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      role = ieTemp.getAttributeValue(AIFConstants.ROLE);
      if (role == null)
        throw new IllegalArgumentException("Can't find role attribute in AnnotationRef element");
      annotation = getAnnotationFromAnnotationRef(ieTemp, parentAnnotation.getDefiningCorpus(), t);
      if (!(annotation.getATLASType().equals(t)))
        throw new IllegalArgumentException("Incompatible type for AnnotationRefSet/Annotation");

      if (!parentAnnotation.addToChildrenWithRole(annotation, role))
        throw new IllegalArgumentException("Can't add AnnotationRef to Children");

    }
  }


  public void buildAnnotationsFromAnnotationSet(ImportedElement ieAnnotationSet, Analysis parentAnalysis) {
    Iterator i = ieAnnotationSet.getChildren(AIFConstants.ANNOTATION).iterator();
    ImportedElement ieAnnotation;
    String type = ieAnnotationSet.getAttributeValue(AIFConstants.CONTAINEDTYPE);
    if (type == null)
      throw new IllegalArgumentException("Can't find containedType attribute in AnnotationSet element");
    if (type.equals(""))
      throw new IllegalArgumentException("Found empty string for containedType in AnnotationSet element");
    while (i.hasNext()) {
      ieAnnotation = (ImportedElement) i.next();
      //YOUHOU buildAnnotation(ieAnnotation, parentAnalysis, type);
      buildAnnotation(ieAnnotation, parentAnalysis);
    }
  }

}
