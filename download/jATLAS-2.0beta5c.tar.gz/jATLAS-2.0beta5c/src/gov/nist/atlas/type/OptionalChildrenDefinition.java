/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.type;


public class OptionalChildrenDefinition {
  public final boolean canAdd() {
    return canAdd;
  }

  public final boolean canRemove() {
    return canRemove;
  }

  public final boolean sortable() {
    return sortable;
  }

  public final boolean byId() {
    return byId;
  }

  public final ATLASType getType() {
    return type;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer("[ ");
    if (canAdd)
      sb.append("canAdd ");
    if (canRemove)
      sb.append("canRemove ");
    if (sortable)
      sb.append("sortable ");
    if (byId)
      sb.append("byId ");
    return sb.append("]").toString();
  }

  protected OptionalChildrenDefinition(ATLASType typeOfOptionalChildren, boolean canAdd, boolean canRemove, boolean sortable, boolean byId) {
    this.canAdd = canAdd;
    this.canRemove = canRemove;
    this.sortable = sortable;
    this.byId = byId;
    type = typeOfOptionalChildren;
  }

  protected final boolean canAdd;
  protected final boolean canRemove;
  protected final boolean sortable;
  protected final boolean byId;
  protected final ATLASType type;
}



