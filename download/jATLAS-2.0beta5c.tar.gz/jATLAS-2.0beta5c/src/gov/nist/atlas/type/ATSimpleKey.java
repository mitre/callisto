/*
 * MAIA
 * Meta-Annotation Infrastructure for ATLAS
 * Author: Chris Laprun
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.type;

import gov.nist.atlas.ATLASClass;


public class ATSimpleKey implements Comparable {
  ATSimpleKey(ATLASClass clazz, String role) {
    hash = HashUtility.computeSimpleHashFor(clazz, role);
    this.clazz = clazz;
    this.role = role;
  }

  public int compareTo(Object other) {
    if (other == this)
      return 0;
    ATSimpleKey key = (ATSimpleKey) other;
    int result = clazz.compareTo(key.clazz);
    return ((result != 0) ? result : role.compareTo(key.role));
  }

  public ATLASClass getATLASClass() {
    return clazz;
  }

  public String getRole() {
    return role;
  }

  public int hashCode() {
    return hash;
  }

  public String toString() {
    return "(" + clazz.getName() + ", " + role + ")";
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;
    return (o.hashCode() == hash && o instanceof ATSimpleKey);
  }

  // can be a problem when hash is reset... decide what to do!
  void setHash(ATLASClass clazz, String role) {
    hash = HashUtility.computeSimpleHashFor(clazz, role);
    this.clazz = clazz;
    this.role = role;
  }

  private int hash;
  private ATLASClass clazz;
  private String role;
}



