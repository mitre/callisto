/*
 * MAIA
 * Meta-Annotation Infrastructure for ATLAS
 * Author: Chris Laprun
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.type;

public class ATMultipleKey implements Comparable {
  ATMultipleKey(ATLASType type, String role) {
    this.type = type;
    this.role = role;
    hash = HashUtility.computeMultipleHashFor(type, role);
  }

  public int compareTo(Object other) {
    if (other == this)
      return 0;
    ATMultipleKey key = (ATMultipleKey) other;
    if (hash == 0)
      return (key.hash == 0) ? 0 : -1;
    int result = type.compareTo(key.type);
    return ((result != 0) ? result : role.compareTo(key.role));
  }

  public int hashCode() {
    return hash;
  }

  public ATLASType getType() {
    return type;
  }

  public String getRole() {
    return role;
  }

  void setHash(ATLASType type, String role) {
    this.type = type;
    this.role = role;
    hash = HashUtility.computeMultipleHashFor(type, role);
  }

  public boolean equals(Object o) {
    if (this == o)
      return true;
    return (o.hashCode() == hash && o instanceof ATMultipleKey);
  }

  public String toString() {
    return "(" + ((type != null) ? type.getName() : null) + ", " + role + ")";
  }

  private int hash;
  private ATLASType type;
  private String role;
}



