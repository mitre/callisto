/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.type.AnchorType;
import gov.nist.atlas.util.RoleIdentifiedParameter;


/**
 * An abstraction for a "coordinate" in the space defined by a SimpleSignal or
 * a SignalGroup. Anchors are reusable elements that are used to define the
 * boundaries of Regions. If Regions define "areas" in a Signal space, Anchors
 * provide the "points" that describe how these Regions are built.<br>
 *
 * Anchors provide the link between the specifities of Signals and the
 * higher-level constructs that Regions are thus freeing these from having to
 * handle the details of actually "carving out" an area in the Signal.<br>
 * Role-identified Parameter elements are used to define the values of
 * the "coordinates".
 *
 * @version $Revision: 1.20 $
 * @author Christophe Laprun
 *
 * @see Parameter
 * @see Signal
 * @see SimpleSignal
 * @see SignalGroup
 * @see Region
 */
public interface Anchor extends ReusableATLASElement, ParametersHolder {
  /**
   * <p>Initializes the content of subordinate Parameters to the specified
   * values. The specified parameters are
   * role-identified, this Anchor's type is thus able to correctly assign them
   * to their proper subordinate. Some validation is performed at this level
   * since it is not possible to assign an invalid ATLASElement to
   * a given subordinate.</p>
   *
   * <p><strong>Notes:</p> <ul> <li>The final error mechanism hasn't been
   * specified yet but this method should be atomic: either
   * all assignments are made or none.</li>
   * <li>The subordinates that are specified as arguments to this method are
   * element with FINITE cardinality.
   * Subordinates with undetermined cardinality are assigned using other,
   * appropriate methods.</li> </ul> </strong>
   *
   * @param parameters the role-identified parameters to be assigned
   * to subordinates
   *
   * @see gov.nist.atlas.util.RoleIdentifiedParameter
   *
   * @deprecated Move to SPI
   */
  void initContainedElementsWith(RoleIdentifiedParameter[] parameters);

  /**
   * Returns this Anchor's type as an AnchorType object.
   *
   * @return the AnchorType assigned to this Anchor
   */
  AnchorType getAnchorType();

  /**
   * Returns the Signal to which this Anchor is anchored.
   *
   * @return the Signal to which this Anchor is anchored
   */
  Signal getSignal();

  /**
   * @clientCardinality 1..*
   * @label references
   */

  /*#Signal lnkSignal;*/

  /**
   * @supplierCardinality 1..*
   * @link aggregationByValue
   */

  /*#Parameter lnkParameter;*/
}

