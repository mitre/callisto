/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.event.ContentChangeEvent;
import gov.nist.atlas.event.ContentChangeListener;
import gov.nist.atlas.event.ContentChangedVetoException;
import gov.nist.atlas.event.ContentWillChangeListener;

import java.util.Iterator;
import java.util.Vector;


/**
 * AbstractValidatable provides a default implementation for the behavior
 * defined by Validatable.
 *
 * @version $Revision: 1.11 $
 * @author Christophe Laprun
 */
abstract public class AbstractValidatable implements Validatable {
  public boolean enableValidation(boolean enable) {
    boolean old = validationEnabled;
    validationEnabled = enable;
    return old;
  }

  public boolean isValidationEnabled() {
    return validationEnabled;
  }

  public boolean isValidated() {
    return validated;
  }

  public ValidationResult validate() {
    ConstraintSet cs = getConstraintManager().getEnabledConstraints();
    ValidationResult[] results = new ValidationResult[cs.size()];
    Constraint constraint = null;
    int i = 0;
    Iterator iter = cs.iterator();
    while (iter.hasNext()) {
      constraint = (Constraint) iter.next();
      results[i++] = constraint.validate(this);
    }
    return ValidationResult.merge(results);
  }

  public synchronized void removeContentChangeListener(ContentChangeListener l) {
    if (contentChangeListeners != null && contentChangeListeners.contains(l)) {
      Vector v = (Vector) contentChangeListeners.clone();
      v.removeElement(l);
      contentChangeListeners = v;
    }
  }

  public synchronized void addContentChangeListener(ContentChangeListener l) {
    Vector v = contentChangeListeners == null ? new Vector(2) : (Vector) contentChangeListeners.clone();
    if (!v.contains(l)) {
      v.addElement(l);
      contentChangeListeners = v;
    }
  }

  public synchronized void removeContentWillChangeListener(ContentWillChangeListener l) {
    if (contentWillChangeListeners != null && contentWillChangeListeners.contains(l)) {
      Vector v = (Vector) contentWillChangeListeners.clone();
      v.removeElement(l);
      contentWillChangeListeners = v;
    }
  }

  public synchronized void addContentWillChangeListener(ContentWillChangeListener l) {
    Vector v = contentWillChangeListeners == null ? new Vector(2) : (Vector) contentWillChangeListeners.clone();
    if (!v.contains(l)) {
      v.addElement(l);
      contentWillChangeListeners = v;
    }
  }

  protected void fireContentChange(ContentChangeEvent e) {
    if (contentChangeListeners != null) {
      Vector listeners = contentChangeListeners;
      int count = listeners.size();
      for (int i = 0; i < count; i++) {
        ((ContentChangeListener) listeners.elementAt(i)).contentChange(e);
      }
    }
  }

  protected void fireContentWillChange(ContentChangeEvent e) throws ContentChangedVetoException {
    if (contentWillChangeListeners != null) {
      Vector listeners = contentWillChangeListeners;
      int count = listeners.size();
      for (int i = 0; i < count; i++) {
        ((ContentWillChangeListener) listeners.elementAt(i)).contentWillChange(e);
      }
    }
  }

  /**
   * Returns the ConstraintManager associated with this Validatable.
   *
   * @return the ConstraintManager associated with this Validatable
   *
   * @see ConstraintManager
   *
   * @deprecated Move to SPI
   */
  protected abstract ConstraintManager getConstraintManager();

  private boolean validationEnabled = false;
  private boolean validated = false;

  /**
   * the list of listener
   */
  private transient Vector contentChangeListeners;
  private transient Vector contentWillChangeListeners;
}


