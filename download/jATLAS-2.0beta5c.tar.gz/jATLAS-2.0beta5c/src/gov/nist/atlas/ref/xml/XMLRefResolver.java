/*
 * Project name
 * Project description
 * Author: author name
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.ref.xml;


import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.CorporaManager;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.ReusableATLASElement;
import gov.nist.atlas.io.ImportedAnchorBuilder;
import gov.nist.atlas.io.ImportedAnnotationBuilder;
import gov.nist.atlas.io.ImportedCorpusBuilder;
import gov.nist.atlas.io.ImportedElement;
import gov.nist.atlas.io.ImportedElementBuilder;
import gov.nist.atlas.io.ImportedElementBuilderFactory;
import gov.nist.atlas.io.ImportedRegionBuilder;
import gov.nist.atlas.io.xml.AIFConstants;
import gov.nist.atlas.io.xml.XMLImportedElement;
import gov.nist.atlas.ref.AbstractRefResolver;
import gov.nist.atlas.util.ATLASImplementationManager;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.XPath;
import org.dom4j.io.SAXReader;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * XMLRefResolver is the implementation of the <CODE>RefResolver</CODE>
 * interface dedicated to XML external references (that is, an xlink not
 * beginning with a '#'). An external reference refers to a ReusableATLASElement
 * defined in a different corpus than the one the reference is located in.
 *
 * @author Christophe Laprun, Sylvain Pajot
 * @version $Revision: 1.21 $
 *
 * @see gov.nist.atlas.ref.AbstractRefResolver
 */
public class XMLRefResolver extends AbstractRefResolver {
  public XMLRefResolver() {
    ImportedElementBuilderFactory factory;
    factory = ImportedElementBuilderFactory.getFactoryFor(ATLASImplementationManager.getDefaultImplementation());
    builders.put(ATLASClass.ANCHOR, factory.getImportedAnchorBuilder());
    builders.put(ATLASClass.ANNOTATION, factory.getImportedAnnotationBuilder());
    builders.put(ATLASClass.REGION, factory.getImportedRegionBuilder());
    builders.put(ATLASClass.CORPUS, factory.getImportedCorpusBuilder());
  }

  public final boolean acceptXLink(String xlink, Corpus corpus) {
    int length = xlink.length();
    if (!super.acceptXLink(xlink, corpus) || length <= 8)
      return false;

    int idIndex = xlink.indexOf('#');
    if ((idIndex == -1) || (idIndex == length - 1))
      return false;

    return xlink.regionMatches(true, idIndex - 8, AIF_EXT, 0, 8);
  }

  public final boolean isLocal() {
    return false;
  }

  // add containing corpus parameter?
  public ReusableATLASElement getElement(String xlink, ATLASClass expectedClass, Corpus containingCorpus) {
    //		checkParameters(parent, expectedClass);
    URL corpusLocation = null;
    URI elementURI = parseXLink(xlink);

    // retrieve the target Corpus location
    try {
      corpusLocation = new URL(elementURI.getScheme(), elementURI.getHost(), elementURI.getPath());
    } catch (MalformedURLException e) {
      e.printStackTrace();
    }
    ReusableATLASElement rae = null;

    String id = elementURI.getFragment();

    // First try to see if the Corpus has already been loaded
    Corpus definingCorpus = CorporaManager.getRegisteredCorpusWith(corpusLocation.toExternalForm());

    if (definingCorpus != null)
    // Corpus was loaded, let's get the element directly!
      return definingCorpus.getReusableElementWith(expectedClass, id);

    System.out.println("Corpus " + corpusLocation + " wasn't loaded...");
    // Corpus wasn't loaded, we need to build it 'shallowly' from XML...
    Document doc = null;
    ImportedElement ieCorpus = null;
    try {
      doc = new SAXReader().read(corpusLocation);
      ieCorpus = new XMLImportedElement(doc.getRootElement());
    } catch (DocumentException e) {
      System.out.println(e.getMessage());
      return null;
    }
    definingCorpus = ((ImportedCorpusBuilder) builders.get(ATLASClass.CORPUS)).buildCorpus(ieCorpus, corpusLocation, true);

    // ... then retrieve the appropriate XML node via XPath...
    String xpathString = new StringBuffer("//atlas:").append(expectedClass.getName())
        .append("[@id='").append(id).append("']").toString();
    XPath xpath = doc.createXPath(xpathString);
    Map uris = new HashMap();
    uris.put("atlas", "http://www.nist.gov/speech/atlas");
    xpath.setNamespaceURIs(uris);
    Node node = xpath.selectSingleNode(doc);

    // ... and finally build the ATLASElement from XML
    ImportedElementBuilder builder = (ImportedElementBuilder) builders.get(expectedClass);
    XMLImportedElement ie = null;
    if (node instanceof Element)
      ie = new XMLImportedElement((Element) node);

//      FIX ME:
//        - use polymorphism => refactor ImportedElementBuilder to present a common interface where possible
//          (at least for reusable elements)
//        - passing containingCorpus is WRONG but needed temporarily in order to test. The corpus that needs to be passed
//          is the defining Corpus which does NOT exist at this point: investigate ways to create it (or a skeletton of
//          it) and maintain a list of Corpora currently in memory.
//
    if (ATLASClass.ANCHOR.equals(expectedClass))
      rae = ((ImportedAnchorBuilder) builder).buildAnchor(ie, definingCorpus);
    else if (ATLASClass.REGION.equals(expectedClass))
      rae = ((ImportedRegionBuilder) builder).buildRegion(ie, definingCorpus);
    else if (ATLASClass.ANNOTATION.equals(expectedClass)) {
      Element parent = node.getParent().getParent();
      String analysisId = parent.attributeValue(AIFConstants.ID);
      rae = ((ImportedAnnotationBuilder) builder).buildAnnotation(ie, definingCorpus.getAnalysisWithId(analysisId));
    } else if (ATLASClass.SIGNAL.equals(expectedClass))
      rae = definingCorpus.getSignalWithId(id);

    return rae;
  }

  public static void main(String[] args) {
    XMLRefResolver resolver = new XMLRefResolver();


    if (args[0] == null) {
      System.err.println("Usage: java XMLRefResolver <xlink>");
      System.exit(-1);
    }

    System.out.println("Trying to retrieve the element identified by: " + args[0]);

    int N = 1;
    long time = 0;
    for (int i = 0; i < N; i++) {
      long t1 = System.currentTimeMillis();
      System.out.println("used mem before: " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()));
      System.out.println(resolver.getElement(args[0], ATLASClass.ANNOTATION, null).asAIFString()); // FIX-ME
      System.out.println("used mem after: " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()));
      long t2 = System.currentTimeMillis();
      time += t2 - t1;
      System.out.println("time: " + (t2 - t1) + "ms");
    }
    System.out.println("average time = " + time / N + "ms");
  }

  private static final String AIF_EXT = ".aif.xml";
  private static final Map builders = new HashMap(5);
}



