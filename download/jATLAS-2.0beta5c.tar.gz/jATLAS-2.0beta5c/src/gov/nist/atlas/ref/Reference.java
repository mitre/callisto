/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.ref;

import gov.nist.atlas.util.RoleAddressable;


/**
 * A Reference makes any ReusableATLASElements referencable, so that the user
 * is thus able to handle such ATLASElements wherever they are defined (in
 * either this reference's containing corpus or a different one).
 * <BR>ReusableATLASElements are Annotation, Anchor, Region, Signal.
 *
 * <P>It delegates the resolving mechanism (when a referenced
 * ReusableATLASElement is accessed) to a <CODE>RefResolver</CODE>.
 * <BR>As it is designed to comply with AIF, the Reference interface
 * uses XLinks to reference a ReusableATLASElement
 *
 *
 * @version $Revision: 1.8 $
 * @author Christophe Laprun, Sylvain Pajot
 *
 * @see gov.nist.atlas.util.RoleAddressable
 * @see RefResolver
 */
public interface Reference extends RoleAddressable {

  /**
   * Returns the RefResolver associated with this Reference. A Reference's
   * RefResolver is chosen based on the XLink of the element it points to.
   *
   * @return the RefResolver associated with this ATLASRef
   *
   * @see RefResolver
   */
  RefResolver getResolver();

  /**
   * Returns the XLink of the element this ATLASRef points to.
   *
   * @return the XLink of the element this ATLASRef points to
   */
  String getXLink();

  /**
   * Determines if this Reference is an internal reference or a reference to an
   * element located in an external Corpus.
   *
   * @return <code>true</code> if this Reference points to an element located
   * in the same Corpus, <code>false</code> if it points to an element located
   * in a different Corpus
   */
  boolean isLocal();
}