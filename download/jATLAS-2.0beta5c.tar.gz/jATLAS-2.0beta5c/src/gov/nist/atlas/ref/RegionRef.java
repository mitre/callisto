/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.ref;

import gov.nist.atlas.Region;


/**
 * RegionRef is a <CODE>Reference</CODE> to a <CODE>Region</CODE>.
 * By implementing the Region interface, this reference can be assimilated to
 * the region it points to and can be accessed the same way.
 *
 * @author Christophe Laprun, Sylvain Pajot
 * @version $Revision: 1.7 $
 * @see gov.nist.atlas.Region
 * @see gov.nist.atlas.ref.Reference
 */
public interface RegionRef extends Reference, Region {
}



