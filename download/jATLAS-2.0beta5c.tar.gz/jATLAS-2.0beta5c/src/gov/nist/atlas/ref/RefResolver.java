/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.ref;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.ReusableATLASElement;


/**
 * A RefResolver is an accessor to ReusableATLASElements (that is Annotation,
 * Region, Signal, Anchor) that are referred using AIF references (XML Xlinks).
 *
 * <P>These refered ReusableATLASElements can be located in either the same
 * corpus than the reference's containing corpus (internal references) or a
 * different one (external references).
 *
 * <P>Usually, a RefResolver is not instanciated with a call to the constructor
 * of its concrete class, but rather by using a <CODE>RefResolverChooser</CODE>,
 * which is able to choose the most appropriate RefResolver for a given Xlink.
 *
 *
 * @author Christophe Laprun, Sylvain Pajot
 * @version $Revision: 1.14 $
 * @see gov.nist.atlas.ref.AbstractRefResolver
 * @see gov.nist.atlas.ref.RefResolverChooser
 * @see gov.nist.atlas.ReusableATLASElement
 */
public interface RefResolver {

  /**
   * Gets the ReusableATLASElement pointed by an xlink
   *
   * @param xlink - the xlink to get the ReusableATLASElement from
   * @param expectedClass - the type of the ReusableATLASElement to get
   * @param containingCorpus - the corpus the xlink is located in
   * @return the ReusableATLASElement pointed by the xlink
   */
  ReusableATLASElement getElement(String xlink, ATLASClass expectedClass, Corpus containingCorpus);

  /**
   * Tests if an xlink is valid. Note that it does not check if the pointed
   * ReusableATLASElement exists (nor is valid) in the current corpus.
   *
   * @param xlink - the xlink to check
   * @param corpus - the corpus the xlink is located in
   * @return true if the internal link is syntactically correct and its
   * containing corpus exists
   */
  boolean acceptXLink(String xlink, Corpus corpus);

  /**
   * Tests if this RefResolver is dedicated to internal references resolving.
   *
   * @return true if this RefResolver aims to resolve internal references
   */
  boolean isLocal();
}



