/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */


package gov.nist.atlas;

import gov.nist.atlas.util.ATLASElementSet;


/**
 * AnnotationsHolder defines the behavior expected of elements
 * holding Annotations.
 *
 * @version $Revision: 1.9 $
 * @author Christophe Laprun
 *
 * @see Annotation
 */
public interface AnnotationsHolder {
  /**
   * Returns the contained Annotations with the specified type.
   *
   * @param typeName the name of the ATLASType of the Annotations
   * to be retrieved
   *
   * @return a possibly empty ATLASElementSet containing the
   * relevant Annotations
   */
  ATLASElementSet getAnnotationsWithType(String typeName);

  /**
   * Returns all Annotations contained in this AnnotationsHolder.
   *
   * @return a possibly empty ATLASElementSet containing all Annotations
   * contained in this AnnotationsHolder
   */
  ATLASElementSet getAllAnnotations();

  /**
   * Adds (if possible) the specified Annotation to this AnnotationsHolder.
   *
   * @param annotation the Annotation to be added
   *
   * @return <code>true</code> if the specified Annotation has been correctly
   * added, <code>false</code> otherwise
   */
  boolean addAnnotation(Annotation annotation);

  /**
   * Adds (if possible) the specified Annotations to this AnnotationsHolder.
   * Note that implementations of this method must be atomic, i.e.
   * all specified Annotations or none are added.
   *
   * @param  annotations an ATLASElementSet containing the Annotations to be added
   *
   * @return <code>true</code> if the specified Annotations have correctly
   * been added, <code>false</code> otherwise
   */
  boolean addAnnotations(ATLASElementSet annotations);

  /**
   * Removes (if possible) the specified Annotation from this
   * AnnotationsHolder.
   *
   * @param annotation the Annotation to be removed
   *
   * @return <code>true</code> if the specified Annotation has been correctly
   * removed, <code>false</code> otherwise
   */
  boolean removeAnnotation(Annotation annotation);
}

