/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;


/**
 * AIFSerializable defines the behavior of ATLASElements that can be
 * serialized to AIF.
 *
 * @version $Revision: 1.13 $
 * @author Christophe Laprun
 */
public interface AIFSerializable {
  /**
   * Prints the contextual AIF representation of this AIFSerializable to the
   * specified StringBuffer. This AIF representation is called contextual because it
   * uses contextual information (most notably role and propagated indent) from its parent element.
   * Note that this
   * method is not meant to be called directly but is needed by the framework in
   * particular to support export to AIF.
   *
   * @param buffer the StringBuffer to which the AIF representation of this
   * AIFSerializable should be printed
   * @param indent
   * @param role   the role of this AIFSerializable in the
   * context of its parent
   * @param context
   *
   * @deprecated Move to SPI
   */
  void toAIFBuffer(StringBuffer buffer, String indent, String role, ATLASElement context);

  /**
   * <p>Returns the context-free (without role or propagated indent) AIF representation of this
   * AIFSerializable as a String. This is a convenience method and should
   * typically be equivalent to:</p>
   *
   * <pre><code>
   * StringBuffer buffer = new StringBuffer();
   * toAIFBuffer(buffer, "  ", "", false);
   * buffer.toString();
   * </code>
   * </pre>
   *
   * @return the context-free AIF representation of this
   * AIFSerializable as a String
   *
   * @see #toAIFBuffer(StringBuffer,String,String,ATLASElement)
   */
  String asAIFString();
}



