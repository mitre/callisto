/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Id;
import gov.nist.atlas.Metadata;
import gov.nist.atlas.MetadataHolder;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;


/**
 * @version $Revision: 1.9 $
 * @author Christophe Laprun
 */
class ATLASMetadataHolder extends IdentifiableATLASElementImpl {
  protected ATLASMetadataHolder(ATLASType type, ATLASElement parent, Id id, ImplementationDelegate delegate) {
    super(type, parent, id, delegate);
    metadataHolder = new MetadataHolderImpl(getATLASType());
  }

  public boolean setMetadata(Metadata metadata) {
    return metadataHolder.setMetadata(metadata);
  }

  public Metadata getMetadata() {
    return metadataHolder.getMetadata();
  }

  public boolean hasMetadata() {
    return metadataHolder.hasMetadata();
  }

  private MetadataHolder metadataHolder;
}