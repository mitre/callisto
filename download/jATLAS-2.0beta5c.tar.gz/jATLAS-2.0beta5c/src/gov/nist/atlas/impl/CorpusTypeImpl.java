/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Signal;
import gov.nist.atlas.spi.TypeImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.AbstractATLASType;
import gov.nist.atlas.type.CorpusType;
import gov.nist.atlas.type.SignalType;
import gov.nist.maia.MAIAScheme;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * @author Christophe Laprun
 * @version $Revision: 1.12 $
 */
public class CorpusTypeImpl extends AbstractATLASType implements CorpusType {
  public CorpusTypeImpl(ATLASType superType, String name, MAIAScheme scheme, TypeImplementationDelegate delegate) {
    super(superType, name, scheme, delegate);
  }

  public ATLASClass getATLASClass() {
    return ATLASClass.CORPUS;
  }

  /**
   * The only valid parent for a Corpus is <code>null</code>.
   * @param parent the potential parent
   * @return <code>true</code> if parent is <code>null</code>,
   *         <code>false</code> otherwise.
   */
  public boolean isParentValid(ATLASElement parent) {
    return parent == null;
  }

  public boolean canAddSignal(Signal signal) {
//    return canAddToSubordinateSet(signal); // FIX-ME: do this eventually!
    if (signal == null)
      return false;
    ATLASType type = signal.getATLASType();
    if (allowedSignalTypes.contains(type))
      return true;
    return false;
  }

  public boolean addSignalType(SignalType type) {
    if (!allowedSignalTypes.contains(type)) {
      allowedSignalTypes.add(type);
      return true;
    }
    return false;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer(super.toString());
    sb.append("\nsignal types:\n");
    for (Iterator stIterator = allowedSignalTypes.iterator(); stIterator.hasNext();) {
      sb.append(((ATLASType) stIterator.next()).getName()).append(" ");
    }
    return sb.toString();
  }

  private Set allowedSignalTypes = new HashSet(7);
}



