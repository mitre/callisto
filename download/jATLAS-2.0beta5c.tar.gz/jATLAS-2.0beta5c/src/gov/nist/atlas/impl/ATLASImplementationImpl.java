/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.*;
import gov.nist.atlas.impl.bundled.DefaultImplementationDelegate;
import gov.nist.atlas.impl.bundled.DefaultTypeImplementationDelegate;
import gov.nist.atlas.ref.SignalRef;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.spi.TypeImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.ATLASTypeFactory;
import gov.nist.atlas.type.ChildrenType;
import gov.nist.atlas.util.ATLASElementSetFactory;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.ATLASImplementationManager;
import gov.nist.atlas.util.DefaultATLASElementSetFactory;

import java.net.URL;

/**
 * A convenient implementation of ATLASImplementation.
 *
 * @version $Revision: 1.15 $
 * @author Christophe Laprun
 *
 * @see gov.nist.atlas.util.ATLASImplementation
 */
public class ATLASImplementationImpl extends ATLASImplementation {

  protected ATLASImplementationImpl() {
    setFactory = new DefaultATLASElementSetFactory();
  }

  public ATLASTypeFactory getATLASTypeFactory() {
    return ATLASTypeFactory.getFactoryFor(this);
  }

  public ATLASElementSetFactory getATLASElementSetFactory() {
    return setFactory;
  }

  public String getAIFVersion() {
    return AIF_VERSION;
  }

  public ImplementationDelegate createImplementationDelegate(ATLASType type) {
    return new DefaultImplementationDelegate(type, this); // FIX-ME
  }

  public MinimalImplementationDelegate createMinimalImplementationDelegate(ATLASType type) {
    return new MinimalImplementationDelegate(type, this); // FIX-ME
  }

  public Analysis newAnalysis(ATLASType type, ATLASElement parent, Id id) {
    return new AnalysisImpl(type, parent, id, createImplementationDelegate(type));
  }

  public Anchor newAnchor(ATLASType type, ATLASElement parent, Id id, SignalRef signal) {
    return new AnchorImpl(type, parent, id, createImplementationDelegate(type), signal);
  }

  public Annotation newAnnotation(ATLASType type, ATLASElement parent, Id id, AnnotationInitializer initializer) {
    return new AnnotationImpl(type, parent, id, createImplementationDelegate(type), initializer);
  }

  public Children newChildren(ChildrenType type, ATLASElement parent) {
    if (ATLASClass.ANNOTATION.equals(type.getContainedElementsType().getATLASClass()))
      return new AnnotationChildrenImpl(type, parent, createImplementationDelegate(type));
    return new ChildrenImpl(type, parent, createImplementationDelegate(type));
  }

  public Corpus newCorpus(ATLASType type, Id id, URL location) {
    return new CorpusImpl(type, id, createImplementationDelegate(type), location);
  }

  public Feature newFeature(ATLASType type, ATLASElement parent) {
    return new FeatureImpl(type, parent, createImplementationDelegate(type));
  }

  public Metadata newMetadata(ATLASType type, ATLASElement parent) {
    return new MetadataImpl(type, parent, createMinimalImplementationDelegate(type));
  }

  public Parameter newParameter(ATLASType type, ATLASElement parent, Unit unit, String value) {
    return new ParameterImpl(type, parent, createMinimalImplementationDelegate(type), value, unit);
  }

  public Region newRegion(ATLASType type, ATLASElement parent, Id id) {
    return new RegionImpl(type, parent, id, createImplementationDelegate(type));
  }

  public SimpleSignal newSimpleSignal(ATLASType type, ATLASElement parent, Id id, URL location, String track) {
    return new SimpleSignalImpl(type, parent, id, createImplementationDelegate(type), location, track);
  }

  public SignalGroup newSignalGroup(ATLASType type, ATLASElement parent, Id id) {
    return new SignalGroupImpl(type, parent, id, createImplementationDelegate(type));
  }

  public Content newContent(ATLASType type, ATLASElement parent) {
    return new ContentImpl(type, parent, createImplementationDelegate(type));
  }

  public Id createNewIdFor(ATLASType type) {
    return idFactory.createNewIdFor(type);
  }

  public Id createNewIdFor(String stringId) {
    return idFactory.createNewIdFor(stringId);
  }

  public Id resolveIdFor(String stringId) {
    return idFactory.resolveIdFor(stringId);
  }

  /**
   * FIX-ME: Not implemented yet.
   */
  public Unit resolveUnitFor(String unitName) {
    return null;
  }

  public TypeImplementationDelegate newTypeDelegate() {
    return new DefaultTypeImplementationDelegate(this);
  }

  private final ATLASElementSetFactory setFactory;
  private final static String AIF_VERSION = "1.1";
  private IdFactoryImpl idFactory = new IdFactoryImpl();

  static {
    ATLASImplementationManager.registerImplementation(ATLASImplementationManager.DEFAULT, new ATLASImplementationImpl());
  }
}



