/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASAccessException;
import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.AbstractValidatable;
import gov.nist.atlas.Children;
import gov.nist.atlas.ConstraintManager;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.ReusableATLASElement;
import gov.nist.atlas.event.ContentChangeEvent;
import gov.nist.atlas.event.ContentChangedVetoException;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASElementFactory;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.ReferentManager;

import java.util.Iterator;
import java.util.Map;


/**
 * AbstractATLASElement is the base abstract class implementing the behavior
 * expected of ATLASElements. We recommend it be used
 * as the basis for alternate implementations although this is not mandatory.
 * It defines some default behaviors that
 * are used by sub-classes either directly or via polymorphism.
 *
 * @version $Revision: 1.49 $
 * @author Christophe Laprun, Nicolas Radde
 *
 * @see gov.nist.atlas.ATLASElement
 */
public class ATLASElementImpl extends AbstractValidatable implements ATLASElement {
  protected ATLASElementImpl() {
  }

  /** Protected constructor to prevent direct default instantiation. */
  protected ATLASElementImpl(ATLASType type, ATLASElement parent, ImplementationDelegate delegate) {
    initWith(type, parent, delegate);
  }

  protected void initWith(ATLASType type, ATLASElement parent, ImplementationDelegate delegate) {
    this.delegate = delegate;
    if (isTypeValid(type))
      this.type = type;
    else
      throw new IllegalArgumentException("The ATLASType: " + type + "is not a valid type for this ATLASElement");
    if (type.isParentValid(parent)) {
      if (parent == null)
        definingCorpus = (Corpus) this;
      else
        definingCorpus = parent.getDefiningCorpus(); // consider removal
      setParent(parent);
    } else
      throw new IllegalArgumentException("You need to pass a valid parent!");
    initContainedElementsWithDefaults();
  }


  public Corpus getDefiningCorpus() {
    return definingCorpus;
//    return getParent().getDefiningCorpus();
  }

  public final ATLASType getATLASType() {
    return type;
  }

  public ATLASClass getATLASClass() {
    return type.getATLASClass();
  }

  public ATLASElement getParent() {
    return parent;
  }

  protected void setParent(ATLASElement parent) {
    this.parent = parent;
  }

  public void toAIFBuffer(StringBuffer buffer, String indent, String role, ATLASElement context) {
    // do something?
  }

  protected String newIndent(String oldIndent) {
    return oldIndent + AIFExportConstants.INDENT;
  }

  public ATLASElement getSubordinateWithRole(String role) {
    return delegate.getSubordinateWithRole(role);
  }

  public ATLASElementSet getAllChildrenWith(ATLASType type) {
    return delegate.getAllChildrenWith(type);
  }

  public Map getRoleRequiredChildAssociations() {
    return delegate.getRoleSubordinateAssociations();
  }

  public Map getRoleOptionalChildrenSetAssociations() {
    return delegate.getTypeSubordinateSetsAssociations();
  }


  public boolean setSubordinateWithRole(ATLASElement element, String role) throws ATLASAccessException {
    boolean result = false;
    ATLASElement current = getSubordinateWithRole(role);
    if (element != null && !element.equals(current)
        && getATLASType().canSetSubordinateWithRole(element, role)) {
      try {
        ContentChangeEvent cEvent = new ContentChangeEvent(this, current, element);
        fireContentWillChange(cEvent);
        result = delegate.specificSetSubordinateWithRole(element, role);
        if (result) {
          fireContentChange(cEvent);
          if (element instanceof ReusableATLASElement) {
            if (current instanceof ReusableATLASElement)
              ReferentManager.removeReferentFrom((ReusableATLASElement) current, this);
            ReferentManager.addReferentTo((ReusableATLASElement) element, this);
          }
        }
      } catch (ContentChangedVetoException e) {
        throw new ATLASAccessException("setSubordinateWithRole vetoed!", e);
      }
    }
    return result;
  }

  private final boolean initContainedElementsWithDefaults() {
    ATLASElementFactory factory = ATLASElementFactory.getFactoryFor(getDefiningCorpus().getATLASImplementation());
    Iterator roles = getATLASType().getDefinedRolesForSubordinates();
    String role = null;
    ATLASType t = null;
    ATLASElement element = null;
    while (roles.hasNext()) {
      role = (String) roles.next();
      t = getATLASType().getTypeOfSubordinateWith(role);
      element = factory.createDefaultATLASElementWith(t, this);
      if (element == null)
        continue;
      // we can call specificSetSubordinateWithRole directly since we know that
      // we can set the created element
      delegate.specificSetSubordinateWithRole(element, role);
    }
    return false;
  }

  /**
   * <p>Provides a default implementation of Comparable.compareTo. This implementation
   * orders elements in the same order as the order defined on ATLASClasses.</p>
   *
   * <p>FIX-ME: Current implementation stupid (compares hashCodes!)</p>
   *
   * @since 2.0 beta 4
   */
  public int compareTo(Object o) {
    ATLASElement other = (ATLASElement) o;
    if (!getATLASType().equals(other.getATLASType()))
      throw new ClassCastException("Cannot compare ATLASElements with different ATLASTypes.");
    if (other == this)
      return 0;
    else
      return (hashCode() > other.hashCode()) ? 1 : -1;
  }

  /**
   * Indicates whether some other object is "equal to" this one. Subclasses
   * should override this method since, being generic, it is not particularly
   * efficient.
   *
   * @param obj the reference object with which to compare
   *
   * @return <code>true</code> if this object is the same as the provided Object;
   *         <code>false</code> otherwise.
   *
   * @since 2.0 beta 5
   */
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj instanceof ATLASElement) {
      ATLASElement other = (ATLASElement) obj;
      ATLASType type = getATLASType();
      ATLASType otherType = other.getATLASType();
      // check types
      if (!type.equals(otherType))
        return false;
      // check number of subordinates
      if (type.getSubordinateNumber() != otherType.getSubordinateNumber() ||
          type.getSubordinateSetNumber() != otherType.getSubordinateSetNumber())
        return false;

      // check subordinates equality
      Iterator roles = type.getDefinedRolesForSubordinates();
      Iterator otherRoles = otherType.getDefinedRolesForSubordinates();
      while (roles.hasNext()) {
        String role = (String) roles.next();
        String otherRole = (String) otherRoles.next();
        // check role equality: will that work? Yes, if constraint on iteration order
        if (!role.equals(otherRole))
          return false;
        // check subordinate equality
        if (!getSubordinateWithRole(role).equals(other.getSubordinateWithRole(otherRole)))
          return false;
      }

      // check subordinate set equality
      Iterator types = type.getContainedTypesInSubordinateSets();
      Iterator otherTypes = otherType.getContainedTypesInSubordinateSets();
      while (types.hasNext()) {
        type = (ATLASType) types.next();
        otherType = (ATLASType) otherTypes.next();
        if (!type.equals(otherType))
          return false;
        if (!getSubordinateSet(type).equals(other.getSubordinateSet(otherType)))
          return false;
      }
    }
    return false;
  }

  /**
   * Provides a basic String representation of this AbstractATLASElement.
   *
   * @return a String containing the names of this AbstractATLASElement's
   * ATLASClass and ATLASType
   */
  public String toString() {
    return new StringBuffer(getATLASType().getATLASClass().getName())
        .append(" with type '").append(getATLASType().getName())
        .append("'").toString();
  }

  public String asAIFString() {
    StringBuffer sb = initBuffer();
    toAIFBuffer(sb, AIFExportConstants.INDENT, "", null);
    return sb.toString();
  }

  /**
   * Initializes the buffer for asAIFString. Allows sub-classes to chose a more
   * appropriate initial size to limit buffer resizing operations.
   *
   * @return a new StringBuffer
   *
   * @since 2.0 beta 4
   */
  protected StringBuffer initBuffer() {
    return new StringBuffer(50);
  }

  // FIX-ME: finer error control
  public Children getChildrenWithRole(String role) throws ATLASAccessException {
    ATLASElement children = getSubordinateWithRole(role);
    if (children instanceof Children)
      return (Children) children;
    throw new ATLASAccessException("No children with role " + role + " in " + this);
  }

  /**
   * FIX-ME: update interface doc!
   * Adds the specified element to the set specified with the provided role.
   * Note that this method is only used to
   * add a new element to a kind of subordinates that have an unspecified
   * cardinality in this ATLASElement's MAIA
   * type definition. In particular, this method shouldn't be used to assign a
   * value to a mandatory subordinate
   * (cardinality=1, specified role and type). For this effect, use
   * setSubordinateWithRole.
   *
   * @param child the ATLASElement to be added
   * @param role the role identifying the set to which the
   *             specified element is to be added, if no role has
   *             been specified in the MAIA definition for this ATLASElement's
   *             ATLASType, the ATLASType.NULL_ROLE constant should be used
   *
   * @return    <code>true</code> if the addition was successfully performed,
   * <code>false</code> otherwise (for example, if the operation was
   * prohibited, the given element was of the wrong type, etc).
   *
   * @see #setSubordinateWithRole(gov.nist.atlas.ATLASElement, java.lang.String)
   * @see gov.nist.atlas.type.ATLASType#canAddToChildrenWithRole(gov.nist.atlas.ATLASElement,java.lang.String)
   *
   */
  public boolean addToChildrenWithRole(ATLASElement child, String role) throws ATLASAccessException {
    boolean result = false;
    if (getATLASType().canAddToChildrenWithRole(child, role)) {
      try {
        ContentChangeEvent cEvent = new ContentChangeEvent(this, null, child);
        fireContentWillChange(cEvent);
        result = delegate.specificAddToChildrenWithRole(child, role);
        if (result) {
          fireContentChange(cEvent);
          updateReferents(child, true);
        }
      } catch (ContentChangedVetoException e) {
        throw new ATLASAccessException("addToChildrenWithRole vetoed!", e);
      }
    }
    return result;
  }

  /**
   * FIX-ME: update interface doc!
   * Removes the specified element to the set specified with the provided
   * role. Note that this method is only used to
   * remove an existing element to a kind of subordinates that have an
   * unspecified cardinality in this ATLASElement's MAIA
   * type definition. In particular, this method shouldn't be used to assign a
   * value to a mandatory subordinate
   * (cardinality=1, specified role and type). For this effect, use
   * setSubordinateWithRole.
   *
   * @param child the ATLASElement to be removed
   * @param role the role identifying the set to which the specified element
   *             is to be removed, if no role has
   *             been specified in the MAIA definition for this ATLASElement's
   *             ATLASType, the ATLASType.NULL_ROLE constant should be used
   *
   * @return    <code>true</code> if the removal was successfully performed,
   * <code>false</code> otherwise (for example, if the operation was
   * prohibited, the given element was of the wrong type, etc).
   *
   * @see #setSubordinateWithRole(gov.nist.atlas.ATLASElement, java.lang.String)
   * @see gov.nist.atlas.type.ATLASType#canRemoveFromChildrenWithRole(gov.nist.atlas.ATLASElement,java.lang.String)
   *
   */
  public boolean removeFromChildrenWithRole(ATLASElement child, String role) throws ATLASAccessException {
    boolean result = false;
    if (getATLASType().canRemoveFromChildrenWithRole(child, role)) {
      try {
        ContentChangeEvent cEvent = new ContentChangeEvent(this, null, child);
        fireContentWillChange(cEvent);
        result = delegate.specificRemoveFromChildrenWithRole(child, role);
        if (result) {
          fireContentChange(cEvent);
          updateReferents(child, false);
        }
      } catch (ContentChangedVetoException e) {
        throw new ATLASAccessException("removeFromChildrenWithRole vetoed!", e);
      }
    }
    return result;
  }

  public ATLASElementSet getSubordinateSet(ATLASType containedSubordinateType) throws ATLASAccessException {
    return delegate.getSubordinateSet(containedSubordinateType);
  }

  public boolean addToSubordinateSet(ATLASElement subordinate) throws ATLASAccessException {
    boolean result = false;
    if (getATLASType().canAddToSubordinateSet(subordinate)) {
      try {
        ContentChangeEvent cEvent = new ContentChangeEvent(this, null, subordinate);
        fireContentWillChange(cEvent);
        result = delegate.specificAddToSubordinate(subordinate);
        if (result) {
          fireContentChange(cEvent);
          updateReferents(subordinate, true);
        }
      } catch (ContentChangedVetoException e) {
        throw new ATLASAccessException("addFromSubordinateSet vetoed!", e);
      }
    }
    return result;
  }

  public boolean removeFromSubordinateSet(ATLASElement subordinate) throws ATLASAccessException {
    boolean result = false;
    if (getATLASType().canRemoveFromSubordinateSet(subordinate)) {
      try {
        ContentChangeEvent cEvent = new ContentChangeEvent(this, null, subordinate);
        fireContentWillChange(cEvent);
        result = delegate.specificRemoveFromSubordinateSet(subordinate);
        if (result) {
          fireContentChange(cEvent);
          updateReferents(subordinate, false);
        }
      } catch (ContentChangedVetoException e) {
        throw new ATLASAccessException("removeFromSubordinateSet vetoed!", e);
      }
    }
    return result;
  }

  public ATLASElementSet getAllSubordinatesInSubordinateSetsWith(ATLASClass atlasClass) throws ATLASAccessException {
    return delegate.getAllSubordinatesFromSubordinateSetsWith(atlasClass);
  }

  public Object getApplicationDelegateWith(String name) {
    return ApplicationDelegateManager.getApplicationDelegate(this, name);
  }

  public boolean setApplicationDelegate(String name, Object applicationDelegate) {
    return ApplicationDelegateManager.setApplicationDelegate(this, name, applicationDelegate);
  }

  protected void updateReferents(ATLASElement subordinate, boolean afterAddition) {
    if (subordinate instanceof ReusableATLASElement) {
      if (afterAddition)
        ReferentManager.addReferentTo((ReusableATLASElement) subordinate, this);
      else
        ReferentManager.removeReferentFrom((ReusableATLASElement) subordinate, this);
    }
  }

  /**
   * Helper method for toAIFBuffer implementations. Prints out the AIF
   * representation of this AbstractATLASElement mandatory (fixed) subordinates.
   *
   * @param sb the StringBuffer to which the AIF representation
   * must be printed
   * @param indent a String containing indentation spaces
   * @param context the ATLASElement in which context this ATLASElement is printed
   */
  protected void subordinatesToAIFBuffer(StringBuffer sb, String indent, Object context) {
    Iterator roles = getATLASType().getDefinedRolesForSubordinates();
    String role = null;
    ATLASElement e = null;

    while (roles.hasNext()) {
      role = (String) roles.next();
      e = getSubordinateWithRole(role);
      if (e == null)
        throw new IllegalArgumentException("There is no element with role: " + role + " where there should be one!");
      e.toAIFBuffer(sb, newIndent(indent), role, this);
    }
  }

  /**
   * Helper method. Prints out the AIF representation of this
   * AbstractATLASElement's subordinates which have
   * undetermined cardinality (named here "multiple contained elements").
   *
   * @param sb the StringBuffer to which the AIF representation
   * must be printed
   * @param indent a String containing indentation spaces
   * @param context the ATLASElement in which context this ATLASElement is printed
   */
  protected void subordinateSetsToAIFBuffer(StringBuffer sb, String indent, Object context) {
    Iterator types = getATLASType().getContainedTypesInSubordinateSets();
    ATLASType type = null;
    ATLASElementSet set = null;

    while (types.hasNext()) {
      type = (ATLASType) types.next();
      set = delegate.getSubordinateSet(type);
      if (set != null)
        set.toAIFBuffer(sb, newIndent(indent), null, this);
    }
  }

  protected ConstraintManager getConstraintManager() {
    return getATLASType();
  }

  protected ATLASElementSet getAllChildrenWith(ATLASClass clazz) {
    return delegate.getAllChildrenWith(clazz);
  }

  protected boolean isTypeValid(ATLASType type) {
    return delegate.isTypeValid(type);
  }

  protected ImplementationDelegate delegate;
  private ATLASType type;
  private ATLASElement parent;
  private Corpus definingCorpus;
}



