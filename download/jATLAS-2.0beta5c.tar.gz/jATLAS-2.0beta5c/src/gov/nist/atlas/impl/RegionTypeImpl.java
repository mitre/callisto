/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Region;
import gov.nist.atlas.ref.AnchorRef;
import gov.nist.atlas.ref.AnnotationRef;
import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.spi.TypeImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.AbstractATLASType;
import gov.nist.atlas.type.RegionType;
import gov.nist.maia.MAIAScheme;

/**
 * @author Christophe Laprun
 * @version $Revision: 1.7 $
 */
public class RegionTypeImpl extends AbstractATLASType implements RegionType {
  public RegionTypeImpl(ATLASType superType, String name, MAIAScheme scheme, TypeImplementationDelegate delegate) {
    super(superType, name, scheme, delegate);
  }

  public ATLASClass getATLASClass() {
    return ATLASClass.REGION;
  }

  public boolean isParentValid(ATLASElement parent) {
    return parent instanceof Corpus || parent instanceof Region || parent instanceof Annotation;
  }

  public void checkInitParameters(AnnotationRef[] annotations, RegionRef[] regions, AnchorRef[] anchors) {
    // check that the appropriate number of element is present
    checkNumber(ATLASClass.ANNOTATION, annotations);
    checkNumber(ATLASClass.REGION, regions);
    checkNumber(ATLASClass.ANCHOR, anchors);

    checkRoles(annotations);
    checkRoles(regions);
    checkRoles(anchors);
  }
}



