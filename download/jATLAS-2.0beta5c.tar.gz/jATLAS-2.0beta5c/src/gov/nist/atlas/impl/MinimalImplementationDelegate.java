/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASAccessException;
import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.impl.bundled.DefaultTypeImplementationDelegate;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.spi.TypeImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.MutableATLASElementSet;

import java.util.Collections;
import java.util.Map;

/**
 * @version $Revision: 1.6 $
 * @author Christophe Laprun
 */
public class MinimalImplementationDelegate implements ImplementationDelegate {

  protected MinimalImplementationDelegate(ATLASType type, ATLASImplementation implementation) {
    /*if (isTypeValid(type))
      this.type = type;
    else
      throw new IllegalArgumentException("The ATLASType: " + type + "is not a valid type for this ATLASElement");
    if (type.isParentValid(parent)) {
//      definingCorpus = parent.getDefiningCorpus(); // consider removal
      setParent(parent);
    } else
      throw new IllegalArgumentException("You need to pass a valid parent!");*/
    if (isTypeValid(type))
      typeDelegate = type.getTypeImplementationDelegate();
    else
      throw new IllegalArgumentException("This ImplementationDelegate cannot be initialize with this type: " + type);
    if (implementation != null)
      this.implementation = implementation;
    else
      throw new IllegalArgumentException("A valid ATLASImplementation is required to initialize ImplementationDelegates.");
  }

  public ATLASElement getSubordinateWithRole(String role) {
    return null;
  }

  public ATLASImplementation getATLASImplementation() {
    return implementation;
  }

  public boolean specificAddToSubordinate(ATLASElement subordinate) throws ATLASAccessException {
    return false;
  }

  public boolean specificRemoveFromSubordinateSet(ATLASElement subordinate) throws ATLASAccessException {
    return false;
  }

  public MutableATLASElementSet getSubordinateSet(ATLASType containedSubordinateType) throws ATLASAccessException {
    return null; // FIX-ME
  }

  public Map getRoleSubordinateAssociations() {
    return Collections.EMPTY_MAP; // FIX-ME
  }

  public Map getTypeSubordinateSetsAssociations() {
    return Collections.EMPTY_MAP; // FIX-ME
  }

  public boolean specificSetSubordinateWithRole(ATLASElement element, String role) {
    return false;
  }

  public boolean specificAddToChildrenWithRole(ATLASElement element, String role) {
    return false;
  }

  public boolean specificRemoveFromChildrenWithRole(ATLASElement element, String role) {
    return false;
  }

  public ATLASElementSet getAllChildrenWith(ATLASClass clazz) {
    return getATLASImplementation().getATLASElementSetFactory().getEmptyATLASElementSet(clazz);
  }

  public ATLASElementSet getAllChildrenWith(ATLASType type) {
    return getATLASImplementation().getATLASElementSetFactory().getEmptyATLASElementSet(type);
  }

  // FIX-ME
  public boolean isTypeValid(ATLASType type) throws IllegalArgumentException {
    if (type.getTypeImplementationDelegate() instanceof DefaultTypeImplementationDelegate)
      return true;
    else
      throw new IllegalArgumentException(type + " is not a valid ATLASType for this ImplementationDelegate.");
  }

  public ATLASElementSet getAllSubordinatesFromSubordinateSetsWith(ATLASClass atlasClass) {
    return getATLASImplementation().getATLASElementSetFactory().getEmptyATLASElementSet(atlasClass);
  }

  //  private Corpus definingCorpus;
  private ATLASImplementation implementation;
  protected TypeImplementationDelegate typeDelegate;
}
