/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Anchor;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.Content;
import gov.nist.atlas.Id;
import gov.nist.atlas.Region;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.ref.AnchorRef;
import gov.nist.atlas.ref.AnnotationRef;
import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.RegionType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.MapATLASElementSet;

import java.util.Iterator;


/**
 *
 * @version $Revision: 1.44 $
 * @author Chris Laprun, Sylvain Pajot
 */
public class RegionImpl extends ReusableATLASElementImpl implements Region {
  protected RegionImpl(ATLASType type, ATLASElement parent, Id id, ImplementationDelegate delegate) {
    super(type, parent, id, delegate);
    getDefiningCorpus().addRegion(this);
  }

  public ATLASElementSet getReferencedSignals() {
    if (signalsAreDirty) {
      referencedSignals = new MapATLASElementSet(ATLASClass.SIGNAL, 7);

      Iterator i = getAllAnchors().iterator();
      while (i.hasNext())
        referencedSignals.add(((Anchor) i.next()).getSignal());

      i = getAllRegions().iterator();
      while (i.hasNext())
        referencedSignals.addAll(((Region) i.next()).getReferencedSignals());

      signalsAreDirty = false;
    }
    return referencedSignals;
  }

  public void toAIFBuffer(StringBuffer sb, String indent, String role, ATLASElement context) {
    String newIndent = newIndent(indent);
    if (context instanceof Annotation || context instanceof Region ||
        context instanceof Content) {
      toAIFBufferAsRef(sb, newIndent, role, context);
      return;
    }

    sb.append(indent).append(AIFExportConstants.REGION_S)
        .append(getId().getAsString()).append(AIFExportConstants.TYPE_ATT)
        .append(getATLASType().getName()).append(AIFExportConstants.CLOSE);

    subordinatesToAIFBuffer(sb, newIndent, this);

    subordinateSetsToAIFBuffer(sb, newIndent, this);

    sb.append(indent).append(AIFExportConstants.REGION_E);
  }

  public void initContainedElementsWith(AnnotationRef[] annotations, RegionRef[] regions, AnchorRef[] anchors) {
    // What to do in case annotations, regions and anchors == null
    // temporary variables for elements addition
    int numberOfElements, i;

    // Annotations addition
    if (annotations != null) {
      numberOfElements = annotations.length;
      for (i = 0; i < numberOfElements; i++) {
        setAnnotationWithRole(annotations[i]);
      }
    }
    // Anchors addition
    if (anchors != null) {
      numberOfElements = anchors.length;
      for (i = 0; i < numberOfElements; i++) {
        setAnchorWithRole(anchors[i]);
      }
    }
    // Regions addition
    if (regions != null) {
      numberOfElements = regions.length;
      for (i = 0; i < numberOfElements; i++) {
        setRegionWithRole(regions[i]);
      }
    }
  }

  public final RegionType getRegionType() {
    return (RegionType) getATLASType();
  }

  public final boolean isTypeValid(ATLASType type) {
    return super.isTypeValid(type) && (type instanceof RegionType);
  }


  public boolean setAnchorWithRole(Anchor anchor, String role) {
    return setSubordinateWithRole(anchor, role);
  }

  public boolean setAnchorWithRole(AnchorRef anchor) {
    return setSubordinateWithRole(anchor.getElement(), anchor.getRole());
  }

  public Anchor getAnchorWithRole(String role) {
    return (Anchor) getSubordinateWithRole(role);
  }

  public boolean addAnchor(Anchor anchor) {
    return addToSubordinateSet(anchor);
  }

  public boolean removeAnchor(Anchor anchor) {
    return removeFromSubordinateSet(anchor);
  }

  public ATLASElementSet getAllAnchors() {
    return getAllChildrenWith(ATLASClass.ANCHOR);
  }

  public boolean setAnnotationWithRole(Annotation annotation, String role) {
    return setSubordinateWithRole(annotation, role);
  }

  public boolean setAnnotationWithRole(AnnotationRef annotation) {
    return setSubordinateWithRole(annotation.getElement(), annotation.getRole());
  }

  public Annotation getAnnotationWithRole(String role) {
    return (Annotation) getSubordinateWithRole(role);
  }

  public boolean addAnnotation(Annotation annotation) {
    return addToSubordinateSet(annotation);
  }

  public boolean removeAnnotation(Annotation annotation) {
    return removeFromSubordinateSet(annotation);
  }

  public ATLASElementSet getAllAnnotations() {
    return getAllChildrenWith(ATLASClass.ANNOTATION);
  }


  public boolean setRegionWithRole(Region region, String role) {
    return setSubordinateWithRole(region, role);
  }

  public boolean setRegionWithRole(RegionRef region) {
    return setSubordinateWithRole(region.getElement(), region.getRole());
  }

  public Region getRegionWithRole(String role) {
    return (Region) getSubordinateWithRole(role);
  }

  public boolean addRegion(Region region) {
    return addToSubordinateSet(region);
  }

  public boolean removeRegion(Region region) {
    return removeFromSubordinateSet(region);
  }

  public ATLASElementSet getAllRegions() {
    return getAllChildrenWith(ATLASClass.REGION);
  }

  /*
    We need to redefine the following methods in order to mark the referenced signals
    as dirty to avoid to re-compute them if unneeded.
  */

  public boolean setSubordinateWithRole(ATLASElement element, String role) {
    if (super.setSubordinateWithRole(element, role)) {
      signalsAreDirty = true;
      return true;
    }
    return false;
  }

  public boolean addToSubordinateSet(ATLASElement subordinate) {
    if (super.addToSubordinateSet(subordinate)) {
      signalsAreDirty = true;
      return true;
    }
    return false;
  }

  public boolean removeFromSubordinateSet(ATLASElement subordinate) {
    if (super.removeFromSubordinateSet(subordinate)) {
      signalsAreDirty = true;
      return true;
    }
    return false;
  }

  private MapATLASElementSet referencedSignals;
  private boolean signalsAreDirty = false;
}