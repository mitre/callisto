/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Id;
import gov.nist.atlas.MIMEClass;
import gov.nist.atlas.Signal;
import gov.nist.atlas.SimpleSignal;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;

import java.net.URL;

/**
 * @version $Revision: 1.26 $
 * @author Christophe Laprun, Sylvain Pajot
 */
public class SimpleSignalImpl extends SignalImpl implements SimpleSignal {
  protected SimpleSignalImpl(ATLASType type, ATLASElement parent, Id id, ImplementationDelegate delegate, URL url, String track) {
    super(type, parent, id, delegate);
    setLocation(url);
    if (track == null || track.equals(""))
      track = DEFAULT_TRACK;
    this.track = track;
  }

  public void toAIFBuffer(StringBuffer sb, String indent, String role, ATLASElement context) {
    if (context instanceof Signal) {
      toAIFBufferAsRef(sb, newIndent(indent), role, context);
      return;
    }

    sb.append(indent).append(AIFExportConstants.SIMPLESIGNAL_S)
        .append(getId().getAsString()).append(AIFExportConstants.TYPE_ATT)
        .append(getATLASType().getName()).append("' mimeClass='")
        .append(getMIMEClass().getName()).append("' mimeType='")
        .append(mimeType).append(AIFExportConstants.LOCATION_ATT)
        .append(url.toExternalForm()).append("' encoding='")
        .append(encoding).append(AIFExportConstants.TRACK_ATT);
    if (track == null)
      sb.append(DEFAULT_TRACK);
    else
      sb.append(track);
    sb.append(AIFExportConstants.EMPTY_CLOSE);
  }

  public void setLocation(URL url) {
    if (url == null)
      throw new IllegalArgumentException("You must pass a valid URL!");
    this.url = url;
  }

  public String getMIMEType() {
    return mimeType;
  }

  public MIMEClass getMIMEClass() {
    MIMEClass mimeClass = getSignalType().getMIMEClass();
    if (mimeClass == null)
      throw new RuntimeException("Problem with MIMEClass for " + getSignalType());
    return mimeClass;
  }

  public String getEncoding() {
    return encoding;
  }

  public String getTrack() {
    return track;
  }

  public URL getLocation() {
    return url;
  }

  public boolean isGroup() {
    return false;
  }

  /** VARIABLES **** */
  private String mimeType;
  private URL url;
  private String encoding;
  private String track;
  public static final String DEFAULT_TRACK = "ALL";
}