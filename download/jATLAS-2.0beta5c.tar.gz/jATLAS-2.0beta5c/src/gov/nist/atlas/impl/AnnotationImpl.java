/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.*;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.AnnotationChildrenType;
import gov.nist.atlas.type.AnnotationType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.RoleIdentifiedFeature;
import gov.nist.atlas.util.RoleIdentifiedParameter;

import java.util.Iterator;


/**
 * @version $Revision: 1.56 $
 * @author Sylvain Pajot, Christophe Laprun
 */
public class AnnotationImpl extends ReusableATLASElementImpl implements Annotation {
  protected AnnotationImpl(ATLASType type, ATLASElement parent, Id id, ImplementationDelegate delegate, AnnotationInitializer initializer) {
    super(type, parent, id, delegate);
    initializer.setAnnotation(this);
    internalInit((Analysis) getParent(), initializer);
  }

  private void internalInit(Analysis parent, AnnotationInitializer initializer) {
    initializer.initRegionAndContent();
    boolean added = parent.addAnnotation(this); //FIX-ME?
    if (!added) {
      System.out.println("parent.getAnalysisType() = " + parent.getAnalysisType());
      throw new ATLASAccessException("Couldn't add " + this + " to analysis " + parent);
    }
  }

  // FIX-ME: remove dependency on ATMultipleKey
  public void toAIFBuffer(StringBuffer sb, String indent, String role, ATLASElement context) {
    if (context instanceof Region || context instanceof Children
        || context instanceof Content) {
      toAIFBufferAsRef(sb, indent, role, context);
      return;
    }
    sb.append(indent).append(AIFExportConstants.ANNOTATION_S)
        .append(getId().getAsString()).append(AIFExportConstants.TYPE_ATT)
        .append(getATLASType().getName()).append(AIFExportConstants.CLOSE);

    String childrenRole = null;
    String newIndent = newIndent(indent);

    AnnotationType annotationType = getAnnotationType();
    ATLASType containedType = null;
    if (childrenDefinedRegion) {
      childrenRole = annotationType.getRoleForRegionDefiningChildren();
      containedType = annotationType.getContainedTypeInChildrenWith(childrenRole);
      sb.append(newIndent)
          .append(AIFExportConstants.REGION_DEF_CHILDREN)
          .append(containedType.getName()).append(AIFExportConstants.WITH_ROLE)
          .append(childrenRole).append(AIFExportConstants.EMPTY_CLOSE);
    } else
      getRegion().toAIFBuffer(sb, newIndent(indent), getRoleForRegion(), this);

    if (childrenDefinedContent) {
      childrenRole = annotationType.getRoleForContentDefiningChildren();
      containedType = annotationType.getContainedTypeInChildrenWith(childrenRole);
      sb.append(newIndent)
          .append(AIFExportConstants.CONTENT_DEF_CHILDREN)
          .append(containedType.getName()).append(AIFExportConstants.WITH_ROLE)
          .append(childrenRole).append(AIFExportConstants.EMPTY_CLOSE);
    } else
      getContent().toAIFBuffer(sb, newIndent(indent), getRoleForContent(), this);

    // Need to handle Children separately for Annotations. Are normally handled
    // by subordinatesToAIFBuffer()
    Iterator roles = getATLASType().getDefinedRolesForSubordinates();
    while (roles.hasNext()) {
      childrenRole = (String) roles.next();
      ATLASElement children = getSubordinateWithRole(childrenRole);
      if (children instanceof Children)
        children.toAIFBuffer(sb, newIndent(indent), childrenRole, this);
    }

    sb.append(indent).append(AIFExportConstants.ANNOTATION_E);
  }

  public void initContentWith(RoleIdentifiedFeature[] features, RoleIdentifiedParameter[] parameters, RegionRef alignedRegion) {
    getContent().initContainedElementsWith(alignedRegion, parameters, features);
  }

  public AnnotationChildren getAnnotationChildrenWithRole(String role) {
    return (AnnotationChildren) getChildrenWithRole(role);
  }

  public final Region getRegion() {
    if (childrenDefinedRegion) {
      AnnotationChildren children = getRegionDefiningChildren();
      return (children != null) ? children.getDefinedRegion() : null; // FIX-ME: should be an error!
    }
    return (Region) getSubordinateWithRole(getRoleForRegion());
  }

  public final Content getContent() {
    if (childrenDefinedContent) {
      AnnotationChildren children = getContentDefiningChildren();
      return (children != null) ? children.getDefinedContent() : null; // FIX-ME
    }
    return (Content) getSubordinateWithRole(getAnnotationType().getRoleForContent());
  }

  public boolean replaceRegionByChildrenRegion() {
    if (getAnnotationType().canRegionBeDefinedByChildren()) {
      childrenDefinedRegion = true;
      return true;
    }
    return false;
  }

  public boolean rebuildRegionFromChildrenRegion() {
    if (getAnnotationType().canRegionBeDefinedByChildren()) {
      childrenDefinedRegion = false;
      setSubordinateWithRole(getRegionDefiningChildren().getDefinedRegion(), getRoleForRegion());
      return true;
    }
    return false;
  }

  public boolean replaceContentByChildrenContent() {
    if (getAnnotationType().canContentBeDefinedByChildren()) {
      childrenDefinedContent = true;
      return true;
    }
    return false;
  }

  public boolean rebuildContentFromChildrenContent() {
    if (getAnnotationType().canContentBeDefinedByChildren()) {
      childrenDefinedContent = false;
      setSubordinateWithRole(getContentDefiningChildren().getDefinedContent(), getRoleForContent());
      return true;
    }
    return false;
  }

  public boolean addChildToChildrenWithRole(Annotation annotation, String role) {
    return addToChildrenWithRole(annotation, role);
  }

  public boolean addToContentDefiningChildren(ATLASElementSet contentDefiningAnnotations) {
    return addToDefiningChildren(contentDefiningAnnotations, AnnotationChildrenType.CONTENT_DEFINING);
  }

  public boolean addToRegionDefiningChildren(ATLASElementSet regionDefiningAnnotations) {
    return addToDefiningChildren(regionDefiningAnnotations, AnnotationChildrenType.REGION_DEFINING);
  }

  public boolean addToDefiningChildren(ATLASElementSet childrenAnnotations, AnnotationChildrenType.SubType kind) {
    String role = getAnnotationType().getRoleForChildrenWith(kind);
    return getChildrenWithRole(role).addToSubordinateSet(childrenAnnotations, ATLASClass.ANNOTATION);
  }

  public AnnotationChildren getContentDefiningChildren() {
    return getDefiningChildrenFor(AnnotationChildrenType.CONTENT_DEFINING);
  }

  public AnnotationChildren getRegionDefiningChildren() {
    return getDefiningChildrenFor(AnnotationChildrenType.REGION_DEFINING);
  }

  public AnnotationChildren getDefiningChildrenFor(AnnotationChildrenType.SubType kind) {
    if (!getAnnotationType().canBeDefinedByChildren(kind))
      return null;
    return (AnnotationChildren) getChildrenWithRole(getAnnotationType().getRoleForChildrenWith(kind)); // FIX-ME
  }

  public final AnnotationType getAnnotationType() {
    return (AnnotationType) getATLASType();
  }

  public final boolean isTypeValid(ATLASType type) {
    boolean bool = super.isTypeValid(type) && (type instanceof AnnotationType);
    return bool;
  }

  private final String getRoleForRegion() {
    return getAnnotationType().getRoleForRegion();
  }

  private final String getRoleForContent() {
    return getAnnotationType().getRoleForContent();
  }

  private boolean childrenDefinedRegion = false;
  private boolean childrenDefinedContent = false;
}
