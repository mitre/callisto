/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Id;
import gov.nist.atlas.Signal;
import gov.nist.atlas.SignalGroup;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.ref.SignalRef;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASElementSet;


/**
 * FIX-ME: this implementation is wrong, FIX IT!
 *
 * @version $Revision: 1.34 $
 * @author Christophe Laprun, Sylvain Pajot
 */
public class SignalGroupImpl extends SignalImpl implements SignalGroup {
  public SignalGroupImpl(ATLASType type, ATLASElement parent, Id id, ImplementationDelegate delegate) {
    super(type, parent, id, delegate);
  }

  public void toAIFBuffer(StringBuffer sb, String indent, String role, ATLASElement context) {
    String newIndent = newIndent(indent);
    if (context instanceof Signal) {
      toAIFBufferAsRef(sb, newIndent, role, context);
      return;
    }

    sb.append(indent).append(AIFExportConstants.SIGNALGROUP_S)
        .append(getId().getAsString()).append(AIFExportConstants.TYPE_ATT)
        .append(getATLASType().getName()).append(AIFExportConstants.ROLE_ATT)
        .append(role).append(AIFExportConstants.CLOSE);

    subordinatesToAIFBuffer(sb, newIndent, this);
    subordinateSetsToAIFBuffer(sb, newIndent, this); // this is the way it should be if we keep addSignal but needs change on AIF

    sb.append(indent).append(AIFExportConstants.SIGNALGROUP_E);
  }

  // FIX-ME
  public void initContainedElementsWith(SignalRef[] signals) {
    if (signals == null) ; // do something
    SignalRef signal = null;
    for (int i = 0; i < signals.length; i++) {
      signal = signals[i];
      setSubordinateWithRole(signal.getElement(), signal.getRole());
    }
  }

  public boolean addSignal(Signal signal) {
    return addToSubordinateSet(signal);
  }

  public boolean removeSignal(Signal signal) {
    return removeFromSubordinateSet(signal);
  }

  public boolean setSignalWithRole(Signal signal, String role) {
    return setSubordinateWithRole(signal, role);
  }

  public Signal getSignalWithRole(String role) {
    return (Signal) getSubordinateWithRole(role);
  }

  public ATLASElementSet getAllSignals() {
    return getAllChildrenWith(ATLASClass.SIGNAL);
  }

  public final boolean isGroup() {
    return true;
  }

  /**
   * @associates <oiref:SignalImpl:oiref>
   * @link aggregation
   */
}