/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASAccessException;
import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Children;
import gov.nist.atlas.ReusableATLASElement;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.ChildrenType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.MutableATLASElementSet;
import gov.nist.atlas.util.ReferentManager;

import java.util.Comparator;


/**
 * @version $Revision: 1.39 $
 * @author Christophe Laprun
 */
public class ChildrenImpl extends ATLASElementImpl implements Children {

  protected ChildrenImpl(ATLASType type, ATLASElement parent, ImplementationDelegate delegate) {
    super(type, parent, delegate);
  }

  public ChildrenType getChildrenType() {
    return (ChildrenType) getATLASType();
  }

  public void toAIFBuffer(StringBuffer buffer, String indent, String role, ATLASElement context) {
    MutableATLASElementSet set = getSet();
    set.setAIFName(AIFExportConstants.CHILDREN);
    set.toAIFBuffer(buffer, newIndent(indent), role, this);
  }

  public ATLASType getContainedElementsType() {
    return getChildrenType().getContainedElementsType();
  }

  public ATLASElementSet getContainedElements() {
    return getSubordinateSet(getContainedElementsType());
  }

  public ATLASElement consolidateAs(ATLASType resultElementType) {
    return null; // FIX-ME
  }

  // FIX-ME
  public void sort() {
    getSet().sort();
  }

  // FIX-ME
  public void sort(Comparator comparator) {
    /*if(getChildrenType().isSortable())
      getSet().sort(comparator);*/
    getSet().sort(comparator);
  }

  public boolean addToSubordinateSet(ATLASElementSet children, ATLASClass expectedElementsClass) throws ATLASAccessException {
    if (children == null || children.isEmpty())
      return false;
    if (expectedElementsClass != children.getComponentATLASClass())
      return false; // children don't match the expected ATLASClass

    boolean additionSuccessful = getSet().addAll(children);
    if (!additionSuccessful)
      throw new ATLASAccessException("Couldn't add all the elements contained in "
          + children);
    return additionSuccessful;
  }

  // We need to override this method because the "real" referent is the Children's parent
  protected void updateReferents(ATLASElement subordinate, boolean afterAddition) {
    if (subordinate instanceof ReusableATLASElement) {
      if (afterAddition)
        ReferentManager.addReferentTo((ReusableATLASElement) subordinate, getParent());
      else
        ReferentManager.removeReferentFrom((ReusableATLASElement) subordinate, getParent());
    }
  }

  private final MutableATLASElementSet getSet() {
    return delegate.getSubordinateSet(getChildrenType().getContainedElementsType());
  }
}