/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASElement;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Manages application delegates for ATLASElements.
 *
 * @author Chris Laprun
 * @version $Revision: 1.2 $
 */
class ApplicationDelegateManager {
  public static Object getApplicationDelegate(ATLASElement targetElement,
                                              String delegateName) {
    Map delegateMap = (Map) elementsToDelegateMap.get(targetElement);
    if (delegateMap != null)
      return delegateMap.get(delegateName);
    return null;
  }

  public static boolean setApplicationDelegate(ATLASElement targetElement,
                                               String delegateName, Object delegate) {
    Map delegateMap = (Map) elementsToDelegateMap.get(targetElement);
    if (delegateMap == null) {
      delegateMap = new HashMap(7);
      elementsToDelegateMap.put(targetElement, delegateMap);
    }
    return delegateMap.put(delegateName, delegate) != delegateMap.get(delegateName);
  }

  private static Map elementsToDelegateMap = new IdentityHashMap(137);
}
