/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


/**
 * <p>ConstraintSet gathers a set of Constraints.</p>
 *
 * <p>Not yet fully supported. Might be moved to the
 * gov.nist.atlas.type package.</p>
 *
 * @version $Revision: 1.14 $
 * @author Christophe Laprun
 *
 * @see Constraint
 */
public class ConstraintSet {
  /**
   * Default constructor.
   */
  public ConstraintSet() {
    constraints = new HashMap(7);
  }

  /**
   * Creates a new ConstraintSet with the initial room for the specified
   * number of Constraints.
   *
   * @param constraintNumber the initial number of Constraints that can be
   * contained in this ConstraintSet
   */
  public ConstraintSet(int constraintNumber) {
    constraints = new HashMap(constraintNumber);
  }

  /**
   * Returns the Constraint, contained in this ConstraintSet, associated with
   * the specified name.
   *
   * @param name the name of the Constraint to be retrieved
   *
   * @return the Constraint associated with the specified name or
   * <code>null</code> if no such Constraint is contained in
   * this ConstraintSet
   */
  public Constraint getConstraintWithName(String name) {
    return (Constraint) constraints.get(name);
  }

  /**
   * Determines if this ConstraintSet contains a Constraint with the specified
   * name.
   *
   * @param name the name of the Constraint which precense is checked
   *
   * @return <code>true</code> if this ConstraintSet contains a Constraint with
   *         the specified name, <code>false</code> otherwise
   *
   * @since 2.0 beta 4
   */
  public boolean containsConstraintWithName(String name) {
    return constraints.containsKey(name);
  }

  /**
   * Provides an iterator over the Constraints contained in this
   * ConstraintSet.
   *
   * @return an iterator over the Constraints contained in this ConstraintSet
   *
   * @see java.util.Iterator
   */
  public Iterator iterator() {
    return constraints.values().iterator();
  }

  /**
   * Returns the size of this ConstraintSet (i.e. the number of
   * unique Constraints contained in this ConstraintSet).
   *
   * @return the size of this ConstraintSet
   */
  public int size() {
    return constraints.size();
  }

  /**
   * Adds the specified Constraint to this ConstraintSet.
   *
   * @param constraint the Constraint to be added to this ConstraintSet
   *
   * @return <code>true</code> if the addition was successful,
   * <code>false</code> otherwise
   */
  boolean addConstraint(Constraint constraint) {
    if (constraint == null)
      return false;
    String name = constraint.getName();
    if (constraints.containsKey(name))
      return false;
    constraints.put(name, constraint);
    return true;
  }

  /**
   * Removes the specified Constraint to this ConstraintSet.
   *
   * @param constraint the Constraint to be removed from this ConstraintSet
   *
   * @return <code>true</code> if the addition was successful,
   * <code>false</code> otherwise
   */
  boolean removeConstraint(Constraint constraint) {
    if (constraint == null)
      return false;
    String name = constraint.getName();
    if (constraints.containsKey(name)) {
      constraints.remove(constraint);
      return true;
    }
    return false;
  }

  /**
   *@link aggregation
   * @associates <{gov.nist.atlas.Constraint}>
   * @supplierCardinality 0..*
   */
  private Map constraints;
}

