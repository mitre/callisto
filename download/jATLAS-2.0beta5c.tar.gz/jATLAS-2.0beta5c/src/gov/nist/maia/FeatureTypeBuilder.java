/*
 * MAIA
 * Meta-Annotation Infrastructure for ATLAS
 * Author: Chris Laprun
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.maia;

import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.FeatureType;
import gov.nist.atlas.util.ATLASImplementation;
import org.dom4j.Element;

class FeatureTypeBuilder extends FeatureDataBuilder {
  FeatureTypeBuilder(ATLASImplementation implementation, ATLASTypeBuilderFactory builderFactory, MAIAScheme scheme) {
    super(implementation, builderFactory, scheme);
  }

  ATLASType build(Element e) {
    FeatureType type = factory.createEmptyFeatureType(null, getNameOrRef(e), scheme);
    scheme.registerType(type);
    populateFeatureData(e, type);
    return type;
  }
}
