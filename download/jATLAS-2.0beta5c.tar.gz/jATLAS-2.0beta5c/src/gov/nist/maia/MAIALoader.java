/*
* MAIA
* Meta-Annotation Infrastructure for ATLAS
* Author: Chris Laprun
*
* This software was developed at the National Institute of Standards and Technology by
* employees of the Federal Government in the course of their official duties.  Pursuant to
* Title 17 Section 105 of the United States Code this software is not subject to copyright
* protection within the United States and is in the public domain. jATLAS is
* an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
*
* THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
* OR IMLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
* OR FITNESS FOR A PARTICULAR PURPOSE.
*/

package gov.nist.maia;

import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.ATLASImplementationManager;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @version $Revision: 1.23 $
 * @author Christophe Laprun
 */
public class MAIALoader {
  /**
   * Public constructor.
   * @param implementation the ATLASImplementation determining which
   *        implementation to use for the ATLASTypes.
   */
  public MAIALoader(ATLASImplementation implementation) {
    if (implementation == null)
      this.implementation = ATLASImplementationManager.getDefaultImplementation();
    else
      this.implementation = implementation;
  }

  public MAIAScheme loadTypeDefinitionsFrom(URL url) {
    if (url == null)
      throw new IllegalArgumentException("You must pass a valid URL.");

    // if scheme has already been loaded, don't do anything...
    // FIX-ME: needs better handling, move code to SchemeManager, needs to check
    // if scheme has changed since last loading (check file's date stamp), perform
    // name checks (and offer to resolve conflicts, diffxml?)
    MAIAScheme scheme = (MAIAScheme) MAIALoader.loadedSchemes.get(url);
    if (scheme != null)
      return scheme;

    try {
      doc = parse(url);
    } catch (DocumentException de) {
      System.out.println(de);
    }

    Element root = doc.getRootElement();
    Element types = root.element(TYPES);
    if (types == null)
      throw new IllegalArgumentException("The MAIA file located at " + url
          + " needs to be updated: in particular, ATLASTypeDefinitions is now called TypeDefinitions.");

    scheme = new MAIAScheme(root.attributeValue(NAME), url); // initialize scheme
    importTypes(scheme); // process imports: builds types on which scheme relies
//      checkTypes();
    scheme = buildTypesFor(scheme, types); // build scheme types
    MAIALoader.loadedSchemes.put(url, scheme); // add scheme to list of loaded schemes`
    return scheme;
  }

  private void addSchemeToParent(String name, MAIAScheme scheme, MAIAScheme parentScheme) {
    if (parentScheme != null) {
      if (name == null)
        name = scheme.getName();
      parentScheme.addImportedScheme(name, scheme);
    }
  }

  private void importTypes(MAIAScheme parentScheme) {
    Iterator imports = doc.getRootElement().elementIterator(MAIALoader.IMPORT);
    Element element = null;
    URL location = null;
    MAIALoader loader = null;
    while (imports.hasNext()) {
      element = (Element) imports.next();
      try {
        location = new URL(element.attributeValue(MAIALoader.LOCATION));
      } catch (MalformedURLException mue) {
        System.err.println(mue.getMessage());
        System.exit(-1);
      }
      String name = element.attributeValue(MAIALoader.WITHNAME);
      loader = new MAIALoader(implementation);
      addSchemeToParent(name, loader.loadTypeDefinitionsFrom(location), parentScheme);
    }
  }


  private Document parse(URL url) throws DocumentException {
    SAXReader reader = new SAXReader();
    return reader.read(url);
  }

  private void checkTypes() {
    if (doc != null) {
      unresolvedNames = new HashSet(31);
      names = new HashSet(31);
      resolveNames(doc.getRootElement().element(TYPES));
      if (!unresolvedNames.isEmpty())
        throw new RuntimeException("MAIA ERROR: Unresolved types:\n" + unresolvedNames);
    }
  }

  private void resolveNames(Element element) {
    Element e = null;
    String nameOrRef = null;
    Node node = null;
    for (int i = 0, size = element.nodeCount(); i < size; i++) {
      node = element.node(i);
      if (node instanceof Element) {
        e = (Element) node;
        if (!e.getName().endsWith(TYPE))
          continue;
        nameOrRef = e.attributeValue(NAME);
        if (nameOrRef != null) {
          if (unresolvedNames.contains(nameOrRef))
            unresolvedNames.remove(nameOrRef); // name is now resolved
          names.add(nameOrRef);
        } else {
          nameOrRef = e.attributeValue(REF);
          if (!names.contains(nameOrRef))
            unresolvedNames.add(nameOrRef); // name hasn't been resolved yet
        }
        resolveNames(e);
      }
    }
  }

  private MAIAScheme buildTypesFor(MAIAScheme scheme, Element types) {
    if (doc != null) {
      ATLASTypeBuilderFactory builderFactory = ATLASTypeBuilderFactory.getFactoryFor(implementation);

      // Signal types
      buildTypesFor(types.elementIterator(MAIALoader.SIGNAL), builderFactory.getSignalTypeBuilder(scheme));

      // SignalGroup types
      buildTypesFor(types.elementIterator(MAIALoader.SIGNALGROUP), builderFactory.getSignalGroupTypeBuilder(scheme));

      // Anchor types
      buildTypesFor(types.elementIterator(MAIALoader.ANCHOR), builderFactory.getAnchorTypeBuilder(scheme));

      // Region types
      buildTypesFor(types.elementIterator(MAIALoader.REGION), builderFactory.getRegionTypeBuilder(scheme));

      // Analysis types
      buildTypesFor(types.elementIterator(MAIALoader.ANALYSIS), builderFactory.getAnalysisTypeBuilder(scheme));

      // Parameter types
      buildTypesFor(types.elementIterator(MAIALoader.PARAMETER), builderFactory.getParameterTypeBuilder(scheme));

      // Feature types
      buildTypesFor(types.elementIterator(MAIALoader.FEATURE), builderFactory.getFeatureTypeBuilder(scheme));

      // Content types
      buildTypesFor(types.elementIterator(MAIALoader.CONTENT), builderFactory.getContentTypeBuilder(scheme));

      // Annotation types
      buildTypesFor(types.elementIterator(MAIALoader.ANNOTATION), builderFactory.getAnnotationTypeBuilder(scheme));

      // Children types
      buildTypesFor(types.elementIterator(MAIALoader.CHILDREN), builderFactory.getChildrenTypeBuilder(scheme));

      // Corpus types
      CorpusTypeBuilder builder = builderFactory.getCorpusTypeBuilder(scheme);
      buildTypesFor(types.elementIterator(MAIALoader.CORPUS), builder);

      return scheme;
    }
    return null;
  }

  private final void buildTypesFor(Iterator subTypes, ATLASTypeBuilder builder) {
    while (subTypes.hasNext()) {
      builder.build((Element) subTypes.next());
    }
  }

  public static void main(String[] args) {
    MAIALoader loader = new MAIALoader(null);
    if (args[0] == null) {
      System.err.println("Usage: java MAIALoader <file>");
      System.exit(-1);
    }
    File file = new File(args[0]);
    URL url = null;
    try {
      url = file.toURL();
    } catch (Exception ex) {
      ex.printStackTrace();
    }

    MAIAScheme scheme = loader.loadTypeDefinitionsFrom(url);
    System.out.println(scheme);
  }

  ATLASImplementation implementation;
  private Document doc;
  private Set unresolvedNames;
  private Set names;
  private static Map loadedSchemes = new HashMap(11);

  // standard attributes
  final static String NAME = "name";
  final static String REF = "ref";
  final static String ROLE = "role";
  final static String MULTIPLE = "hasIndefiniteCardinality";
  final static String LOCATION = "location";
  final static String WITHNAME = "withName";

  // other attributes
  final static String CT = "containedType";
  final static String CHILDREN_ROLE = "byChildrenWithRole";

  // element names
  final static String IMPORT = "Import";
  final static String TYPES = "TypeDefinitions";
  final static String CORPUS = "CorpusType";
  final static String SIGNAL = "SignalType";
  final static String SIGNALGROUP = "SignalGroupType";
  final static String ANCHOR = "AnchorType";
  final static String REGION = "RegionType";
  final static String ANNOTATION = "AnnotationType";
  final static String ANALYSIS = "AnalysisType";
  final static String PARAMETER = "ParameterType";
  final static String CONTENT = "ContentType";
  final static String FEATURE = "FeatureType";
  final static String CHILDREN = "ChildrenType";
  final static String REGION_DEFINED_AS = "RegionDefinedAs";
  final static String CONTENT_DEFINED_AS = "ContentDefinedAs";
  final static String DEF_CONTENT = "DefinesContentAs";
  final static String DEF_REGION = "DefinesRegionAs";

  // other constants
  final static String TYPE = "Type";
  final static String UNEEDED_ROLE = ATLASType.NULL_ROLE;
}

