/*
 * MAIA
 * Meta-Annotation Infrastructure for ATLAS
 * Author: Chris Laprun
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. MAIA and ATLAS
 * are experimental systems.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.maia;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.type.*;

import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Chris Laprun
 * @version $Revision: 1.7 $
 *
 * @since 2.0 beta 4
 */
public class MAIAScheme {
  public MAIAScheme(String name, URL location) {
    this.name = name;
    this.location = location;
    repository = new ATLASTypeRepository();
  }

  public String getName() {
    return name;
  }

  public URL getLocation() {
    return location;
  }

  public String toString() {
    return repository.display();
  }

  public boolean addImportedScheme(String name, MAIAScheme scheme) {
    return scheme != importedSchemes.put(name, scheme);
  }

  public boolean removeImportedScheme(String name) {
    return importedSchemes.remove(name) != null;
  }

  public ATLASType getATLASType(ATLASClass aClass, String name) {
    int colonPosition = name.lastIndexOf(':');
    if (colonPosition == -1) {
      return repository.getTypeFor(aClass, name);
    } else {
      String schemeName = name.substring(0, colonPosition);
      String typeName = name.substring(colonPosition + 1);
      MAIAScheme definingScheme = (MAIAScheme) importedSchemes.get(schemeName);
      if (definingScheme == null)
        throw new IllegalArgumentException("Unknown scheme: '" + schemeName + "'");
      return definingScheme.getATLASType(aClass, typeName);
    }
  }

  /**
   * Provides an Iterator over the ATLASTypes with the specified ATLASClass defined in this MAIAScheme.
   *
   * @param aClass the ATLASClass of the ATLASTypes to be iterated over
   * @return an Iterator over the ATLASTypes with the specified ATLASClass defined in this MAIAScheme.
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverTypesWith(ATLASClass aClass) {
    return repository.iteratorOverTypesWith(aClass);
  }

  public AnalysisType getAnalysisType(String name) {
    return (AnalysisType) getATLASType(ATLASClass.ANALYSIS, name);
  }

  /**
   * Provides an Iterator over the AnalysisTypes defined in this MAIAScheme.
   *
   * @return an Iterator over the AnalysisTypes defined in this MAIAScheme.
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverAnalysisTypes() {
    return iteratorOverTypesWith(ATLASClass.ANALYSIS);
  }

  public AnchorType getAnchorType(String name) {
    return (AnchorType) getATLASType(ATLASClass.ANCHOR, name);
  }

  /**
   * Provides an Iterator over the AnchorTypes defined in this MAIAScheme.
   *
   * @return an Iterator over the AnchorTypes defined in this MAIAScheme.
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverAnchorTypes() {
    return iteratorOverTypesWith(ATLASClass.ANCHOR);
  }

  public AnnotationType getAnnotationType(String name) {
    return (AnnotationType) getATLASType(ATLASClass.ANNOTATION, name);
  }

  /**
   * Provides an Iterator over the AnnotationTypes defined in this MAIAScheme.
   *
   * @return an Iterator over the AnnotationTypes defined in this MAIAScheme.
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverAnnotationTypes() {
    return iteratorOverTypesWith(ATLASClass.ANNOTATION);
  }

  public ChildrenType getChildrenType(String name) {
    return (ChildrenType) getATLASType(ATLASClass.CHILDREN, name);
  }

  /**
   * Provides an Iterator over the ChildrenTypes defined in this MAIAScheme.
   *
   * @return an Iterator over the ChildrenTypes defined in this MAIAScheme.
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverChildrenTypes() {
    return iteratorOverTypesWith(ATLASClass.CHILDREN);
  }

  public ContentType getContentType(String name) {
    return (ContentType) getATLASType(ATLASClass.CONTENT, name);
  }

  /**
   * Provides an Iterator over the ContentTypes defined in this MAIAScheme.
   *
   * @return an Iterator over the ContentTypes defined in this MAIAScheme.
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverContentTypes() {
    return iteratorOverTypesWith(ATLASClass.CONTENT);
  }

  public CorpusType getCorpusType(String name) {
    return (CorpusType) getATLASType(ATLASClass.CORPUS, name);
  }

  /**
   * Provides an Iterator over the CorpusTypes defined in this MAIAScheme.
   *
   * @return an Iterator over the CorpusTypes defined in this MAIAScheme.
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverCorpusTypes() {
    return iteratorOverTypesWith(ATLASClass.CORPUS);
  }

  public FeatureType getFeatureType(String name) {
    return (FeatureType) getATLASType(ATLASClass.FEATURE, name);
  }

  /**
   * Provides an Iterator over the FeatureTypes defined in this MAIAScheme.
   *
   * @return an Iterator over the FeatureTypes defined in this MAIAScheme.
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverFeatureTypes() {
    return iteratorOverTypesWith(ATLASClass.FEATURE);
  }

  public ParameterType getParameterType(String name) {
    return (ParameterType) getATLASType(ATLASClass.PARAMETER, name);
  }

  /**
   * Provides an Iterator over the ParameterTypes defined in this MAIAScheme.
   *
   * @return an Iterator over the ParameterTypes defined in this MAIAScheme.
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverParameterTypes() {
    return iteratorOverTypesWith(ATLASClass.PARAMETER);
  }

  public RegionType getRegionType(String name) {
    return (RegionType) getATLASType(ATLASClass.REGION, name);
  }

  /**
   * Provides an Iterator over the RegionTypes defined in this MAIAScheme.
   *
   * @return an Iterator over the RegionTypes defined in this MAIAScheme.
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverRegionTypes() {
    return iteratorOverTypesWith(ATLASClass.REGION);
  }

  public SignalType getSignalType(String name) {
    return (SignalType) getATLASType(ATLASClass.SIGNAL, name);
  }

  /**
   * Provides an Iterator over the SignalTypes defined in this MAIAScheme.
   *
   * @return an Iterator over the SignalTypes defined in this MAIAScheme.
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverSignalTypes() {
    return iteratorOverTypesWith(ATLASClass.SIGNAL);
  }

  protected boolean registerType(ATLASType type) {
    return repository.registerType(type);
  }

  private String name;
  private URL location;
  private ATLASTypeRepository repository;
  private Map importedSchemes = new HashMap(3);
}
