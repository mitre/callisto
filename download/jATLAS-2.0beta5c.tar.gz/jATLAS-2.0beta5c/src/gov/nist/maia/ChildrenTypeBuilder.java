/*
 * Created by IntelliJ IDEA.
 * User: claprun
 * Date: Sep 3, 2002
 * Time: 2:43:28 PM
 * To change template for new class use
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package gov.nist.maia;

import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.ChildrenType;
import gov.nist.atlas.util.ATLASImplementation;
import org.dom4j.Element;

class ChildrenTypeBuilder extends ATLASTypeBuilder {
  public ChildrenTypeBuilder(ATLASImplementation implementation, ATLASTypeBuilderFactory builderFactory, MAIAScheme scheme) {
    super(implementation, builderFactory, scheme);
  }

  ATLASType build(Element element) {
    ChildrenType type = factory.createEmptyChildrenType(null, getNameOrRef(element), scheme);
    scheme.registerType(type);

    buildMultipleFor(element.elementIterator(MAIALoader.ANNOTATION),
        builderFactory.getAnnotationTypeBuilder(scheme), type);

    return type;
  }
}
