/*
 * MAIA
 * Meta-Annotation Infrastructure for ATLAS
 * Author: Chris Laprun
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.maia;

import gov.nist.atlas.util.ATLASImplementation;

import java.util.HashMap;
import java.util.Map;

abstract class ATLASTypeBuilderFactory {
  final static ATLASTypeBuilderFactory getFactoryFor(ATLASImplementation implementation) {
    ATLASTypeBuilderFactory factory = (ATLASTypeBuilderFactory) factories.get(implementation);
    if (factory == null) {
      factory = new DefaultATLASTypeBuilderFactory(implementation);
      factories.put(implementation, factory);
    }
    return factory;
  }

  abstract AnalysisTypeBuilder getAnalysisTypeBuilder(MAIAScheme scheme);

  abstract AnchorTypeBuilder getAnchorTypeBuilder(MAIAScheme scheme);

  abstract AnnotationTypeBuilder getAnnotationTypeBuilder(MAIAScheme scheme);

  abstract ChildrenTypeBuilder getChildrenTypeBuilder(MAIAScheme scheme);

  abstract ContentTypeBuilder getContentTypeBuilder(MAIAScheme scheme);

  abstract CorpusTypeBuilder getCorpusTypeBuilder(MAIAScheme scheme);

  abstract FeatureTypeBuilder getFeatureTypeBuilder(MAIAScheme scheme);

  abstract ParameterTypeBuilder getParameterTypeBuilder(MAIAScheme scheme);

  abstract RegionTypeBuilder getRegionTypeBuilder(MAIAScheme scheme);

  abstract SignalTypeBuilder getSignalTypeBuilder(MAIAScheme scheme);

  abstract SignalGroupTypeBuilder getSignalGroupTypeBuilder(MAIAScheme scheme);

  private final static Map factories = new HashMap(7);
}
