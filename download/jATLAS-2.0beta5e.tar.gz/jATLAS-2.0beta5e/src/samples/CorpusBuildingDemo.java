/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package samples;

import gov.nist.atlas.Analysis;
import gov.nist.atlas.Anchor;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.CorporaManager;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.MIMEClass;
import gov.nist.atlas.Region;
import gov.nist.atlas.Signal;
import gov.nist.atlas.io.xml.AIFXMLExport;
import gov.nist.atlas.ref.AnchorRef;
import gov.nist.atlas.ref.ATLASRef;
import gov.nist.atlas.ref.AnnotationRef;
import gov.nist.atlas.util.ATLASElementFactory;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.ATLASImplementationManager;
import gov.nist.atlas.util.RoleWrapper;
import gov.nist.maia.MAIALoader;
import gov.nist.maia.MAIAScheme;

import java.io.File;
import java.net.URL;
import java.util.logging.Logger;

/**
 * A sample application demonstrating how a Corpus would be built using jATLAS.
 *
 * For example, to run the demo:
 * java CorpusBuildingDemo /users/frodo/corpus.aif.xml
 *
 * @author Christophe Laprun
 * @version $Revision: 1.2 $
 */
public class CorpusBuildingDemo {
  public static void main(String[] args) {
    CorpusBuildingDemo app = new CorpusBuildingDemo();

    long initMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();

    if (args.length != 1) {
      System.err.println("Usage: java CorpusBuildingDemo <AIF output file>");
      System.exit(-1);
    }

    File maiaFile = new File("CorpusBuildingDemo.maia.xml");
    URL url = null;
    try {
      url = maiaFile.toURL();
    } catch (Exception ex) {
      ex.printStackTrace();
    }

    /*
      In order to create ATLASElements, we need to load the MAIA type definition
      in which the ATLASTypes to be used for our particular application are
      defined. These types are gathered in a MAIAScheme instance which records
      all the types defined in the MAIA type definition.
    */
    MAIAScheme scheme = app.loadMAIATypeDefinitionsFrom(url);

    /*
      Next, we create a Corpus composed of the transcription of 5 words from an
      audio file, passing it the MAIAScheme containing all the appropriate
      type definitions...
    */
    Corpus corpus = app.createCorpus(scheme);

    File out = new File(args[0]);
    try {
      url = out.toURL();
    } catch (Exception ex) {
      ex.printStackTrace();
    }

    /*
      ... and save it to AIF in an XML file named after the argument passed to
      the application.
    */
    app.exportCorpus(url, corpus);

    /*
      To make sure that everything went OK (this step is by no mean required), we
      reload the Corpus from the AIF file...
    */
    corpus = null;
    corpus = app.reloadCorpus(url);

    /*
      ... and add a new sentence Annotation made up from the set of words that
      we previously defined...
    */
    app.addSentenceAnnotation(corpus);

    /*
      ... and export it again to AIF! What a blast! :)
    */
    app.exportCorpus(url, corpus);

    System.out.println("Printing out the Corpus:");
    // the AIF version of an ATLASElement can be obtained via the asAIFString method
    System.out.println("corpus = " + corpus.asAIFString());
    System.out.println("Used memory= " + ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory())-initMem));
  }

  private void addSentenceAnnotation(Corpus corpus) {
    System.out.println("Adding a 'sentence' Annotation composed of the already created words.\n");
    Analysis sentenceAnalysis = corpus.getAnalysisWithRole("sentences");
    Analysis wordAnalysis = corpus.getAnalysisWithRole("words");
    ATLASElementSet words = wordAnalysis.getAnnotationsWithType("word");
    factory.createAnnotation("sentence", sentenceAnalysis, words, words);
  }

  public CorpusBuildingDemo() {
    /*
      Retrieve the implementation which is going to be used for the Corpus. We
      are using here the default implementation provided by jATLAS.
    */
    implementation = ATLASImplementationManager.getDefaultImplementation();

    /*
      Retrieve the ATLASElement factory associated with the chosen
      implementation. This factory is used to create ATLAS elements while
      ensuring that the correct implementation is used
    */
    factory = ATLASElementFactory.getFactoryFor(implementation);
    System.out.println("Initializing done!");
  }

  private MAIAScheme loadMAIATypeDefinitionsFrom(URL url) {
    /*
      Create a MAIALoader to load type definition from a MAIA file. An
      ATLASImplementation is passed to specify which implementaiton to use.
    */
    MAIALoader loader = new MAIALoader(implementation);

    /*
      Load type definitions from a MAIA file. The types are created and stored
      in a repository. After this load operation, the types contained in the
      MAIA definition located at the given URL are available to jATLAS
      applications.
    */
    MAIAScheme scheme = loader.loadTypeDefinitionsFrom(url);
    System.out.println("MAIA type definition loaded.");
    return scheme;
  }

  private Corpus createCorpus(MAIAScheme scheme) {
    System.out.println("Creating Corpus:");
    long startTime = System.currentTimeMillis();

    String[] wordsParam = new String[]{"She", "had", "a", "blue", "dog"};
    final String ANCHOR_TYPE = "offset";
    final String PARAMETER_ROLE = "int";

    /*
      Create a Corpus of type "simple". Note that we don't need to explicitely
      create Analysis elements, it is taken care of when the Corpus is created.
      As a general rule, when it is possible to automatically create subordinate
      elements from type information, the factory methods do so. In our present
      case, createCorpus actually creates the subordinate Analysis elements.
    */
    Corpus corpus = factory.createCorpus("simple", scheme);


    /*
      Retrieves the Analysis contained in the Corpus we just created and that
      is associated with the role "words".
    */
    Analysis words = corpus.getAnalysisWithRole("words");
    System.out.println("\tAnalysis of type 'words' created.");

    // Create the signal
    Signal signal = factory.createSimpleSignal("audio", corpus, MIMEClass.AUDIO, "ogg", null, null, "file://somefile.ogg");
    System.out.println("\tAudio signal created.");


    // Create anchors
    /*
      Similarly to what is done for Analysis, the subordinate Parameters are
      automatically created for Anchors with a default value.
    */
    Anchor anc1 = factory.createAnchor(ANCHOR_TYPE, corpus, signal);
    anc1.setValueOfParameterWithRole("0", PARAMETER_ROLE);

    Anchor anc2 = factory.createAnchor(ANCHOR_TYPE, corpus, signal);
    anc2.setValueOfParameterWithRole("10", PARAMETER_ROLE);

    Anchor anc3 = factory.createAnchor(ANCHOR_TYPE, corpus, signal);
    anc3.setValueOfParameterWithRole("20", PARAMETER_ROLE);

    Anchor anc4 = factory.createAnchor(ANCHOR_TYPE, corpus, signal);
    anc4.setValueOfParameterWithRole("30", PARAMETER_ROLE);

    Anchor anc5 = factory.createAnchor(ANCHOR_TYPE, corpus, signal);
    anc5.setValueOfParameterWithRole("40", PARAMETER_ROLE);

    Anchor anc6 = factory.createAnchor(ANCHOR_TYPE, corpus, signal);
    anc6.setValueOfParameterWithRole("50", PARAMETER_ROLE);
    System.out.println("\tAnchors of type 'offset' created.");


    // Create regions
    /*
      Anchors need to be wrapped in an AnchorRef to specify the role they play
      in the context of the referencing Region since a given Anchor can be
      reused in different Regions with different roles. For example, the "anc2"
      Anchor is referenced with the role "end" in the "reg1" Region and with
      the role "start" in the "reg2" Region.
    */
    AnchorRef start = ATLASRef.createAnchorRef(anc1, "start");
    AnchorRef end = ATLASRef.createAnchorRef(anc2, "end");
    Region reg1 = factory.createRegion("interval", corpus, null, null, new AnchorRef[]{start, end});

    start = ATLASRef.createAnchorRef(anc2, "start");
    end = ATLASRef.createAnchorRef(anc3, "end");
    Region reg2 = factory.createRegion("interval", corpus, null, null, new AnchorRef[]{start, end});

    start = ATLASRef.createAnchorRef(anc3, "start");
    end = ATLASRef.createAnchorRef(anc4, "end");
    Region reg3 = factory.createRegion("interval", corpus, null, null, new AnchorRef[]{start, end});

    start = ATLASRef.createAnchorRef(anc4, "start");
    end = ATLASRef.createAnchorRef(anc5, "end");
    Region reg4 = factory.createRegion("interval", corpus, null, null, new AnchorRef[]{start, end});

    start = ATLASRef.createAnchorRef(anc5, "start");
    end = ATLASRef.createAnchorRef(anc6, "end");
    Region reg5 = factory.createRegion("interval", corpus, null, null, new AnchorRef[]{start, end});
    System.out.println("\tRegions of type 'interval' created.");

    // Create annotations
    /*
      Regions also need to be wrapped in RegionRef in order to be referenced
      in the context of Annotations in order to be able to reuse them with
      different roles in different contexts.
    */
    Annotation ann1 = factory.createAnnotation("word", words, ATLASRef.createRegionRef(reg1, "interval"));
    ann1.getContent().setValueOfParameterWithRole(wordsParam[0], "string");

    Annotation ann2 = factory.createAnnotation("word", words, ATLASRef.createRegionRef(reg2, "interval"));
    ann2.getContent().setValueOfParameterWithRole(wordsParam[1], "string");

    Annotation ann3 = factory.createAnnotation("word", words, ATLASRef.createRegionRef(reg3, "interval"));
    ann3.getContent().setValueOfParameterWithRole(wordsParam[2], "string");

    Annotation ann4 = factory.createAnnotation("word", words, ATLASRef.createRegionRef(reg4, "interval"));
    ann4.getContent().setValueOfParameterWithRole(wordsParam[3], "string");

    Annotation ann5 = factory.createAnnotation("word", words, ATLASRef.createRegionRef(reg5, "interval"));
    ann5.getContent().setValueOfParameterWithRole(wordsParam[4], "string");
    System.out.println("\tAnnotations of type 'word' created.");

    System.out.println("Done.");
    System.out.println("Corpus creation time: " + (System.currentTimeMillis() - startTime) + " ms\n");
    return corpus;
  }

  private void exportCorpus(URL url, Corpus corpus) {
    long startTime = System.currentTimeMillis();
    System.out.println("Exporting Corpus to AIF.");
    AIFXMLExport export = new AIFXMLExport(url);
    export.save(corpus);
    System.out.println("Done.");
    System.out.println("Corpus exporting time: " + (System.currentTimeMillis() - startTime) + " ms\n");
  }

  private Corpus reloadCorpus(URL url) {
    long startTime = System.currentTimeMillis();
    System.out.println("Reloading Corpus from AIF.");
    Corpus corpus = CorporaManager.loadCorpus(url, implementation);
    System.out.println("Done.");
    System.out.println("Corpus reload time: " + (System.currentTimeMillis() - startTime) + " ms\n");
    return corpus;
  }

  private final ATLASImplementation implementation;
  private final ATLASElementFactory factory;
}
