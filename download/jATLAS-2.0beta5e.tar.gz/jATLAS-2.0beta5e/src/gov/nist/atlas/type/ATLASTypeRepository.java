/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.type;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.util.FilteredIterator;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Collection;
import java.util.Collections;


/**
 * A repository for registered ATLASTypes. Types are accessed via the MAIAScheme object representing the MAIA scheme
 * in which they were defined. ATLASTypeRepository organizes types inside a MAIAScheme and applications should deal with
 * MAIAScheme and not ATLASTypeRepository.
 *
 * @version $Revision: 1.2 $
 * @author Chris Laprun, Sylvain Pajot
 * @see gov.nist.maia.MAIAScheme
 */
public class ATLASTypeRepository {
  /**
   * Retrieves the ATLASType for the specified ATLASClass of elements,
   * associated with the given name.
   *
   * @param clazz the ATLASClass of the type to be retrieved
   * @param name the name of the ATLASType to be retrieved
   * @return the ATLASType of the specified ATLASClass with the specified name
   */
  public ATLASType getTypeFor(ATLASClass clazz, String name) {
    return (ATLASType) types.get(new ATSimpleKey(clazz, name)); // optimize?
  }

  /**
   * Retrieves all the types contained in this ATLASTypeRepository.
   *
   * @return an unmodifiable Collection containing the ATLASTypes registered with this ATLASTypeRepository.
   * @since 2.0 Beta 6
   */
  public Collection getAllTypes() {
    return Collections.unmodifiableCollection(types.values());
  }

  /**
   * Provides an Iterator over the contained types with the specified ATLASClass.
   *
   * @param aClass the ATLASClass of elements which types are to be iterated over
   * @return an Iterator over the types with the specified ATLASClass
   * @since 2.0 Beta 6
   */
  public Iterator iteratorOverTypesWith(final ATLASClass aClass) {
    return new FilteredIterator(getAllTypes().iterator(), new FilteredIterator.FilteringStrategy() {
      public boolean filter(Object object) throws IllegalArgumentException {
        if (object instanceof ATLASType) {
          ATLASType type = (ATLASType) object;
          return !aClass.equals(type.getATLASClass());
        }
        throw new IllegalArgumentException("This FilteringStrategy can only handle ATLASElements.");
      }
    });
  }

  public ATLASTypeRepository() {
    this(37);
  }

  public ATLASTypeRepository(int initialSize) {
    types = new HashMap(initialSize); // FIX-ME: make sure that a prime is used?
  }

  /**
   * Registers the specified type in the repository.
   *
   * @param type the type to register
   * @return <code>true</code> if the registration process went well,
   *         <code>false</code> otherwise (invalid type, type already
   *         registered, etc.)
   */
  public boolean registerType(ATLASType type) {
    if (type == null)
      throw new IllegalArgumentException("You cannot register null types.");
    String name = type.getName();
    ATLASClass clazz = type.getATLASClass();
    if (getTypeFor(clazz, name) != null || name.equals("")) return false;
    types.put(new ATSimpleKey(clazz, name), type);
    return true;
  }

  /**
   * Creates a String suited for the display of the registred ATLASTypes.
   *
   * @return a String suited for the display of the registred ATLASTypes
   */
  public String display() {
    StringBuffer sb = new StringBuffer("Registered types:\n");
    Iterator i = (types.values()).iterator();
    ATLASType t;
    while (i.hasNext()) {
      t = (ATLASType) i.next();
      sb.append("====\n" + t.toString() + "\n");
    }
    return sb.toString();
  }

  private Map types;
}



