/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.type;

import gov.nist.atlas.ref.RegionRef;

/**
 *
 * @author Christophe Laprun
 * @version $Revision: 1.2 $
 */
public interface AnnotationType extends ATLASType {

  void checkInitParameters(RegionRef region);

  boolean canRegionBeDefinedByChildren();

  boolean canContentBeDefinedByChildren();

  boolean canBeDefinedByChildren(AnnotationChildrenType.SubType kind);

  String getRoleForRegionDefiningChildren();

  String getRoleForContentDefiningChildren();

  String getRoleForChildrenWith(AnnotationChildrenType.SubType kind);

  /**
   *
   * @return
   *
   * @since 2.0 beta 4
   */
  ContentType getTypeForContent();

  /**
   *
   * @return
   *
   * @since 2.0 beta 4
   */
  RegionType getTypeForRegion();


  /**
   *
   * @return
   *
   * @since 2.0 beta 4
   */
  String getRoleForRegion();

  /**
   *
   * @return
   *
   * @since 2.0 beta 4
   */
  String getRoleForContent();

  /**
   *
   * @param definedContentType
   * @param childrenRole
   *
   * @since 2.0 beta 4
   */
  void setContentDefiningChildren(ContentType definedContentType, String childrenRole);

  /**
   *
   * @param definedRegionType
   * @param childrenRole
   *
   * @since 2.0 beta 4
   */
  void setRegionDefiningChildren(RegionType definedRegionType, String childrenRole);
}



