/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.type;

import gov.nist.atlas.ATLASAccessException;
import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.DefaultConstraintManager;
import gov.nist.atlas.Metadata;
import gov.nist.atlas.spi.TypeImplementationDelegate;
import gov.nist.atlas.util.ATLASElementSetFactory;
import gov.nist.atlas.util.ATLASElementSetProperties;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.ATLASImplementationManager;
import gov.nist.atlas.util.FilteredIterator;
import gov.nist.atlas.util.MutableATLASElementSet;
import gov.nist.atlas.util.RoleAddressable;
import gov.nist.atlas.util.SortableMap;
import gov.nist.maia.MAIAScheme;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


/**
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public abstract class AbstractATLASType extends DefaultConstraintManager implements ATLASType {
  protected AbstractATLASType(ATLASType superType, String name, MAIAScheme scheme, TypeImplementationDelegate delegate) {
    this.name = name;
    hash = HashUtility.computeSimpleHashFor(getATLASClass(), name);
    if (delegate == null)
      this.delegate = ATLASImplementationManager.getDefaultImplementation().newTypeDelegate();
    else
      this.delegate = delegate;
    this.superType = superType;
    this.scheme = scheme;
  }

  public int compareTo(Object other) {
    if (other == this)
      return 0;
    ATLASType type = (ATLASType) other;
    int result = getATLASClass().compareTo(type.getATLASClass());
    return ((result != 0) ? result : name.compareTo(type.getName()));
  }

  public boolean equals(Object obj) {
    return compareTo(obj) == 0;
  }

  public final String getName() {
    return name;
  }

  public String getQualifiedName() {
    return scheme.getName() + ":" + name;
  }

  public MAIAScheme getMAIAScheme() {
    return scheme;
  }

  public ATLASType getSuperType() {
    return superType;
  }

  public ATLASImplementation getATLASImplementation() {
    return delegate.getATLASImplementation();
  }

  public boolean canSetMetadata(Metadata metadata) {
    return true; // FIX-ME maybe also add hasMetadata
  }

  public boolean canSetSubordinateWithRole(ATLASElement element, String role) {
    return (element != null
        && element.getATLASType().equals(getTypeOfSubordinateWith(role)));
  }

  public boolean canAddToChildrenWithRole(ATLASElement element, String role) {
    return getTypeOfChildrenWith(role).canAddToSubordinateSet(element);
  }

  public boolean canRemoveFromChildrenWithRole(ATLASElement element, String role) {
    return getTypeOfChildrenWith(role).canRemoveFromSubordinateSet(element);
  }

  public boolean canAddToSubordinateSet(ATLASElement newSubordinate) {
    return getSubordinateSetDefinitionFor(newSubordinate).canAdd();
  }

  public boolean canRemoveFromSubordinateSet(ATLASElement subordinate) {
    return getSubordinateSetDefinitionFor(subordinate).canRemove();
  }

  private final OptionalChildrenDefinition getSubordinateSetDefinitionFor(ATLASElement subordinate) {
    return getSubordinateSetDefinitionFor((subordinate != null) ?
        subordinate.getATLASType() : null);
  }

  public ATLASType getContainedTypeInChildrenWith(String role) {
    ChildrenType childrenType = getTypeOfChildrenWith(role);
    return childrenType.getContainedElementsType();
  }

  public int getSubordinateNumber() {
    return requiredChildDefinitions.size();
  }

  public int getRequiredChildrenNumber(ATLASClass clazz) {
    RequiredChildClassInfo ci = (RequiredChildClassInfo) requiredChildClassInfos.get(clazz);
    return (ci == null) ? 0 : ci.getCount();
  }

  public int getSubordinateSetNumber() {
    return optionalChildrenDefinitions.size();
  }

  /**
   * Returns the list of the roles associated with required children with the
   * specified ATLASClass.
   *
   * @param clazz
   * @return
   *
   */
  protected List getRolesForRequiredChildrenWith(ATLASClass clazz) {
    RequiredChildClassInfo ci = (RequiredChildClassInfo) requiredChildClassInfos.get(clazz);
    if (ci != null)
      return ci.getDefinedRoles();
    return Collections.EMPTY_LIST;
  }

  public ATLASType getTypeOfSubordinateWith(String role) {
    if (!requiredChildDefinitions.containsKey(role))
      throw new ATLASAccessException("No subordinate with role " + role
          + " is defined for elements with this " + shortDescription()); // EH
    return ((RequiredChildDefinition) requiredChildDefinitions.get(role)).getType();
  }

  public ChildrenType getTypeOfChildrenWith(String role) {
    ATLASType potentialChildrenType = getTypeOfSubordinateWith(role);
    if (potentialChildrenType instanceof ChildrenType)
      return (ChildrenType) potentialChildrenType;
    else
      throw new ATLASAccessException("No Children with role " + role
          + " is defined for elements with this " + shortDescription()); // EH
  }

  public Iterator getDefinedRolesForSubordinates() {
    return requiredChildDefinitions.keySet().iterator();
  }

  public Iterator getDefinedRolesForChildren() {
    /*
      A little tricky here... :) First, filter the entries of requiredChildDefinions to only keep those having a
      ChildrenType as value. Then, we need to redefine next on FilteredIterator to return only the key and not the entry!
    */
    return new FilteredIterator(requiredChildDefinitions.entrySet().iterator(), new FilteredIterator.FilteringStrategy() {
      public boolean filter(Object object) throws IllegalArgumentException {
        Map.Entry entry = (Map.Entry) object;
        RequiredChildDefinition reqChildDef = (RequiredChildDefinition) entry.getValue();
        return !(reqChildDef.getType() instanceof ChildrenType);
      }
    }) {
      public Object next() {
        Map.Entry entry = (Map.Entry) super.next();
        return entry.getKey();
      }
    };
  }

  /*public Iterator getSortedRequiredChildDefinitions(Comparator comparator) {
    return requiredChildDefinitions.sortedKeys(comparator);
  }*/

  public Iterator getContainedTypesInSubordinateSets() {
    return optionalChildrenDefinitions.keySet().iterator();
  }

  /*public Iterator getSortedOptionalChildrenDefinitions(Comparator comparator) {
    return optionalChildrenDefinitions.sortedKeys(comparator);
  }*/

  public final int hashCode() {
    return hash;
  }

  /* --- Description methods --- */

  public String toString() {
    StringBuffer sb = new StringBuffer(shortDescription());
    if (!requiredChildDefinitions.isEmpty())
      sb.append("\nfixed:\n").append(requiredChildDefinitions);
    if (!optionalChildrenDefinitions.isEmpty())
      sb.append("\nmultiple:\n").append(optionalChildrenDefinitions);
    return sb.toString();
  }

  public String shortDescription() {
    return new StringBuffer(getATLASClass().getName()).append("Type named '").append(name).append("'").toString();
  }

  /* --- Validation methods --- */

  /**
   * Check that the appropriate number of elements are passed for the
   * given ATLASClass
   *
   * @param c the ATLASClass of the elements which number is to be checked
   * @param array the array of elements which size is to be checked
   *
   * @throws java.lang.IllegalArgumentException if the number of element is incorrect
   */
  protected final void checkNumber(ATLASClass c, ATLASElement[] array) {
    int number = (array != null) ? array.length : 0;
    int n = getRequiredChildrenNumber(c);
    if (n != number)
      throw new IllegalArgumentException(
          new StringBuffer("Error: ").append(n).append(" ").append(c.getName())
          .append("(s) required; ").append(number).append(" given for ")
          .append(shortDescription()).toString()
      );
  }

  /**
   * Check that the roles are correct with respect to this ATLASType for the
   * given RoleAddressable elements.
   *
   * @param array an array containing the elements which roles are to be checked
   *
   * @throws java.lang.IllegalArgumentException if the roles of the specified elements are incorrect
   */
  protected final void checkRoles(RoleAddressable[] array) {
    if (array != null) {
      String role = null;
      for (int i = 0; i < array.length; i++) {
        RoleAddressable roleAddressable = array[i];
        if (roleAddressable == null)
          throw new IllegalArgumentException("Null elements cannot be used to initialize elements with this ATLASType ["
              + getName() + "]");
        role = roleAddressable.getRole();
        if (!canContainFixedElementWith(role))
          throw new IllegalArgumentException(
              new StringBuffer("Error: ").append(roleAddressable)
              .append("' cannot be added when trying to create ")
              .append(getATLASClass().getName()).append("s of type '")
              .append(getName()).append("'. Allowed roles are: ")
              .append(getRolesForRequiredChildrenWith(roleAddressable.getElement().getATLASClass())).toString()
          );
      }
    }
  }

  /**
   * Determines if the specified role is still available for this ATLASType.
   *
   * @param role the role whic availabilty is checked
   *
   * @since 2.0 beta 4
   */
  protected void checkRoleAvailability(String role) {
    if (requiredChildDefinitions.containsKey(role))
      throw new IllegalArgumentException("Role '" + role + "' has already been " +
          "defined for " + this); // EH
  }

  public boolean canContainFixedElementWith(String role) {
    return requiredChildDefinitions.containsKey(role);
  }

  public boolean canContainMultipleElementWith(String role) {
    return optionalChildrenDefinitions.containsKey(role);
  }

/*
  public boolean canContainFixedElementWith(ATSimpleKey key) {
    return requiredChildDefinitions.containsKey(key);
  }

  public boolean canContainMultipleElementWith(ATMultipleKey key) {
    return optionalChildrenDefinitions.containsKey(key);
  }
*/

  /**
   * FIX-ME
   * Adds an entry in this ATLASType's internal structure, specifying that elements
   * with this ATLASType can contain an element with the specified ATLASClass
   * and role according to the rules defined in the given RequiredChildDefinition.
   *
   * @param role the role of the new mandatory subordinate
   * @param typeOfRequiredChild the type of the new required child
   *
   * @return <code>true</code> if the addition was successful, <code>false</code>
   *         otherwise.
   * @since 2.0 beta 4
   */
  public boolean addRequiredChildDefinition(String role, ATLASType typeOfRequiredChild) {
    checkRoleAvailability(role);
    requiredChildDefinitions.put(role, delegate.createRequiredChildDefinition(typeOfRequiredChild));
    modifyClassInfoWith(typeOfRequiredChild.getATLASClass(), role);
    return true;
  }

  /**
   * FIX-ME
   * Adds an entry in this ATLASType's internal structure, specifying that elements
   * with this ATLASType can contain an element with the specified ATLASClass
   * and role according to the rules defined in the given RequiredChildDefinition.
   *
   * @param typeOfContainedElements the type of the new optional children
   * @param canAdd <code>true</code> if this type allows addition of this kind of optional children, <code>false</code>
   *        otherwise
   * @param canRemove <code>true</code> if this type allows removal of this kind of optional children, <code>false</code>
   *        otherwise
   * @param sortable <code>true</code> if the new optional children need to be stored in a set that is easily sortable,
   *        <code>false</code> otherwise
   * @param byId <code>true</code> if the new optional children need to be stored in a set allowing fast access via `
   *        the element's Id, <code>false</code> otherwise
   *
   * @return <code>true</code> if the addition was successful, <code>false</code>
   *         otherwise.
   * @since 2.0 beta 4
   */
  public boolean addSurbodinateSetDefinition(ATLASType typeOfContainedElements, boolean canAdd, boolean canRemove, boolean sortable, boolean byId) {
    optionalChildrenDefinitions.put(typeOfContainedElements, delegate.createOptionalChildrenDefinition(typeOfContainedElements, canAdd, canRemove, sortable, byId));
    return true;
  }

  public RequiredChildDefinition getSubordinateDefinitionFor(String role) {
    return (role == null) ? null : (RequiredChildDefinition) requiredChildDefinitions.get(role);
  }

  public final OptionalChildrenDefinition getSubordinateSetDefinitionFor(ATLASType containedType) {
    OptionalChildrenDefinition optChildDef =
        (OptionalChildrenDefinition) optionalChildrenDefinitions.get(containedType);
    if (optChildDef == null)
      throw new ATLASAccessException("Elements of type " + getName()
          + " cannot contain elements with type " + containedType);
    return optChildDef;
  }

  public TypeImplementationDelegate getTypeImplementationDelegate() {
    return delegate;
  }

  private final void modifyClassInfoWith(ATLASClass clazz, String role) {
    if (!requiredChildClassInfos.containsKey(clazz))
      requiredChildClassInfos.put(clazz, new RequiredChildClassInfo(role));
    else {
      RequiredChildClassInfo ci = (RequiredChildClassInfo) requiredChildClassInfos.get(clazz);
      ci.addRole(role); // increment count as well
    }
  }

  /* -- <Attributes> -- */


  private static ATSimpleKey reusableSimpleKey = new ATSimpleKey(null, null);
  private static ATMultipleKey reusableMultipleKey = new ATMultipleKey(null, null);

  protected final ATSimpleKey getSimpleKeyFor(ATLASClass aClass, String role, boolean create) {
    if (create) return new ATSimpleKey(aClass, role);
    reusableSimpleKey.setHash(aClass, role);
    return reusableSimpleKey;
  }

  protected final ATMultipleKey getMultipleKeyFor(ATLASType type, String role, boolean create) {
    if (create) return new ATMultipleKey(type, role);
    reusableMultipleKey.setHash(type, role);
    return reusableMultipleKey;
  }

  /**
   * Returns a new MutableATLASElementSet to initiliaze the
   * container identified by the given ATLASType and role.
   * MOVE UP???
   *
   * @param containedType
   * @return
   */
  public MutableATLASElementSet createSubordinateSetFor(ATLASType containedType) {
    OptionalChildrenDefinition optChildDef = getSubordinateSetDefinitionFor(containedType);
    if (optChildDef == null)
      throw new ATLASAccessException("Elements with type " + containedType
          + " cannot be contained in this ATLASType [" + this + "]");

    ATLASElementSetProperties properties = new ATLASElementSetProperties();
    properties.setBooleanProperty(ATLASElementSetProperties.HEAVY_REORDERINGS,
        optChildDef.sortable());
    properties.setBooleanProperty(ATLASElementSetProperties.ACCESS_BY_ID,
        optChildDef.byId());

    return ATLASElementSetFactory.getFactoryFor(getATLASImplementation())
        .createMutableATLASElementSet(optChildDef.getType(), 11, properties);
  }

  protected static class RequiredChildClassInfo {
    RequiredChildClassInfo(String role) {
      roles.add(role);
      count = 1;
    }

    List getDefinedRoles() {
      Collections.sort(roles);
      return Collections.unmodifiableList(roles);
    }

    boolean doesRoleExist(String role) {
      return roles.contains(role);
    }

    int getCount() {
      return count;
    }

    boolean addRole(String role) {
      if (!roles.contains(role)) {
        count++;
        return roles.add(role);
      }
      return false;
    }

    List roles = new LinkedList();
    int count;
  }


  /**
   * @link aggregationByValue
   * @supplierCardinality 0..*
   */
  protected final SortableMap requiredChildDefinitions = new SortableMap();

  /**
   * @link aggregationByValue
   * @supplierCardinality 0..*
   */
  protected final SortableMap optionalChildrenDefinitions = new SortableMap();
  private final Map requiredChildClassInfos = new HashMap(7);
  private final String name;
  private final int hash;
  private TypeImplementationDelegate delegate;
  private final ATLASType superType;
  private final MAIAScheme scheme;
}



