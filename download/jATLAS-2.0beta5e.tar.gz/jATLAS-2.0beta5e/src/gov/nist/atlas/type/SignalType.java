/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.type;

import gov.nist.atlas.MIMEClass;
import gov.nist.atlas.Unit;

public interface SignalType extends ATLASType {
  /**
   * Returns the number of dimensions of the vectorial space that this
   * SignalType models.
   *
   * @return the number of dimensions for Signals of this type
   *
   * @since 2.0 beta 4 (moved from Size)
   */
  int getNumberOfDimensions();

  /**
   * Returns the names of the dimensions of the vectorial space that this
   * SignalType models.
   *
   * @return a String array containig the names of the dimensions
   *
   * @since 2.0 beta 4 (moved from Size)
   */
  String[] getDimensionNames();

  /**
   * Returns the unit of values associated with the specified dimension.
   *
   * @param name the name of the dimension which unit is to be retrieved
   *
   * @return the unit associated with the specified dimension
   *
   * @see gov.nist.atlas.Unit
   *
   * @since 2.0 beta 4 (moved from Size)
   */
  Unit getUnitForDimension(String name);

  MIMEClass getMIMEClass();

  void setMimeClass(MIMEClass mimeClass);

//  MIMEType getMIMEType();  // FIX-ME: use org.w3c.www.MIMEType??
}



