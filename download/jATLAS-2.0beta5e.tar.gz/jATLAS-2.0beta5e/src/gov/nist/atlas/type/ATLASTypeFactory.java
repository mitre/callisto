/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.type;

import gov.nist.atlas.impl.*;
import gov.nist.atlas.spi.TypeImplementationDelegate;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.ATLASImplementationManager;
import gov.nist.maia.MAIAScheme;

import java.util.HashMap;
import java.util.Map;


/**
 * Transform into a concrete class customized by an implementation as it is done
 * for ATLASElementFactory.
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun*/
public class ATLASTypeFactory {
  protected ATLASTypeFactory() {
    this.implementation = ATLASImplementationManager.getDefaultImplementation();
  }

  protected ATLASTypeFactory(ATLASImplementation implementation) {
    this.implementation = implementation;
  }

  // FIX-ME
  public RequiredChildDefinition addSimpleFragmentTo(ATLASType containedElementType, String containedElementRole, ATLASType parent) {
    AbstractATLASType ati = getMainTypeAsImplIfSecondaryIsValid(parent, containedElementType);

    ati.addRequiredChildDefinition(containedElementRole, containedElementType);
    return ati.getSubordinateDefinitionFor(containedElementRole);
  }

  // FIX-ME
  public OptionalChildrenDefinition addMultipleFragmentTo(ATLASType containedElementType, String containedElementRole, boolean canAdd, boolean canRemove, boolean sortable, boolean byId, ATLASType parent) {
    AbstractATLASType ati = getMainTypeAsImplIfSecondaryIsValid(parent, containedElementType);

    ati.addSurbodinateSetDefinition(containedElementType, canAdd, canRemove, sortable, byId);
    return ati.getSubordinateSetDefinitionFor(containedElementType);
  }

  /**
   *
   * @param type
   * @param childrenContainedType
   * @param role
   *
   * @deprecated Starting 2.0 beta 4, this method is deprecated and will throw
   *             an UnsupportedOperationException error when used. Use
   *             AnnotationType.setContentDefiningChildren instead.
   * @see AnnotationType#setContentDefiningChildren
   */
  public final void setContentDefiningChildren(AnnotationType type, AnnotationType childrenContainedType, String role) {
    throw new UnsupportedOperationException(
        "ATLASTypeFactory.setContentDefiningChildren is now deprecated. Use " +
        "AnnotationType.setContentDefiningChildren instead.");
  }

  /**
   *
   * @param type
   * @param childrenContainedType
   * @param role
   *
   * @deprecated Starting 2.0 beta 4, this method is deprecated and will throw
   *             an UnsupportedOperationException error when used. Use
   *             AnnotationType.setRegionDefiningChildren instead.
   * @see AnnotationType#setRegionDefiningChildren
   */
  public final void setRegionDefiningChildren(AnnotationType type, AnnotationType childrenContainedType, String role) {
    throw new UnsupportedOperationException(
        "ATLASTypeFactory.setRegionDefiningChildren is now deprecated. Use " +
        "AnnotationType.setRegionDefiningChildren instead.");
  }

  public AnalysisType createEmptyAnalysisType(ATLASType superType, String name, MAIAScheme scheme) {
    AnalysisType type = scheme.getAnalysisType(name);
    if (type == null) {
      TypeImplementationDelegate delegate = implementation.newTypeDelegate();
      type = new AnalysisTypeImpl(superType, name, scheme, delegate);
      delegate.setAssociatedType(type);
    }
    return type;
  }

  public AnchorType createEmptyAnchorType(ATLASType superType, String name, MAIAScheme scheme) {
    AnchorType type = scheme.getAnchorType(name);
    if (type == null) {
      TypeImplementationDelegate delegate = implementation.newTypeDelegate();
      type = new AnchorTypeImpl(superType, name, scheme, delegate);
      delegate.setAssociatedType(type);
    }
    return type;
  }

  public AnnotationType createEmptyAnnotationType(ATLASType superType, String name, MAIAScheme scheme) {
    AnnotationType type = scheme.getAnnotationType(name);
    if (type == null) {
      TypeImplementationDelegate delegate = implementation.newTypeDelegate();
      type = new AnnotationTypeImpl(superType, name, scheme, delegate);
      delegate.setAssociatedType(type);
    }
    return type;
  }

  public ChildrenType createEmptyChildrenType(ATLASType superType, String name, MAIAScheme scheme) {
    ChildrenType type = scheme.getChildrenType(name);
    if (type == null) {
      TypeImplementationDelegate delegate = implementation.newTypeDelegate();
      type = new ChildrenTypeImpl(superType, name, scheme, delegate);
      delegate.setAssociatedType(type);
    }
    return type;
  }

  public ContentType createEmptyContentType(ATLASType superType, String name, MAIAScheme scheme) {
    ContentType type = scheme.getContentType(name);
    if (type == null) {
      TypeImplementationDelegate delegate = implementation.newTypeDelegate();
      type = new ContentTypeImpl(superType, name, scheme, delegate, false);
      delegate.setAssociatedType(type);
    }
    return type;
  }

  public CorpusType createEmptyCorpusType(ATLASType superType, String name, MAIAScheme scheme) {
    CorpusType type = scheme.getCorpusType(name);
    if (type == null) {
      TypeImplementationDelegate delegate = implementation.newTypeDelegate();
      type = new CorpusTypeImpl(superType, name, scheme, delegate);
      delegate.setAssociatedType(type);
    }
    return type;
  }

  public FeatureType createEmptyFeatureType(ATLASType superType, String name, MAIAScheme scheme) {
    FeatureType type = scheme.getFeatureType(name);
    if (type == null) {
      TypeImplementationDelegate delegate = implementation.newTypeDelegate();
      type = new FeatureTypeImpl(superType, name, scheme, delegate);
      delegate.setAssociatedType(type);
    }
    return type;
  }

  public ParameterType createEmptyParameterType(ATLASType superType, String name, MAIAScheme scheme) {
    ParameterType type = scheme.getParameterType(name);
    if (type == null) {
      TypeImplementationDelegate delegate = implementation.newTypeDelegate();
      type = new ParameterTypeImpl(superType, name, scheme, delegate);
      delegate.setAssociatedType(type);
    }
    return type;
  }

  public RegionType createEmptyRegionType(ATLASType superType, String name, MAIAScheme scheme) {
    RegionType type = scheme.getRegionType(name);
    if (type == null) {
      TypeImplementationDelegate delegate = implementation.newTypeDelegate();
      type = new RegionTypeImpl(superType, name, scheme, delegate);
      delegate.setAssociatedType(type);
    }
    return type;
  }

  public SignalType createEmptySignalType(ATLASType superType, String name, MAIAScheme scheme) {
    SignalType type = scheme.getSignalType(name);
    if (type == null) {
      TypeImplementationDelegate delegate = implementation.newTypeDelegate();
      type = new SignalTypeImpl(superType, name, scheme, delegate);
      delegate.setAssociatedType(type);
    }
    return type;
  }

  public static final ATLASTypeFactory getFactoryFor(ATLASImplementation implementation) {
    ATLASTypeFactory factory = (ATLASTypeFactory) factories.get(implementation);
    if (factory == null) {
      factory = new ATLASTypeFactory(implementation);
      factories.put(implementation, factory);
    }
    return factory;
  }

  private final static Map factories = new HashMap(5);
  protected final ATLASImplementation implementation;

  private AbstractATLASType getMainTypeAsImplIfSecondaryIsValid(ATLASType mainType, ATLASType secondaryType) {
    if (secondaryType == null)
      throw new IllegalArgumentException("Must pass a valid secondary type!");
    if (mainType instanceof AbstractATLASType) {
      return (AbstractATLASType) mainType;
    } else
      throw new IllegalArgumentException("Must pass DefaultTypeImplementationDelegate main type!");
  }
}