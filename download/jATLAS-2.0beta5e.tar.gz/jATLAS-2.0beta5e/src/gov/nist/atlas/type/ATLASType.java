/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.type;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.ConstraintManager;
import gov.nist.atlas.Metadata;
import gov.nist.atlas.spi.TypeImplementationDelegate;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.MutableATLASElementSet;
import gov.nist.maia.MAIAScheme;

import java.util.Iterator;


/**
 * <p>ATLASType records information about a specific sort of ATLASElements.
 * ATLASTypes constrain the generic content model for a particular class
 * (ATLASClass) of ATLASElements in order to provide more useful entities for
 * specific applications. ATLASTypes define equivalence classes for
 * ATLASElements. All elements with the same ATLASType are members of the
 * equivalence class define by the ATLASType and share similar meta-information
 * and data structure.</p>
 *
 * <p>ATLASType provides information allowing checks to be performed before
 * manipulating ATLASElements of this ATLASType. Similarly, information about
 * the allowed structure of members of the equivalence class can be retrieved
 * also.</p>
 *
 * <p>ATLASType elements are built from MAIA definitions.</p>
 *
 * <p><strong>Example:</strong><br> A Region is a kind of ATLASElement. It is
 * associated to an ATLASType instance which records what kind of subordinates can be
 * contained/referenced and the metadata shared by instances of this type. A Region, as per the ATLAS data model, can reference
 * Anchor elements. However, this information by itself is not specific enough. Type information constrains the
 * generic content model for specific needs. We can define, for example, an "interval" Region type specifying that only
 * two Anchors should be referenced, one with the role "start" and the other
 * one with the role "end". Even more interesting is the fact that it is also
 * possible to constrain the ATLASType of subordinate elements.
 * We could specify that Anchors subordinates for our "interval" Region must
 * be of type "offset". Recording such information allows precise definition
 * of the annotation task being defined and ensures data integrity. In our
 * example, it is not possible to assign an Anchor of another type than
 * "offset" to the subordinate identified with the ATLASClass
 * ATLASClass.ANCHOR and the role "start". </p>
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public interface ATLASType extends ConstraintManager, Comparable {
  /**
   *
   * @return
   *
   * @since 2.0 beta 4
   */
  ATLASType getSuperType();

  /**
   *
   * @return
   *
   * @since 2.0 beta 4
   */
  MAIAScheme getMAIAScheme();

  /**
   * Returns this ATLASType's name.
   *
   * @return this ATLASType's name
   */
  String getName();

  /**
   * Returns this ATLASType's qualified name in the form scheme_name:name. For
   * example if this ATLASType has been defined in the context of a MAIA scheme
   * named <code>RT02</code> and its name is <code>interval</code> then its
   * qualified name will be <code>RT02:interval</code>.
   *
   * @return this ATLASType's qualified name.
   *
   * @since 2.0 beta 4
   */
  String getQualifiedName();

  /**
   * Returns the ATLASClass of which this ATLASElements with this ATLASType are
   * members.
   *
   * @return the ATLASClass of this ATLASType
   */
  ATLASClass getATLASClass();

  /**
   * Retrieves the ATLASImplementation that this ATLASType uses.
   *
   * @return the ATLASImplementation used by this ATLASType.
   *
   * @since 2.0 beta 4
   */
  ATLASImplementation getATLASImplementation();

  /**
   * Determines if the specified parent is a valid parent for ATLASElements of this
   * ATLASType. This method is used in an ATLASElement's initWith method.
   *
   * @param parent the parent to be checked
   *
   * @return <code>true</code> if the specified parent is valid,
   *         <code>false</code> otherwise.
   */
  boolean isParentValid(ATLASElement parent);

  /**
   * NOT-IMPLEMENTED YET
   *
   * @param metadata the metadata to be set
   *
   * @return <code>true</code> if the specified metadata can be set,
   *         <code>false</code> otherwise.
   */
  boolean canSetMetadata(Metadata metadata);

  /**
   * Determines if the specified ATLASElement can be set in place of the
   * subordinate identified with the given role.
   *
   * @param element the new value for the subordinate element
   * @param role    the role of subordinate element to be set, if no role has
   *                been specified in the MAIA definition for this
   *                ATLASType, the ATLASType.NULL_ROLE constant should be used
   *
   * @return  <code>true</code> if the subordinate element can be set,
   *          <code>false</code> otherwise meaning that the specified
   *          element cannot be assigned to the subordinate identified with
   *          the given role
   *
   * @see gov.nist.atlas.ATLASElement#setSubordinateWithRole(ATLASElement, String)
   * @see #NULL_ROLE
   *
   * @since 2.0 beta 4 (renamed, was canSetElementWithRole)
   */
  boolean canSetSubordinateWithRole(ATLASElement element, String role);

  /**
   * Determines if the specified element can be added to the Children
   * specified with the provided role.
   *
   * @param element the ATLASElement to be added
   * @param role the role identifying the Children to which the
   *             specified element is to be added
   *
   * @return    <code>true</code> if the addition can be performed,
   * <code>false</code> otherwise.
   *
   * @see gov.nist.atlas.ATLASElement#addToChildrenWithRole
   *
   * @since 2.0 beta 4 (renamed, was canAddElementWithRole)
   */
  boolean canAddToChildrenWithRole(ATLASElement element, String role);

  /**
   * Determines if the specified element can be removed from the Children
   * specified with the provided role.
   *
   * @param element the ATLASElement to be removed
   * @param role the role identifying the Children from which the
   *             specified element is to be removed
   *
   * @return    <code>true</code> if the removal can be performed,
   * <code>false</code> otherwise.
   *
   * @see gov.nist.atlas.ATLASElement#removeFromChildrenWithRole
   *
   * @since 2.0 beta 4 (renamed, was canRemoveElementWithRole)
   */
  boolean canRemoveFromChildrenWithRole(ATLASElement element, String role);

  /**
   * Determines if the specified element can be added to the appropriate
   * subordinate set.
   *
   * @param subordinate the ATLASElement to be added
   *
   * @return    <code>true</code> if the addition can be performed,
   * <code>false</code> otherwise.
   *
   * @see gov.nist.atlas.ATLASElement#addToSubordinateSet
   *
   * @since 2.0 beta 4
   */
  boolean canAddToSubordinateSet(ATLASElement subordinate);

  /**
   * Determines if the specified element can be removed from the appropriate
   * subordinate set.
   *
   * @param subordinate the ATLASElement to be removed
   *
   * @return    <code>true</code> if the removal can be performed,
   * <code>false</code> otherwise.
   *
   * @see gov.nist.atlas.ATLASElement#removeFromSubordinateSet
   *
   * @since 2.0 beta 4
   */
  boolean canRemoveFromSubordinateSet(ATLASElement subordinate);

  /**
   * Use this constant to identify a subordinate element which role has not been
   * explicitely specified. This happens in MAIA when a given ATLASType declares
   * it can only contain a <strong>single</strong> subordinate with a specific
   * type. In this case, a role is not required since the purpose of roles is to
   * distinguish between subordinates with the same ATLASType. When no role is
   * required, it is not needed to declare one in MAIA. To access subordinates
   * with undeclared roles, ATLASType.NULL_ROLE provides a constant so that
   * the intention of the user is made clear. <code>null</code> could have been
   * used instead but it would not been clear, when examining parameters of
   * methods that require a role, if the <code>null</code> value was intentional
   * of the result of an error.
   *
   * @deprecated To be removed if we switch to mandatory role model
   */
  String NULL_ROLE = "NULL_ROLE";

  /**
   *
   * @param role
   * @return
   *
   * @since 2.0 beta 4
   */
  RequiredChildDefinition getSubordinateDefinitionFor(String role);

  /**
   *
   * @param containedType
   * @return
   *
   * @since 2.0 beta 4
   */
  OptionalChildrenDefinition getSubordinateSetDefinitionFor(ATLASType containedType);

  /**
   * Returns the total number of fixed subordinate elements (elements with indivudual
   * role) that are contained in ATLASElement of this ATLASType.
   *
   * @return the number of fixed elements
   *
   * @since 2.0 beta 4 (renamed)
   */
  int getSubordinateNumber();

  /**
   * Returns the number of fixed subordinate elements (elements with indivudual role) with
   * the given ATLASClass, that ATLASElements of this ATLASType contain.
   *
   * @param clazz ATLASClass of fixed elements which number is requested
   *
   * @return the number of fixed elements with the given ATLASClass
   *
   * @since 2.0 beta 4 (renamed)
   *
   * @deprecated Remove???
   */
  int getRequiredChildrenNumber(ATLASClass clazz);

  /**
   * Returns the number of different types of ATLASElements with unspecified
   * cardinality that are contained in elements of this ATLASType.
   *
   * @return the number of types of subordinates with unspecified cardinality
   *
   * @since 2.0 beta 4 (renamed)
   */
  int getSubordinateSetNumber();

  /**
   * Returns the set of ATSimpleKeys allowing the identification of mandatory
   * subordinates for this ATLASType.
   *
   * @return a possibly empty set of ATSimpleKey elements
   *
   * @see <{ATSimpleKey}>
   *
   * @since 2.0 beta 4 (renamed)
   */
  Iterator getDefinedRolesForSubordinates();

  /**
   * Returns an Iterator over the roles of the Children elements defined for this ATLASType.
   *
   * @return an Iterator over the roles of the Children elements defined for this ATLASType
   * @since 2.0 Beta 6
   */
  Iterator getDefinedRolesForChildren();

  /**
   * Returns the set of ATMultipleKeys allowing the identification of mandatory
   * subordinates for this ATLASType.
   *
   * FIX-ME
   *
   * @return a possibly empty set of ATMultipleKey elements
   *
   * @see
   *
   * @since 2.0 beta 4 (renamed)
   */
  Iterator getContainedTypesInSubordinateSets();

  /**
   * Returns a set of ATSimpleKeys (identifying this ATLASType's mandatory subordinates),
   * sorted as specified by the given Comparator.
   *
   * FIX-ME
   *
   * @param comparator the Comparator according to which the keys must be sorted
   *
   * @return a possibly empty sorted set of ATSimpleKeys
   *
   * @since 2.0 beta 2, 2.0 beta 4 (renamed)
   *
   * @see <{ATSimpleKey}>
   */
//  Iterator getSortedRequiredChildDefinitions(Comparator comparator);

  /**
   * Returns a set of ATMultipleKeys (identifying this ATLASType's subordinates
   * with indefinite cardinality), sorted as specified by the given Comparator.
   *
   * @param comparator the Comparator according to which the keys must be sorted
   *
   * @return a possibly empty sorted set of ATMultipleKeys
   *
   * @since 2.0 beta 2, 2.0 beta 4 (renamed)
   *
   * @see <{ATMultipleKey}>
   */
//  Iterator getSortedOptionalChildrenDefinitions(Comparator comparator);

  /**
   * Returns the ATLASType associated with the subordinate element with the
   * specified ATLASClass and role if such an element
   * can be contained in ATLASElements associated with this ATLASType.
   *
   * @param role the role of the subordinate element
   *
   * @return the ATLASType associated with the identified subordinate
   *
   * @throws IllegalArgumentException if the couple (ATLASClass, role) does not
   * identify a subordinate that can be contained in ATLASElements of this
   * ATLASType
   */
  ATLASType getTypeOfSubordinateWith(String role);

  ATLASType getContainedTypeInChildrenWith(String role);

  ChildrenType getTypeOfChildrenWith(String role);

  TypeImplementationDelegate getTypeImplementationDelegate();

  MutableATLASElementSet createSubordinateSetFor(ATLASType containedType);

  /**
   * Returns the ATLASType associated with the subordinate element with the
   * specified ATSimpleKey if such an element
   * can be contained in ATLASElements associated with this ATLASType.
   *
   * @param key the ATSimpleKey identifying the subordinate element
   *
   * @return the ATLASType associated with the identified subordinate
   *
   * @throws IllegalArgumentException if the specified ATSimpleKey does not
   * identify a subordinate that can be contained in ATLASElements of this
   * ATLASType
   *
   * @see <{ATSimpleKey}>
   */
//  ATLASType getTypeOfRequiredChildWith(ATSimpleKey key);
}



