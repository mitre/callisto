/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.type;

/**
 * ContentType records the information associated with types of Content elements.
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public interface ContentType extends ATLASType {
  /**
   * Determines if this ContentType defines an aligned Region.
   *
   * @return <code>true</code> if this ContentType defines an aligned Region,
   *         <code>false</code> otherwise.
   */
  boolean hasAlignedRegion();

  /**
   * Specifies if this ContentType defines an aligned Region.
   *
   * @param hasAlignedRegion <code>true</code> if this ContentType should define
   *        an aligned Region, <code>false</code> otherwise.
   */
  void setAlignedRegion(boolean hasAlignedRegion);

  /**
   * Retrieves the role associated with the definition of the aligned Region, if
   * any.
   *
   * @return the role associated with the definition of the aligned Region, or
   *         <code>null</code> if this ContentType doesn't define an aligned
   *         Region.
   * @since 2.0 beta 4
   */
  String getRoleForAlignedRegion();
}



