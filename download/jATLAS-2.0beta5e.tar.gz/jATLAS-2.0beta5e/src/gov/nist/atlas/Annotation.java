/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.type.AnnotationChildrenType;
import gov.nist.atlas.type.AnnotationType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.RoleIdentifiedFeature;
import gov.nist.atlas.util.RoleIdentifiedParameter;


/**
 * <p>Annotation is the ATLAS abstraction for a linguistic annotation. It
 * captures the basic concept behind ATLAS that Annotations are the
 * association of some Content to a Region in a Signal.</p>
 * <p>An Annotation can
 * also (optionally) reference children so as to create a hierarchy of related
 * Annotations (such as the hierarchy created by the relation between a
 * sentence and its word components). This parent-children relation is
 * modelled by the Children element.</p>
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 * @author Sylvaion Pajot
 *
 * @see Region
 * @see Content
 * @see Children
 */
public interface Annotation extends ReusableATLASElement {
  /**
   * <p>Initializes this Annotation's Content's subordinate elements to the specified
   * values. The specified parameters are role-identified, this Annotation's Content type is thus able to correctly assign
   * them to their proper subordinate. Some validation is performed at this level since it is not possible to assign
   * an invalid ATLASElement to a given subordinate.</p>
   *
   * <p>The specified parameters are values that are to be assigned to this
   * Annotation's Content element.</p>
   *
   * <p><strong>Notes:</strong></p> <ul>
   * <li>The final error mechanism hasn't been specified yet but this method
   * should be atomic: either all assignments are made or none.</li>
   * <li>The subordinates that are specified as arguments to this method are
   * element with FINITE cardinality.
   * Subordinates with undetermined cardinality are assigned using other,
   * appropriate methods.</li> </ul>
   *
   * @param features    the role-identified Features to be assigned to this
   * Annotation's Content, optional (pass <code>null</code> when not needed).
   * @param parameters the role-identified Parameters to be assigned to this
   * Annotation's Content, optional (pass <code>null</code> when not needed).
   * @param alignedRegion the aligned Region associated with this
   * Annotation's Content, optional (pass <code>null</code> when not needed). See
   * Content for more details.
   *
   * @see gov.nist.atlas.util.RoleIdentifiedParameter
   * @see gov.nist.atlas.util.RoleIdentifiedFeature
   * @see gov.nist.atlas.ref.RegionRef
   * @see Content
   */
  void initContentWith(RoleIdentifiedFeature[] features, RoleIdentifiedParameter[] parameters, RegionRef alignedRegion);

  /**
   * Returns this Annotation's type as an AnnotationType object.
   *
   * @return the AnnotationType assigned to this Annotation
   */
  AnnotationType getAnnotationType();

  /**
   * Returns the Region this Annotation is associating Content to.
   *
   * @return the Region this Annotation is associating Content to
   *
   * @see Region
   */
  Region getRegion();

  /**
   * <p>Specifies that the Region of this Annotation is to be defined by the
   * Region defined by the Region-defining
   * Children element. In particular, after calling this method, subsequent
   * calls to getRegion() will return the
   * Region defined by the appropriate Children element. If a Region was
   * already present for this Annotation, it is
   * bypassed by subsequent calls to getRegion().</p>
   *
   * <p>It is important to note that, after calling this method, the Region
   * for this Annotation is re-calculated,
   * as specified by the Region-defining Children element, each time
   * getRegion() is called. For optimization or reuse
   * purposes, it might be interesting to create a new Region based on the
   * Region-defining Children that will be used
   * for subsequent calls to getRegion() instead of re-calculating it each
   * time. This is achieve by a call to rebuildRegionFromChildrenRegion().</p>
   *
   * @return    <code>true</code> if the Region of this Annotation has been
   * succesfully replaced by the Region defined by
   * the appropriate Children element, <code>false</code> otherwise
   * (this is in particular the case if there
   * aren't any Region-defining Children or this operation is not
   * permitted by this Annotation's type).
   *
   * @see Children#getDefinedRegion()
   * @see #rebuildRegionFromChildrenRegion()
   */
  boolean replaceRegionByChildrenRegion();

  /**
   * <p>Specifies that the Region of this Annotation is to be rebuilt from the
   * Region defined by the Region-defining
   * Children element. This allows for replacement of this Annotation's
   * current Region by a new Region that has been
   * calculated from the appropriate Children element. It is especially
   * efficient to call this method when, according to
   * this Annotation's type, the Region for this Annotation is supposed to be
   * defined by one of its Children elements
   * and that the Region-defining Children is considered stable (e.g. no
   * subordinates are added and/or removed). Calling
   * this method allows the calculation to take place once and for all,
   * avoiding the Region to be re-calculated each
   * time getRegion() is called.</p>
   *
   * <p>Note however that there is the possibility of de-synchronization
   * between the Region as defined by the Region-defining Children and the
   * calculated Region (this happens if subordinates are added and/or
   * removed after a call to this method. In future versions, an event-based
   * mechanism might be introduced to automatically re-calculate the Region
   * after a modification to the Children element.</p>
   *
   * <p>To sum up, this method allows users to cache the Region defined by the
   * Region-defining Children element. However,
   * the integry of this cache is not currently ensured. To be sure that the
   * Region returned by getRegion() is always the
   * one defined by the appropriate Children, call
   * replaceRegionByChildrenRegion().</p>
   *
   * @return    <code>true</code> if the Region of this Annotation has been
   * succesfully rebuilt from the Region defined by
   * the appropriate Children element, <code>false</code> otherwise
   * (this is in particular the case if there
   * aren't any Region-defining Children or this operation is not
   * permitted by this Annotation's type).
   *
   * @see Children#getDefinedRegion()
   * @see #replaceRegionByChildrenRegion()
   */
  boolean rebuildRegionFromChildrenRegion();

  /**
   * Returns the Content of this Annotation.
   *
   * @return the Content of this Annotation
   *
   * @see Content
   */
  Content getContent();

  /**
   * <p>Specifies that the Content of this Annotation is to be defined by the
   * Content defined by the Content-defining
   * Children element. In particular, after calling this method, subsequent
   * calls to getContent() will return the
   * Content defined by the appropriate Children element. If a Content was
   * already present for this Annotation, it is
   * bypassed by subsequent calls to getContent().</p>
   *
   * <p>It is important to note that, after calling this method, the Content
   * for this Annotation is re-calculated,
   * as specified by the Content-defining Children element, each time
   * getContent() is called. For optimization or reuse
   * purposes, it might be interesting to create a new Content based on the
   * Content-defining Children that will be used
   * for subsequent calls to getContent() instead of re-calculating it each
   * time. This is achieve by a call to
   * rebuildContentFromChildrenContent().</p>
   *
   * @return    <code>true</code> if the Content of this Annotation has been
   * succesfully replaced by the Content defined by
   * the appropriate Children element, <code>false</code> otherwise
   * (this is in particular the case if there
   * aren't any Content-defining Children or this operation is not
   * permitted by this Annotation's type).
   *
   * @see Children#getDefinedContent()
   * @see #rebuildContentFromChildrenContent()
   */
  boolean replaceContentByChildrenContent();

  /**
   * <p>Specifies that the Content of this Annotation is to be rebuild from
   * the Content defined by the Content-defining
   * Children element. This allows for replacement of this Annotation's
   * current Content by a new Content that has been
   * calculated from the appropriate Children element. It is especially
   * efficient to call this method when, according to
   * this Annotation's type, the Content for this Annotation is supposed to be
   * defined by one of its Children elements
   * and that the Content-defining Children is considered stable (e.g. no
   * subordinates are added and/or removed). Calling
   * this method allows the calculation to take place once and for all,
   * avoiding the Content to be re-calculated each
   * time getContent() is called.</p>
   *
   * <p>Note however that there is the possibility of de-synchronization
   * between the Content as defined by the Content-defining Children and the
   * calculated Content (this happens if subordinates are added and/or
   * removed after a call to this method. In future versions, an event-based
   * mechanism might be introduced to automatically re-calculate the Content
   * after a modification to the Children element.</p>
   *
   * <p>To sum up, this method allows users to cache the Content defined by
   * the Content-defining Children element. However,
   * the integry of this cache is not ensure for now. To be sure that the
   * Content returned by getContent() is always the
   * one defined by the appropriate Children, call
   * replaceContentByChildrenContent().</p>
   *
   * @return    <code>true</code> if the Content of this Annotation has been
   * succesfully rebuilt from the Content defined by
   * the appropriate Children element, <code>false</code> otherwise
   * (this is in particular the case if there
   * aren't any Content-defining Children or this operation is not
   * permitted by this Annotation's type).
   *
   * @see Children#getDefinedContent()
   * @see #replaceContentByChildrenContent()
   */
  boolean rebuildContentFromChildrenContent();

  /**
   * Adds the specified Annotation to the Children element identified with the
   * specified role.
   *
   * @param annotation the child Annotation to be added
   * @param role the role identifying the Children element to which the
   * specified Annotation should be added
   *
   * @return <code>true</code> if the addition was sucessful,
   * <code>false</code> otherwise.
   */
//  boolean addChildToChildrenWithRole(Annotation annotation, String role);

  /**
   * Adds the specified Annotations to the Content-defining Children element.
   *
   * @param contentDefiningAnnotations an ATLASElementSet containing the Annotations
   *        to be added to the Content-defining Children element
   *
   * @return <code>true</code> if the addition was sucessful,
   * <code>false</code> otherwise. Note that if the operation fails for any
   * Annotation in the ATLASElementSet, none are added (thus preserving the
   * atomicity of this method).
   *
   * @since 2.0 beta 2
   */
  boolean addToContentDefiningChildren(ATLASElementSet contentDefiningAnnotations);

  /**
   * Adds the specified Annotations to the Region-defining Children element.
   *
   * @param regionDefiningAnnotations an ATLASElementSet containing the Annotations
   *        to be added to the Region-defining Children element
   *
   * @return <code>true</code> if the addition was sucessful,
   * <code>false</code> otherwise. Note that if the operation fails for any
   * Annotation in the ATLASElementSet, none are added (thus preserving the
   * atomicity of this method).
   *
   * @since 2.0 beta 2
   */
  boolean addToRegionDefiningChildren(ATLASElementSet regionDefiningAnnotations);

  /**
   * Adds the specified Annotations to the Children element defining the
   * subordinate specified by the given AnnotationChildrenType (either Content or Region).
   *
   * @param childrenAnnotations an ATLASElementSet containing the Annotations
   *        to be added to this Annotation's identified Children element
   * @param kind <code>AnnotationChildrenType.CONTENT_DEFINING</code> to specify
   *        that the Annotations should be added to the Content-defining Children
   *        element or <code>AnnotationChildrenType.REGION_DEFINING</code> to add the
   *        Annotations to the Region-defining Children element.
   *
   * @return <code>true</code> if the addition was sucessful,
   * <code>false</code> otherwise. Note that if the operation fails for any
   * Annotation in the ATLASElementSet, none are added (thus preserving the
   * atomicity of this method).
   *
   * @since 2.0 beta 2
   *
   * @deprecated Move to SPI
   */
  boolean addToDefiningChildren(ATLASElementSet childrenAnnotations, AnnotationChildrenType.SubType kind);

  /**
   * Removes the specified Annotation to the Children element identified with
   * the specified role.
   *
   * @param annotation the child Annotation to be removed
   * @param role the role identifying the Children element to which the
   * specified Annotation should be removed
   *
   * @return <code>true</code> if the removal was sucessful,
   * <code>false</code> otherwise.
   */
//  boolean removeChildFromChildrenWithRole(Annotation annotation, String role);

  /**
   * Retrieves the Children element (containing Annotations) indentified with
   * the specified role.
   *
   * @param role    the role of the Children element to be retrieved.
   * @return the appropriate Children element
   * @throws ATLASAccessException if no such Children exists
   *
   * @since 2.0 beta 4 (was getChildrenWith)
   */
  AnnotationChildren getAnnotationChildrenWithRole(String role);

  /**
   * Retrieves the Children element containing Annotations of the specified
   * type. If there were several Children elements
   * containing Annotations of similar types, a role (as specified by this
   * Annotation's type) can be provided when
   * needed to completely identify the Children element to be retrieved (a
   * Children element is totally identified with the couple [type, role]).
   *
   * @param containedType the ATLASType of the Annotations contained in the
   * Children element to be retrieved
   * @param role    the role of the Children element to be retrieved. If no
   * such role is needed, use the constant
   * ATLASType.NULL_ROLE, defined for this purpose.
   *
   * @return the appropriate Children element, <code>null</code> otherwise.
   */
//  AnnotationChildren getChildrenWith(AnnotationType containedType, String role);

  /**
   * Retrieves the Content-defining Children of this Annotation if there is such
   * element.
   *
   * @return the Content-defining Children element, <code>null</code> otherwise
   *
   * @since 2.0 beta 2
   */
  AnnotationChildren getContentDefiningChildren();

  /**
   * Retrieves the Region-defining Children of this Annotation if there is such
   * element.
   *
   * @return the Region-defining Children element, <code>null</code> otherwise
   *
   * @since 2.0 beta 2
   */
  AnnotationChildren getRegionDefiningChildren();

  /**
   * Retrieves the Children element defining the
   * subordinate specified by the given AnnotationChildrenType (either Content or Region).
   *
   * @param kind <code>AnnotationChildrenType.CONTENT_DEFINING</code> to specify
   *        that the Annotations should be added to the Content-defining Children
   *        element or <code>AnnotationChildrenType.REGION_DEFINING</code> to add the
   *        Annotations to the Region-defining Children element.
   *
   * @return the specified Children element, <code>null</code> if no such element
   * exists
   *
   * @since 2.0 beta 2
   *
   * @deprecated Move to SPI
   */
  AnnotationChildren getDefiningChildrenFor(AnnotationChildrenType.SubType kind);

  /**
   * @clientCardinality 0..*
   * @label references
   */

  /*#Region lnkRegion;*/

  /**
   * @supplierCardinality 0..*
   * @link aggregationByValue
   */

  /*#AnnotationChildren lnkAnnotation;*/

  /** @link aggregationByValue */

  /*#Content lnkContent;*/
}

