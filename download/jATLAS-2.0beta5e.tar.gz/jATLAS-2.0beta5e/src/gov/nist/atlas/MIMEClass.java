/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import java.util.HashMap;


/**
 * <p>Provides type-safe constant for MIME types of ATLAS signals. In ATLAS, we
 * make a distinction between generic MIME types ("application", "audio", ...)
 * which we call MIME "classes" and specific MIME types
 * ("text/simple", "audio/wav"). This class provides only constants for MIME
 * "classes" as we call them.</p>
 *
 * <p>More details on MIME types can be found at
 * <a href='http://www.oac.uci.edu/indiv/ehood/MIME/MIME.html'>
 * http://www.oac.uci.edu/indiv/ehood/MIME/MIME.html</a></p>
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun, Sylvain Pajot
 */
final public class MIMEClass {
  public final static MIMEClass APPLICATION = new MIMEClass(1, "application");
  public final static MIMEClass AUDIO = new MIMEClass(2, "audio");
  public final static MIMEClass IMAGE = new MIMEClass(3, "image");
  public final static MIMEClass MESSAGE = new MIMEClass(4, "message");
  public final static MIMEClass MODEL = new MIMEClass(5, "model");
  public final static MIMEClass MULTIPART = new MIMEClass(6, "multipart");
  public final static MIMEClass TEXT = new MIMEClass(7, "text");
  public final static MIMEClass VIDEO = new MIMEClass(8, "video");

  public final int hashCode() {
    return hashCode;
  }

  /**
   * Returns this MIMEClass' name.
   *
   * @return this MIMEClass' name
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the set of currently supported MIMEClasses.
   *
   * @return an array containing the currently supported MIMEClasses
   */
  public static MIMEClass[] getSupportedMIMEClasses() {
    return (MIMEClass[]) supportedMIMEClasses.values().toArray();
  }

  /**
   * Returns the supported MIMEClass associated (if any) with the
   * specified name.
   *
   * @param mimeClassName the name of the MIMEClass to be retrieved
   *
   * @return the supported MIMEClass associated (if any) with the specified
   * name
   * @throws IllegalArgumentException if no supported MIMEClass is associated
   * with the specified name
   */
  public static MIMEClass getMIMEClassFor(String mimeClassName) {
    MIMEClass mimeClass = (MIMEClass) supportedMIMEClasses.get(mimeClassName);
    if (mimeClass == null)
      throw new IllegalArgumentException(mimeClassName + " is not a supported MIMEClass.");
    return mimeClass;
  }

  /**
   * Private constructor. Should never be used, just there to prevent
   * default instantiation.
   */
  private MIMEClass() {
    this(-1, "");
  }

  private MIMEClass(int hash, String name) {
    hashCode = hash;
    this.name = name;
  }

  private final static HashMap supportedMIMEClasses = new HashMap(9);

  static {
    supportedMIMEClasses.put(APPLICATION.getName(), APPLICATION);
    supportedMIMEClasses.put(AUDIO.getName(), AUDIO);
    supportedMIMEClasses.put(IMAGE.getName(), IMAGE);
    supportedMIMEClasses.put(TEXT.getName(), TEXT);
    supportedMIMEClasses.put(VIDEO.getName(), VIDEO);
  }

  private final int hashCode;
  private final String name;
}

