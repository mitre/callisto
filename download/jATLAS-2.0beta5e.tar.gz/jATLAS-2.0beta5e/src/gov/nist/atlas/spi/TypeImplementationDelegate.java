/*
 * Created by IntelliJ IDEA.
 * User: claprun
 * Date: Jul 24, 2002
 * Time: 3:08:30 PM
 * To change template for new interface use
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package gov.nist.atlas.spi;

import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.OptionalChildrenDefinition;
import gov.nist.atlas.type.RequiredChildDefinition;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.MutableATLASElementSet;

/**
 * @since 2.0 beta 4
 */
public interface TypeImplementationDelegate {
  /**
   * Determines if the specified RequiredChildDefinition is valid for this ATLASType.
   *
   * @param fragment the RequiredChildDefinition to test
   * @return <code>true</code> if the specified fragment is valid,
   *         <code>false</code> otherwise
   */
  boolean isRequiredChildDefinitionValid(RequiredChildDefinition fragment);

  /**
   * Determines if the specified OptionalChildrenDefinition is valid for this ATLASType.
   *
   * @param fragment the RequiredChildDefinition to test
   * @return <code>true</code> if the specified fragment is valid,
   *         <code>false</code> otherwise
   */
  boolean isOptionalChildrenDefinitionValid(OptionalChildrenDefinition fragment);

  void setAssociatedType(ATLASType type);

  RequiredChildDefinition createRequiredChildDefinition(ATLASType typeOfRequiredChild);

  OptionalChildrenDefinition createOptionalChildrenDefinition(ATLASType typeOfOptionalChildren, boolean canAdd, boolean canRemove, boolean sortable, boolean byId);

  MutableATLASElementSet createContainerForMultipleSubordinates(ATLASType containedType); // FIX-ME

  ATLASImplementation getATLASImplementation();
}
