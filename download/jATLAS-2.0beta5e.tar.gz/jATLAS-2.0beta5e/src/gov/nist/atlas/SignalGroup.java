/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.ref.SignalRef;


/**
 * <p>A group of related Signals. SignalGroup groups SimpleSignals or
 * even other SignalGroups thus creating an entity which has the same
 * semantics as Signal (their common super-interface). This allow
 * synchronization of Signals.</p>
 *
 * <p>SignalGroups behave exactly like Signals.
 * SignalGroups must group Signals that share a common structure or
 * dimensionality since it must be possible to align them along one of their
 * dimensions.</p>
 *
 * <p>The obvious usage of SignalGroup is to align several
 * different Signals on a single timeline (the common dimension
 * being here time).</p>
 *
 * <p>Note that:</p> <ul> <li>It is NOT possible to have Anchors to
 * referencing parts of a Signal that are beyond the boundaries defined by the
 * intersection (along their common dimension) of all the Signals in the
 * SignalGroup.</li> <li>Signals cannot be modified after Anchors are
 * assigned to them. In particular, it is not possible to add
 * Signals to a SignalGroup after Anchors have been assigned to it.</li> </ul>
 *
 * <p><strong>As of the first release, SignalGroups are not fully supported. In
 * particular, this interface is subject to changes due to incoherences and it
 * is not yet possible to perform dimension checking on Signals that are
 * added. </strong> </p>
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 *
 * @see Signal
 * @see SimpleSignal
 */
public interface SignalGroup extends SignalsHolder, Signal {
  /**
   * <p>Initializes the content of subordinate to the specified values. The
   * specified parameters are role-identified (via Signal references), this SignalGroup's type is thus
   * able to correctly assign them to their proper subordinate. Some
   * validation is performed at this level since it is not possible to assign
   * an invalid ATLASElement to a given subordinate.</p> <p><strong>Notes:</p>
   * <ul> <li>The final error mechanism hasn't been specified yet but this method
   * should be atomic: either all assignments are made or none.</li>
   * <li>The subordinates that are specified as arguments to this method are
   * element with FINITE cardinality.
   * Subordinates with undetermined cardinality are assigned using other,
   * appropriate methods.</li> </ul> </strong>
   *
   * @param signals the Signal references to be assigned to
   * Signal subordinates
   *
   * @see gov.nist.atlas.ref.SignalRef
   *
   * @deprecated Move to SPI
   */
  void initContainedElementsWith(SignalRef[] signals);

  /**
   * @supplierCardinality 1..*
   * @label references
   */

  /*#Signal lnkSignal;*/
}

