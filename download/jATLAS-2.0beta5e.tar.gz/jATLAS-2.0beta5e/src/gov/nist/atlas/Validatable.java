/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.event.ContentChangeListener;
import gov.nist.atlas.event.ContentWillChangeListener;

/**
 * <p>Validatable defines the behaviors that are expected of ATLAS elements that
 * can be validated.</p>
 *
 * <p><strong>Theses behaviors are not fully implemented yet.</strong></p>
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public interface Validatable extends AIFSerializable {
  /**
   * Determines if this Validatable is validated or not. A Validatable might
   * not be validated as the result of an explicit user action to disable
   * validation at save time. A Corpus containing non-validated Validatable
   * cannot be published without them being first validated.
   *
   * @return <code>true</code> if this Validatable is validated,
   * <code>false</code> otherwise.
   */
  boolean isValidated();

  /**
   * Activates or deactivates validation for this Validatable.
   * Validation can be deactivated upon explicit user request to allow such
   * things as forcing saving of invalid annotation data (for example, when
   * the work needed to make this Validatable valid hasn't been completed).
   * This method allows putting the user in charge of deciding when to
   * validate or not.
   *
   * @param enable a boolean indicating whether validation is
   * enabled (when it is <code>true</code>) or not (when it is
   * <code>false</code>)
   * @return a boolean indicating the previous activation of validation
   * (<code>true</code> if validation was previously
   * activated, <code>false</code> otherwise).
   */
  boolean enableValidation(boolean enable);

  /**
   * Determines if validation is enabled for this Validatable.
   *
   * @return <code>true</code> if validation is enabled,
   * <code>false</code> otherwise.
   */
  boolean isValidationEnabled();

  /**
   * <p>Performs validation of this Validatable.</p>
   *
   * <p><strong>NOT fully implemented yet.</strong></p>
   *
   * @return a ValidationResult object representing the result of the
   * validation process
   *
   * @see ValidationResult
   */
  ValidationResult validate();

  /**
   * Removes the specificied ContentChangeListener from this Validatable's
   * listener list.
   *
   * @param listener the ContentChangeListener to be removed
   *
   * @see gov.nist.atlas.event.ContentChangeListener
   */
  public void removeContentChangeListener(ContentChangeListener listener);

  /**
   * Adds the specified ContentChangeListener to this Validatable's listener
   * list.
   *
   * @param listener the ContentChangeListener to be added
   *
   * @see gov.nist.atlas.event.ContentChangeListener
   */
  public void addContentChangeListener(ContentChangeListener listener);

  /**
   * Removes the specificied ContentWillChangeListener from this Validatable's
   * listener list.
   *
   * @param listener the ContentWillChangeListener to be removed
   *
   * @see gov.nist.atlas.event.ContentWillChangeListener
   */
  public void removeContentWillChangeListener(ContentWillChangeListener listener);

  /**
   * Adds the specified ContentWillChangeListener to this Validatable's listener
   * list.
   *
   * @param listener the ContentWillChangeListener to be added
   *
   * @see gov.nist.atlas.event.ContentWillChangeListener
   */
  public void addContentWillChangeListener(ContentWillChangeListener listener);

}

