/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.type.AnalysisType;


/**
 * Analysis allows the organization of related Annotations. It is an element
 * that allows people to organize levels of Annotations in a convenient way.
 * Grouping of Annotations is left to the user's desires, a typical usage of
 * Analysis elements being to group Annotations of the same type but such an
 * organization is by no means mandatory.
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 *
 * @see Annotation
 */
public interface Analysis extends MetadataHolder, AnnotationsHolder, IdentifiableATLASElement {
  /**
   * Returns this Analysis' type as an AnalysisType object.
   *
   * @return the AnalysisType assigned to this Analysis
   */
  AnalysisType getAnalysisType();

  /**
   * Retrieves the subordinate Annotation identified by the specified id.
   *
   * @param stringId a String representation of the id of the Annotation
   * to be retrieved
   * @return the subordinate Annotation identified by the specified id,
   * <code>null</code> otherwise.
   */
  Annotation getAnnotationWithId(String stringId);

  /**
   * Determines if this Analysis contains an Annotation with the specified
   * identifier.
   *
   * @param stringId a String representation of the identifier of the Annotation
   *                 which containment is tested
   *
   * @return <code>true</code> if such an Annotation is contained in this
   *         Analysis, <code>false</code> otherwise.
   *
   * @since 2.0 beta 4
   */
  boolean containsAnnotationWithId(String stringId);

  /**
   * @link aggregationByValue
   * @supplierCardinality 0..*
   */

  /*#Annotation lnkAnnotation;*/
}




