/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import java.util.Set;


/**
 * ReusableATLASElement defines the behavior expected of reusable ATLASElements
 * i.e. elements that can be referenced across or inside ATLAS documents.
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public interface ReusableATLASElement extends IdentifiableATLASElement {
  /**
   * Returns the set of elements holding a reference to this
   * ReusableATLASElement.
   *
   * @return a possibly empty Set containing the ATLASElements referring
   * to this ReusableATLASElement
   */
  Set getReferentElements();


  /**
   * Adds the specified element to this ReusableATLASElement's set of
   * referring elements.
   *
   * @param element the new referring ATLASElement
   *
   * @return <code>true</code> if the addition was successful,
   * <code>false</code> otherwise
   */
  boolean addReferentElement(ATLASElement element);

  /**
   * Removes the specified element to this ReusableATLASElement's set of
   * referring elements.
   *
   * @param element the referring ATLASElement to be removed
   *
   * @return <code>true</code> if the removal was successful,
   * <code>false</code> otherwise
   */
  boolean removeReferentElement(ATLASElement element);

  /**
   * Returns this element's identifier as a fully qualified URL.
   *
   * Note that the semantics is not yet fully defined since it is not clear
   * what we should return if this element is contained in a Corpus that has
   * been created via user interaction and has never been serialized yet.
   *
   * @return a String representation of this element's fully qualified URL
   *
   * @since 2.0 beta 4
   *
   * @deprecated should this be Id's responsibility?
   */
  String getIdAsURL();
}

