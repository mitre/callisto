/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */


package gov.nist.atlas;

import gov.nist.atlas.util.ATLASElementSet;


/**
 * ParametersHolder specifies the behavior expected from elements
 * manipulating Parameters.
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public interface ParametersHolder {
  /**
   * Returns the Parameter subordinate identified with the specified role.
   *
   * @param role the role identifying the Parameter to retrieve
   *
   * @return the Parameter subordinate identified with the specified role,
   * <code>null</code> if no such Parameter is contained in this
   * ParametersHolder
   */
  Parameter getParameterWithRole(String role);

  /**
   * Returns all the Parameter subordinates contained in this
   * ParametersHolder.
   *
   * @return a possibly empty ATLASElementSet containing this
   * ParametersHolder's Parameter subordinates
   */
  ATLASElementSet getAllParameters();

  /**
   * Sets the value of the subordinate Parameter identified by the specified
   * role to the given value.
   *
   * @param value the new value to be assigned to the subordinate Parameter
   * @param role the role identifying the subordinate Parameter
   * which value is to be changed
   *
   * @return <code>true</code> if the new value was successfully set,
   * <code>false</code> otherwise
   */
  boolean setValueOfParameterWithRole(String value, String role);

  /**
   * Retrieves a String representation of the value of the subordinate Parameter
   * identified by the specified role.
   *
   * @param role the role identifying the subordinate Parameter which value is
   * to be retrieved
   *
   * @return a String representation of the Parameter's value
   */
  String getStringValueOfParameterWithRole(String role);

  /**
   * Retrieves an Object representation of the value of the subordinate Parameter
   * identified by the specified role.
   *
   * @param role the role identifying the subordinate Parameter which value is
   * to be retrieved
   *
   * @return a Object representation of the Parameter's value
   */
  Object getObjectValueOfParameterWithRole(String role);
}

