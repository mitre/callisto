/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.ref;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.ReusableATLASElement;


/**
 * InternalRefResolver is the implementation of the <CODE>RefResolver</CODE>
 * interface dedicated to XML internal references (that is, an xlink beginning
 * with a '#'). An internal reference refers to a ReusableATLASElement within
 * the corpus the reference is located in.
 *                                                                        `
 * @author Christophe Laprun, Sylvain Pajot
 * @version $Revision: 1.2 $
 *
 * @see gov.nist.atlas.ref.AbstractRefResolver
 */
class InternalRefResolver extends AbstractRefResolver {
  public final boolean acceptXLink(String xlink, Corpus corpus) {
    return (super.acceptXLink(xlink, corpus) && xlink.charAt(0) == '#');
  }

  public final ReusableATLASElement getElement(String xlink, ATLASClass expectedClass, Corpus containingCorpus) {
    checkParameters(expectedClass);

    String id = parseXLink(xlink).getFragment();
    return containingCorpus.getReusableElementWith(expectedClass, id);
  }

  public final boolean isLocal() {
    return true;
  }
}