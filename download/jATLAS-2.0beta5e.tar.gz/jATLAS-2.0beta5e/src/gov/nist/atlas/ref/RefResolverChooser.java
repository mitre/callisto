/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.ref;

import gov.nist.atlas.Corpus;
import gov.nist.atlas.ref.xml.XMLRefResolver;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;


/**
 * A RefResolverChooser is able to lexically analyze an xlink and choose
 * the appropriate RefResolver for that reference
 *
 * @author Christophe Laprun, Sylvain Pajot
 * @version $Revision: 1.2 $
 * @see gov.nist.atlas.ref.RefResolver
 */
public class RefResolverChooser {

  /**
   * Retrieves the most appropriate RefResolver for the specified XLink and
   * initializes it with a URI corresponding to the given XLink
   *
   * @param xlink - the xlink from which to determine the RefResolver
   * @param corpus - the corpus the xlink is located in
   * @return the appropriate RefResolver
   */
  public static RefResolver chooseRefResolverFor(String xlink, Corpus corpus) {
    URI uri = parseXLink(xlink);
    String scheme = uri.getScheme();
    if (scheme == null)
      scheme = "inmem";
    RefResolver resolver = (RefResolver) resolvers.get(scheme);
    if (resolver == null)
      throw new IllegalArgumentException("No RefResolver can handle this xlink: " + xlink);
    return resolver;
  }

  public static URI parseXLink(String xlink) {
    URI xlinkAsURI = null;
    try {
      xlinkAsURI = new URI(xlink);
    } catch (URISyntaxException e) {
      throw new IllegalArgumentException(xlink + " is not a valid XLink." +
          " Reason: " + e.getMessage());
    }
    if (xlinkAsURI.getFragment() == null)
      throw new IllegalArgumentException("The XLink [" + xlink + "] does not " +
          "contain a valid Id reference and cannot therefore be resolved as " +
          "ReusableATLASElement.");
    return xlinkAsURI;
  }

  private static Map resolvers = new HashMap(7);

  static {
    resolvers.put("inmem", new InternalRefResolver());
    resolvers.put("ftp", new XMLRefResolver()); //FIX-ME
    resolvers.put("http", new XMLRefResolver()); //FIX-ME
    resolvers.put("file", new XMLRefResolver()); //FIX-ME
  }
}