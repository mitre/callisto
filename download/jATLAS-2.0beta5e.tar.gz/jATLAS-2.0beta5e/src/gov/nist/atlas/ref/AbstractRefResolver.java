/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.ref;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.Corpus;

import java.net.URI;


/**
 * AbstractRefResolver provides a skeletal implementation of the
 * <CODE>RefResolver</CODE> interface by providing a basic
 * implementation of the <CODE>acceptXLink</CODE> method.
 * It also adds a security purposed method, useful for its
 * concrete subclasses.
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun, Sylvain Pajot
 */
public abstract class AbstractRefResolver implements RefResolver {

  public boolean acceptXLink(String xlink, Corpus corpus) {
    return (corpus != null && xlink != null && xlink.length() != 0);
  }

  /**
   * Makes sure that the specified referenced type belongs to a
   * ReusableATLASElement, to prevent from AIF file manipulations errors
   *
   * @param expectedClass - the type of the ATLASElement to get
   */
  public void checkParameters(ATLASClass expectedClass) {
    if (!expectedClass.isReusable())
      throw new IllegalArgumentException("The expected ATLASType of the referenced element is not of a Reusable type!");
  }

  protected URI parseXLink(String xlink) {
    return RefResolverChooser.parseXLink(xlink);
  }
}