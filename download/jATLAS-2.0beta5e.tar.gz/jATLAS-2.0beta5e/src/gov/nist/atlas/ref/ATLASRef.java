/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.ref;

import gov.nist.atlas.AIFSerializable;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Anchor;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Region;
import gov.nist.atlas.ReusableATLASElement;
import gov.nist.atlas.Signal;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.RoleAddressable;
import gov.nist.atlas.util.RoleWrapper;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;


/**
 *
 * <p>ATLASRef is the basic class via which ATLAS references are implemented.
 * It provides static methods to create references from XLink strings
 * and roles. </p>
 *
 * <p>Using the dynamic proxy mechanism introduced in the 1.3 version of Java,
 * ATLASRef handles requests to references even if they have not been resolved
 * yet (i.e. the referred element has not been retrieved or built yet). This
 * allows faster loading of Corpora with cross-document references.</p>
 *
 * <p>Actual elements are resolved using a RefResolver that is chosen based
 * on the type of XLink identifying the referred object.</p>
 *
 * @version $Revision: 1.4 $
 * @author Christophe Laprun
 *
 * @see RefResolver
 * @see java.lang.reflect.InvocationHandler
 * @see java.lang.reflect.Proxy
 * @see <a href='http://java.sun.com/j2se/1.3/docs/guide/reflection/proxy.html'>
 * Dynamic Proxy Introduction</a>
 */
public class ATLASRef extends RoleWrapper implements InvocationHandler, Reference {

  /** Private constructor to prevent direct instantiation. */
  private ATLASRef() {
  }

  /**
   * Internal constructor.
   *
   * @param xlink the XLink string identifying the referred element
   * @param type the expected ATLASType of the referred element
   * @param corpus the Corpus from which the reference is issued
   * @param role the role of the reference in its parent's context
   */
  private ATLASRef(String xlink, ATLASType type, Corpus corpus, String role) {
    // FIX-ME: try to optimize this
    resolver = RefResolverChooser.chooseRefResolverFor(xlink, corpus);
    this.role = role;
    this.xlink = xlink;
    this.type = type;
    containingCorpus = corpus;
  }

  /**
   * Internal constructor.
   *
   * @param element the ReusableATLASElement backing this ATLASRef
   * @param role the role of this ATLASRef in its parent's context
   */
  private ATLASRef(ReusableATLASElement element, String role) {
    delegate = element;
    xlink = element.getIdAsURL();
    type = element.getATLASType();
    containingCorpus = element.getDefiningCorpus();
    this.role = role;
  }

  /**
   * Internal factory method. Creates a new Proxy implementing the specified
   * interface and associated with a new ATLASRef referencing the given XLink.
   *
   * @param clazz the Class object identifying the interface the new ATLASRef
   * is to implement (i.e. to create a new AnchorRef, pass AnchorRef.class)
   * @param xlink the XLink string identifying the referred element
   * @param type the expected ATLASType of the referred element
   * @param corpus the Corpus from which the reference is issued
   * @param role the role of the reference in its parent's context
   * @return a new Proxy object implementing the specified Reference interface
   * and delegating its calls to a newly created ATLASRef
   */
  protected static Reference createATLASRef(Class clazz, String xlink, ATLASType type, Corpus corpus, String role) {
    return (Reference) Proxy.newProxyInstance(clazz.getClassLoader(), new Class[]{clazz}, new ATLASRef(xlink, type, corpus, role));
  }

  /**
   * Internal factory method. Creates a new Proxy implementing the appropriate
   * Reference interface based on the specified ReusableATLASElement and with
   * the specified role.
   *
   * @param element the ReusableATLASElement referenced by the new Reference
   * @param role the role of the reference in its parent's context
   * @return a new Proxy object implementing the specified Reference interface
   * and delegating its calls to a newly created ATLASRef
   */
  protected static Reference createATLASRef(ReusableATLASElement element, String role) {
    Class refClass = null;
    try {
      refClass = Class.forName("gov.nist.atlas.ref." + element.getATLASClass().getName() + "Ref");
    } catch (ClassNotFoundException e) {
      throw new RuntimeException("Shouldn't have happened!", e);
    }
    ATLASRef ref = new ATLASRef(element, role);
    return (Reference) Proxy.newProxyInstance(refClass.getClassLoader(), new Class[]{refClass}, ref);
  }

  public final boolean isLocal() {
    return local;
  }

  /**
   * Creates an AnchorRef from an Anchor and a role.
   *
   * @param anchor the Anchor to which the AnchorRef points
   * @param role the role to be associated with the given Anchor
   * @return an AnchorRef which associates the specified Anchor and role
   */
  public static AnchorRef createAnchorRef(Anchor anchor, String role) {
    return (AnchorRef) createATLASRef(anchor, role);
  }

  /**
   * Creates an AnnotationRef from an Annotation and a role.
   *
   * @param annotation the Annotation to which the AnnotationRef points
   * @param role the role to be associated with the given Annotation
   * @return an AnnotationRef which associates the specified Annotation and role
   */
  public static AnnotationRef createAnnotationRef(Annotation annotation, String role) {
    return (AnnotationRef) createATLASRef(annotation, role);
  }

  /**
   * Creates a RegionRef from a Region and a role.
   *
   * @param region the Region to which the RegionRef points
   * @param role the role to be associated with the given Region
   * @return a RegionRef which associates the specified Region and role
   */
  public static RegionRef createRegionRef(Region region, String role) {
    return (RegionRef) createATLASRef(region, role);
  }

  /**
   * Creates a SignalRef from a Signal and a role.
   *
   * @param signal the Signal to which the SignalRef points
   * @param role the role to be associated with the given Signal
   * @return a SignalRef which associates the specified Signal and role
   */
  public static SignalRef createSignalRef(Signal signal, String role) {
    return (SignalRef) createATLASRef(signal, role);
  }


  /**
   * Creates a new AnchorRef pointing to the specified XLink.
   *
   * @param xlink the XLink string identifying the referred element
   * @param type the expected ATLASType of the referred element
   * @param corpus the Corpus from which the reference is issued
   * @param role the role of the reference in its parent's context
   *
   * @see AnchorRef
   */
  public static AnchorRef createAnchorRef(String xlink, ATLASType type, Corpus corpus, String role) {
    return (AnchorRef) createATLASRef(AnchorRef.class, xlink, type, corpus, role);
  }

  /**
   * Creates a new AnnotationRef pointing to the specified XLink.
   *
   * @param xlink the XLink string identifying the referred element
   * @param type the expected ATLASType of the referred element
   * @param corpus the Corpus from which the reference is issued
   * @param role the role of the reference in its parent's context
   *
   * @see AnnotationRef
   */
  public static AnnotationRef createAnnotationRef(String xlink, ATLASType type, Corpus corpus, String role) {
    return (AnnotationRef) createATLASRef(AnnotationRef.class, xlink, type, corpus, role);
  }

  /**
   * Creates a new RegionRef pointing to the specified XLink.
   *
   * @param xlink the XLink string identifying the referred element
   * @param type the expected ATLASType of the referred element
   * @param corpus the Corpus from which the reference is issued
   * @param role the role of the reference in its parent's context
   *
   * @see RegionRef
   */
  public static RegionRef createRegionRef(String xlink, ATLASType type, Corpus corpus, String role) {
    return (RegionRef) createATLASRef(RegionRef.class, xlink, type, corpus, role);
  }

  /**
   * Creates a new SignalRef pointing to the specified XLink.
   *
   * @param xlink the XLink string identifying the referred element
   * @param type the expected ATLASType of the referred element
   * @param corpus the Corpus from which the reference is issued
   * @param role the role of the reference in its parent's context
   *
   * @see SignalRef
   */
  public static SignalRef createSignalRef(String xlink, ATLASType type, Corpus corpus, String role) {
    return (SignalRef) createATLASRef(SignalRef.class, xlink, type, corpus, role);
  }

  /*public final String getRole() {
    return role;
  }*/

  public final RefResolver getResolver() {
    return resolver;
  }

  public final String getXLink() {
    return xlink;
  }

  public final String getIdAsURL() {
    // If xlink is local, force resolution. Cast is ok, thought delegate isn't
    // ReusableElt: its ATLASElt because of RoleWrapper. 20040401:red@mitre.org

    // If the delegate doesn't exist yet (e.g. reference appears in AIF before
    // Element) we must revert to calculating idAsURL here.  This could have
    // failed if the actual Element's idAsURL were never cached before the
    // Corpus' location changed.  ../impl/ReusableATLASElementImpl updated
    // to immidiately cache, but that's just for the one implementation.
    // 20040401:red@mitre.org
    if (delegate != null)
      return ((ReusableATLASElement)delegate).getIdAsURL();
    if (xlink.startsWith("#")) {
      if (getElement() != null) // resolve
        return ((ReusableATLASElement)delegate).getIdAsURL();
      else
        return containingCorpus.getLocation().toExternalForm() + xlink;
    } else
      return xlink;
  }

  private final String getIdOnly() {
    return xlink.substring(xlink.lastIndexOf('#') + 1);
  }

  public void toAIFBuffer(StringBuffer sb, String indent, String role, ATLASElement context) {
    sb.append(indent).append("<").append(type.getATLASClass().getAIFName())
        .append("Ref xlink:href=\'");
    if (context.getDefiningCorpus() != containingCorpus)
      sb.append(getIdAsURL());
    else
      sb.append("#").append(getIdOnly());
    sb.append(AIFExportConstants.ROLE_ATT).append(role)
        .append(AIFExportConstants.EMPTY_CLOSE);
  }

  /**
   * Returns the element pointed by this ATLASRef's XLink. This is the method
   * that is called to resolve the reference. This ATLASRef asks its
   * RefResolver to return the pointed element and then uses it as a delegate
   * for future method calls. This method is called when this ATLASRef does
   * not have the required information to handle a method call by itself.
   *
   * @return the element pointed by this ATLASRef's XLink, <code>null</code>
   * if this ATLASRef's XLink cannot be resolved to an actual element
   */
  public final ATLASElement getElement() {
    // FIX-ME : is it a problem to return less specific element than the element
    // itself (delegate) ?
    if (delegate == null)
      delegate = resolver.getElement(xlink, type.getATLASClass(), containingCorpus);
    return delegate;
  }

  /**
   * Determines if the specified Object is equal to this Reference. The
   * comparison is made on the XLinks: if two References are associated with
   * the same XLink, they are considered equal.
   */
  public boolean equals(Object other) {
    if (other == this)
      return true;
    if (other instanceof ReusableATLASElement) {
      ReusableATLASElement ref = (ReusableATLASElement) other;
      return getIdAsURL().equals(ref.getIdAsURL());
    }
    return false;
  }

  private Integer getHashCode() {
    if (hash == null)
      hash = new Integer(hashCode());
    return hash;
  }

  /**
   * <p>Handles method calls to this ATLASRef. This method is at the core of
   * the Dynamic Proxy mechanism. The dynamic proxy mechanism forwards method
   * calls to this ATLASRef to this method using Java's reflection
   * mechanism.</p>
   *
   * <p>This ATLASRef tries to handle as much method calls as it can without
   * having to resolve the XLink it holds. If a method is called that this
   * ATLASRef cannot handle, it tries to resolve the XLink by calling
   * <code>getElement()</code>. If the XLink resolution is successful,
   * the retrieved element is used as a delegate for future method calls.</p>
   *
   * <p>As of the first release, ATLASRef directly handles:</p> <ul>
   * <li><code>getRole()</code></li> <li><code>getElement()</code></li>
   * <li><code>getATLASType()</code></li>
   * <li><code>equals(Object other)</code></li>
   * <li><code>getResolver()</code></li>
   * <li><code>getXLink()</code></li> </ul>
   *
   * @see java.lang.reflect.InvocationHandler#invoke(Object, Method, Object[])
   */
  public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
    try {
      if (m.equals(GET_ROLE))
        return getRole();
      if (m.equals(GET_ELEMENT))
        return getElement();
      if (m.equals(GET_ATLAS_TYPE))
        return type;
      if (m.equals(EQUALS)) {
        if (this.equals(args[0]))
          return Boolean.TRUE;
        return Boolean.FALSE;
      }
      if (m.equals(HASHCODE))
        return getHashCode();
      if (m.equals(GET_RESOLVER))
        return getResolver();
      if (m.equals(GET_XLINK))
        return getXLink();
      if (m.equals(GET_ID_AS_URL))
        return getIdAsURL();
      if (m.equals(TO_AIF)) {
        toAIFBuffer((StringBuffer) args[0], (String) args[1], (String) args[2], (ATLASElement) args[3]);
        return null;
      }

      ATLASElement element = getElement();
      return m.invoke(element, args);
    } catch (InvocationTargetException ite) {
      throw ite.getTargetException();
    } catch (Exception e) {
      throw e;
    }
  }


  private RefResolver resolver;
//  private ReusableATLASElement delegate;
  private ATLASType type;
  private String xlink;
  private boolean local;
  private Corpus containingCorpus;
  private Integer hash;

  // Dynamic proxy related initializations
  private static Method GET_ROLE;
  private static Method GET_ELEMENT;
  private static Method GET_ATLAS_TYPE;
  private static Method EQUALS;
  private static Method GET_XLINK;
  private static Method GET_RESOLVER;
  private static Method GET_ID_AS_URL;
  private static Method TO_AIF;
  private static Method HASHCODE;

  static {
    try {
      GET_ROLE = RoleAddressable.class.getMethod("getRole", null);
      GET_ELEMENT = RoleAddressable.class.getMethod("getElement", null);
      GET_ATLAS_TYPE = ATLASElement.class.getMethod("getATLASType", null);
      EQUALS = Object.class.getMethod("equals", new Class[]{Object.class});
      HASHCODE = Object.class.getMethod("hashCode", null);
      GET_RESOLVER = Reference.class.getMethod("getResolver", null);
      GET_XLINK = Reference.class.getMethod("getXLink", null);
      GET_ID_AS_URL = ReusableATLASElement.class.getMethod("getIdAsURL", null);
      TO_AIF = AIFSerializable.class.getMethod("toAIFBuffer", new Class[]{StringBuffer.class, String.class, String.class, ATLASElement.class});
    } catch (NoSuchMethodException e) {
      e.printStackTrace();// should never happen
    }
  }
}



