/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.ref.AnchorRef;
import gov.nist.atlas.ref.AnnotationRef;
import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.type.RegionType;
import gov.nist.atlas.util.ATLASElementSet;


/**
 * <p>An abstraction for a region or "area" in a Signal. Since signals can be
 * of arbitrary dimensionality, Region elements provide
 * a layer above the signal to abstractly define an area within that signal.
 * Users are thus shielded from having to with the details of signals at the
 * Annotation level. Moreover, since users only deal with Regions, it is
 * possible to change the internals of Regions (to refine the identified area
 * for example), without impacting Annotations that depend on it.<br>
 * Examples of Regions include (but are not limited to) intervals for linear
 * signals such as text or audio, rectangles for bi-dimensional signals
 * (images). More complex Regions might be defined for more synthetic and
 * structured signal classes (such as lexicons).</p>
 *
 * <p>Regions are identified and their reuse is encouraged.</p>
 *
 * <p>In ATLAS, Regions can be defined as follow:</p> <ol>
 * <li>Basic Regions refer to a Signal via a set of Anchor elements, each
 * Anchor being assigned a unique role within the context of the
 * parent Region.</li> <li>Composite Regions can be built by referencing
 * already created Regions to support complex annotation schemes.</li>
 * <li>Regions can also reference Annotations to support multi-level
 * annotation schemes where annotated data is used as the source for further
 * annotation. This allows direct support of the coreference task which links
 * two or more independent annotations and associates information with this
 * link. For instance if the sentence "Fred said he would volunteer" was
 * annotated as a series of words, the Annotation representing the word "he"
 * could be linked (using a coreference Annotation) to the Annotation
 * representing the word "Fred".</li>
 * <li>A combination of the previous techniques can be used to model really
 * complex annotation schemes.</li> <li>Alternatively, Regions can be defined
 * by referring to some of the Children of the Annotation it is part of. Thus,
 * in hierarchical annotation schemes, the Region definition can be delegated
 * to a lower level in the hierarchy. For instance, the Region for a sentence
 * Annotation can be defined by the Region defined by the word children
 * Annotations.</li> </ol>
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 *
 * @see Anchor
 * @see Signal
 * @see Annotation
 * @see Children
 */
public interface Region extends ReusableATLASElement {
  /**
   * <p>Initializes the content of subordinate to the specified values. The
   * specified parameters are role-identified, this Region's type is thus able
   * to correctly assign them to their proper subordinate. Some
   * validation is performed at this level since it is not possible to assign
   * an invalid ATLASElement to a given subordinate.</p> <p><strong>Notes:</p>
   * <ul> <li>The final error mechanism hasn't been specified yet but this method
   * should be atomic: either all assignments are made or none.</li>
   * <li>The subordinates that are specified as arguments to this method are
   * element with FINITE cardinality.
   * Subordinates with undetermined cardinality are assigned using other,
   * appropriate methods.</li> </ul> </strong>
   *
   * @param annotations the Annotation references to be assigned to
   * Annotation subordinates
   * @param regions the Region references to be assigned to
   * Region subordinates
   * @param anchors the Anchor references to be assigned to
   * Anchor subordinates
   *
   * @see gov.nist.atlas.ref.AnnotationRef
   * @see gov.nist.atlas.ref.RegionRef
   * @see gov.nist.atlas.ref.AnchorRef
   *
   * @deprecated Move to SPI
   */
  void initContainedElementsWith(AnnotationRef[] annotations, RegionRef[] regions, AnchorRef[] anchors);

  /**
   * Returns this Region's type as a RegionType object.
   *
   * @return the RegionType assigned to this Region
   */
  RegionType getRegionType();

  /**
   * Returns the Anchor subordinate identified with the specified role.
   *
   * @param role the role identifying the Anchor to retrieve
   *
   * @return the Anchor subordinate identified with the specified role,
   * <code>null</code> if no such Anchor is contained in this Region
   */
  Anchor getAnchorWithRole(String role);

  /**
   * Sets the subordinate Anchor identified with the specified
   * role to the specified Anchor if such an operation is allowed by this
   * Region's ATLASType.
   *
   * @param anchor the new value for the subordinate anchor
   * @param role    the role identifying the anchor to be set, if no role has
   *                been specified in the MAIA definition for this Region's
   *                ATLASType, the ATLASType.NULL_ROLE constant should be used
   *
   * @return  <code>true</code> if the anchor has been sucessfully
   * set, <code>false</code> otherwise meaning that the specified
   * anchor cannot be assigned to the subordinate identified with
   * the given role
   *
   * @since 2.0 beta 4
   */
  boolean setAnchorWithRole(Anchor anchor, String role);

  /**
   * Sets the subordinate Anchor identified with the specified
   * role to the specified Anchor (via the specified AnchorRef) if such an
   * operation is allowed by this Region's ATLASType.
   *
   * @param anchor an AnchorRef identicating the role and the new value for the
   *        subordinate anchor to be set
   *
   * @return  <code>true</code> if the anchor has been sucessfully
   * set, <code>false</code> otherwise meaning that the specified
   * anchor cannot be assigned to the subordinate identified with
   * the given role
   *
   * @since 2.0 beta 4
   */
  boolean setAnchorWithRole(AnchorRef anchor);

  /**
   * Returns all the Anchor subordinates contained in this Region.
   *
   * @return a possibly empty ATLASElementSet containing this Region's
   * Anchor subordinates
   */
  ATLASElementSet getAllAnchors();

  /**
   * Returns the Region subordinate identified with the specified role.
   *
   * @param role the role identifying the Region to retrieve
   *
   * @return the Region subordinate identified with the specified role,
   * <code>null</code> if no such Region is contained in this Region
   */
  Region getRegionWithRole(String role);

  /**
   * Sets the subordinate Region identified with the specified
   * role to the specified Region if such an operation is allowed by this
   * Region's ATLASType.
   *
   * @param region the new value for the subordinate region
   * @param role    the role identifying the region to be set, if no role has
   *                been specified in the MAIA definition for this Region's
   *                ATLASType, the ATLASType.NULL_ROLE constant should be used
   *
   * @return  <code>true</code> if the region has been sucessfully
   * set, <code>false</code> otherwise meaning that the specified
   * region cannot be assigned to the subordinate identified with
   * the given role
   *
   * @since 2.0 beta 4
   */
  boolean setRegionWithRole(Region region, String role);

  /**
   * Sets the subordinate Region identified with the specified
   * role to the specified Region (via the specified RegionRef) if such an
   * operation is allowed by this Region's ATLASType.
   *
   * @param region a RegionRef identicating the role and the new value for the
   *        subordinate region to be set
   *
   * @return  <code>true</code> if the region has been sucessfully
   * set, <code>false</code> otherwise meaning that the specified
   * region cannot be assigned to the subordinate identified with
   * the given role
   *
   * @since 2.0 beta 4
   */
  boolean setRegionWithRole(RegionRef region);

  /**
   * Returns all the Region subordinates contained in this Region.
   *
   * @return a possibly empty ATLASElementSet containing this Region's
   * Region subordinates
   */
  ATLASElementSet getAllRegions();

  /**
   * Returns the Annotation subordinate identified with the specified role.
   *
   * @param role the role identifying the Annotation to retrieve
   *
   * @return the Annotation subordinate identified with the specified role,
   * <code>null</code> if no such Annotation is contained in this Region
   */
  Annotation getAnnotationWithRole(String role);

  /**
   * Sets the subordinate Annotation identified with the specified
   * role to the specified Annotation if such an operation is allowed by this
   * Region's ATLASType.
   *
   * @param annotation the new value for the subordinate annotation
   * @param role    the role identifying the annotation to be set, if no role has
   *                been specified in the MAIA definition for this Region's
   *                ATLASType, the ATLASType.NULL_ROLE constant should be used
   *
   * @return  <code>true</code> if the annotation has been sucessfully
   * set, <code>false</code> otherwise meaning that the specified
   * annotation cannot be assigned to the subordinate identified with
   * the given role
   *
   * @since 2.0 beta 4
   */
  boolean setAnnotationWithRole(Annotation annotation, String role);

  /**
   * Sets the subordinate Annotation identified with the specified
   * role to the specified Annotation (via the specified AnnotationRef) if such an
   * operation is allowed by this Region's ATLASType.
   *
   * @param annotation an AnnotationRef identicating the role and the new value for the
   *        subordinate annotation to be set
   *
   * @return  <code>true</code> if the annotation has been sucessfully
   * set, <code>false</code> otherwise meaning that the specified
   * annotation cannot be assigned to the subordinate identified with
   * the given role
   *
   * @since 2.0 beta 4
   */
  boolean setAnnotationWithRole(AnnotationRef annotation);

  /**
   * Returns all the Annotation subordinates contained in this Region.
   *
   * @return a possibly empty ATLASElementSet containing this
   * Region's Annotation subordinates
   */
  ATLASElementSet getAllAnnotations();

  /**
   * Returns the set of Signals this Region defines an area in.
   *
   * @return a (possibly empty) ATLASElementSet containing the Signals this
   *         Region defines area in.
   *
   * @since 2.0 beta 4
   */
  ATLASElementSet getReferencedSignals();

  /**
   * Adds the specified Region to this Region's subordinate set.
   *
   * @param region the Region to add
   *
   * @return <code>true</code> if the addition was correctly done,
   * <code>false</code> otherwise
   *
   */
  boolean addRegion(Region region);

  /**
   * Removes the specified Region from this Region's subordinate set.
   *
   * @param region the Region to remove
   *
   * @return <code>true</code> if the removal was correctly done,
   * <code>false</code> otherwise
   */
  boolean removeRegion(Region region);

  /**
   * Adds the specified Anchor to this Region's subordinate set.
   *
   * @param anchor the Anchor to add
   *
   * @return <code>true</code> if the addition was correctly done,
   * <code>false</code> otherwise
   */
  boolean addAnchor(Anchor anchor);

  /**
   * Removes the specified Anchor from this Region's subordinate set.
   *
   * @param anchor the Anchor to remove
   *
   * @return <code>true</code> if the removal was correctly done,
   * <code>false</code> otherwise
   */
  boolean removeAnchor(Anchor anchor);

  /**
   * Adds the specified Annotation to this Region's subordinate set.
   *
   * @param annotation the Annotation to add
   *
   * @return <code>true</code> if the addition was correctly done,
   * <code>false</code> otherwise
   */
  boolean addAnnotation(Annotation annotation);

  /**
   * Removes the specified Annotation from this Region's subordinate set.
   *
   * @param annotation the Annotation to remove
   *
   * @return <code>true</code> if the removal was correctly done,
   * <code>false</code> otherwise
   */
  boolean removeAnnotation(Annotation annotation);

  /**
   * @supplierCardinality 0..*
   * @label references
   */

  /*#Anchor lnkAnchor;*/

  /**
   * @supplierCardinality 0..*
   * @label references
   */

  /*#Annotation lnkAnnotation;*/

  /**
   * @supplierCardinality 0..*
   * @label references
   */

  /*#Region lnkRegion;*/

  /**
   * This association will probably be modelled by a
   * <code>RegionDefinedBy</code> XML element in AIF with
   * <code>children</code> and <code>role</code> attributes identifying which
   * among the children elements defines the region.
   * @supplierCardinality 0..1
   * @label can be defined by
   */

  /*#AnnotationChildren lnkChildren;*/
}

