/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.event.ValueChangeListener;
import gov.nist.atlas.event.ValueWillChangeListener;
import gov.nist.atlas.type.ParameterType;


/**
 * Parameters encapsulates simple values that are used in ATLAS.
 * Parameters are typed values providing an easy way to
 * map character strings (as stored in XML) to native data types in ATLAS.
 * Parameters are provided for atomic (non-structured) values. If structured
 * values are required, use Features. The values represented by Parameters can
 * also have an optional unit.
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun, Nicolas Radde
 *
 * @see Feature
 */
public interface Parameter extends ATLASElement {
  /**
   * Returns this Parameter's type as a ParameterType object.
   *
   * @return the ParameterType assigned to this Parameter
   */
  ParameterType getParameterType();

  /**
   * <p>Returns this Parameter's Unit, if one is associated with it.</p>
   *
   * <p><strong>When this Parameter's Unit is not specified, this method
   * currently returns <code>null</code>. This might change in a future
   * revision.</strong></p>
   *
   * @return this Parameter's Unit, <code>null</code> if none is associated with it
   *
   * @deprecated Move to ParameterType
   */
  Unit getUnit();

  /**
   * Returns this Parameter's value as an Object.
   *
   * @return an Object representing this Parameter's value
   */
  Object getValueAsObject();

  /**
   * Returns this Parameter's value as a String.
   *
   * @return a String representing this Parameter's value
   */
  String getValueAsString();

  /**
   * Sets this Parameter's value to the specified one.
   *
   * @param value the new value as a String (needs to be converted/checked)
   *
   * @return <code>true</code> if the new value was successfully set,
   * <code>false</code> otherwise
   */
  boolean setValue(String value);

  /**
   * Removes the specified ValueChangeListener from the list of listeners.
   *
   * @param listener the ValueChangeListener you want to remove.
   *
   * @see gov.nist.atlas.event.ValueChangeListener
   */
  void removeValueChangeListener(ValueChangeListener listener);

  /**
   * Adds the specified ValueChangeListener to the list of listeners.
   *
   * @param listener the ValueChangeListener you want to add
   *
   * @see gov.nist.atlas.event.ValueChangeListener
   */
  void addValueChangeListener(ValueChangeListener listener);

  /**
   * Removes the specified ValueWillChangeListener to the list of listeners.
   *
   * @param listener the ValueWillChangeListener you want to add
   *
   * @see gov.nist.atlas.event.ValueWillChangeListener
   */
  void removeValueWillChangeListener(ValueWillChangeListener listener);

  /**
   * Adds the specified ValueWillChangeListener to the list of listeners.
   *
   * @param listener the ValueWillChangeListener you want to add
   *
   * @see gov.nist.atlas.event.ValueWillChangeListener
   */
  void addValueWillChangeListener(ValueWillChangeListener listener);

  /* may be in the SPI
  protected void fireValueChange(ValueChangeEvent e);
  protected void fireValueWillChange(ValueChangeEvent e) throws ValueChangedVetoException;
  */
}

