/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.type.MetadataType;

import java.util.Set;


/**
 * Metadata represents arbitrary metadata that can be associated to some
 * ATLASElements. <strong>NOT YET FULLY SUPPORTED.</strong>
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public interface Metadata extends ATLASElement {
  /**
   * Returns this Metadata's type as a MetadataType object.
   *
   * @return the MetadataType assigned to this Metadata
   */
  MetadataType getMetadataType();


  /**
   * Creates or changes an entry for this Metadata. A Metadata entry is a
   * key-value pair. This methods creates a new entry if none is associated
   * to the specified key or changes the value associated to it if it
   * already exists.
   *
   * @param key the key of the entry to modify or create
   * @param value the new value for the entry identified by the specified key
   *
   * @return <code>true</code> if the operation has been successful,
   * <code>false</code> otherwise
   */
  boolean setOrCreatePair(String key, String value);

  /**
   * Retrieves the value associated to the specified key.
   *
   * @param key the key for this entry which value is to be retrieved
   *
   * @return the String value associated to the specified key,
   * <code>null</code> if there isn't any entry associated to this key
   * in this Metadata
   */
  String getValueFor(String key);

  /**
   * Returns the set of the keys of all entries contained in this Metadata.
   *
   * @return a Set containing the keys of this Metadata's entries
   */
  Set getKeys();
}

