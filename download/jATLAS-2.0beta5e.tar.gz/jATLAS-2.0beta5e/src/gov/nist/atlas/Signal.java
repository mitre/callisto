/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;

import gov.nist.atlas.type.SignalType;


/**
 * <p>An abstraction for Signals in ATLAS. This is a super-interface for both
 * SimpleSignal and SignalGroup thus allowing the API to handle both in a
 * consistent way.</p>
 *
 * <p>Information about a Signal's dimensionality can be determined via its
 * Size information. See the Size class for more details.</p>
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 *
 * @see SimpleSignal
 * @see SignalGroup
 * @see Size
 */
public interface Signal extends MetadataHolder, ReusableATLASElement {
  /**
   * Returns this Signal's type as a SignalType object.
   *
   * @return the SignalType assigned to this Signal
   */
  SignalType getSignalType();

  /**
   * Returns this Signal's Size object.
   *
   * @return this Signal's Size object
   *
   * @see Size
   */
  Size getSize();

  /**
   * Determines if this Signal is a SignalGroup.
   *
   * @return <code>true</code> if this Signal is a SignalGroup,
   * <code>false</code> otherwise
   */
  boolean isGroup();
}

