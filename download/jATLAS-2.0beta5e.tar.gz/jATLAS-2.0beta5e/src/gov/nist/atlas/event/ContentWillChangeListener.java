/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.event;

import java.util.EventListener;

/**
 * <p>This interface defines the methods to implement to be able to be notified
 * <strong>before</strong> the subordinate elements of a Validatable will
 * change.</p>
 *
 * <p>This ContentWillChangeListener can then be registered with the Validatable(s)
 * it is interested in monitoring and will then be notified each time an object
 * tries to modify the subordinate set monitored Validatable(s). This
 * ContentWillChangeListener has the opportunity to issue a veto to prevent the
 * change. This is especially helpful to perform validation before change.</p>
 *
 * @version $Revision: 1.2 $
 * @author Nicolas Radde
 *
 * @see ContentChangeEvent
 * @see gov.nist.atlas.Validatable
 */
public interface ContentWillChangeListener extends EventListener {

  /**
   * This function is called by the object who fire this associate event, before
   * to do the change. If a ValueChangedVetoException is throw during the call,
   * the change is canceled.
   *
   * @param event is the Event who contain information about the change
   * @throws ContentChangedVetoException is the exception throwing if the object is not
   *                                   agree with the change.
   */
  /**
   * This method is called whenever a change is requested on the subordinate set
   * of the monitored Validatable(s), <strong>before</strong> the actual change
   * thus allowing this ContentWillChangeListener to issue a veto on the change
   * by throwing a Content ChangedVetoException. In this case, the change will be
   * vetoed and no change will occur in the monitored element's subordinate
   * set(s).
   *
   * @param event a ContentChangeEvent describing the requested change
   * @throws ContentChangedVetoException if the change is vetoed for any reason
   */
  public void contentWillChange(ContentChangeEvent event) throws ContentChangedVetoException;
}