/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.test;

import gov.nist.atlas.ATLASAccessException;
import gov.nist.atlas.Anchor;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.CorporaManager;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Region;
import gov.nist.atlas.ref.ATLASRef;
import gov.nist.atlas.ref.AnchorRef;
import gov.nist.atlas.type.RegionType;
import gov.nist.atlas.util.ATLASElementSet;
import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * TestRegion the tests the Region interface
 *
 * @author Sylvain Pajot, Chris Laprun
 */
public class TestRegion extends AbstractATLASTest {

  public TestRegion(String name) {
    super(name);
  }

  public void setUp() {
    super.setUp();
    corpus = loadCorpus(CORPUS_NAME);
    annotation = corpus.getAnnotationWithId(PARENT_ANNOTATION_ID);
    anchor1 = corpus.getAnchorWithId(ANCHOR_ID1);
    anchor2 = corpus.getAnchorWithId(ANCHOR_ID2);
    AnchorRef aref1 = ATLASRef.createAnchorRef(anchor1, ANCHOR1_ROLE);
    AnchorRef aref2 = ATLASRef.createAnchorRef(anchor2, ANCHOR2_ROLE);
    AnchorRef[] anchorRefs = new AnchorRef[]{aref1, aref2};
    region = factory.createRegion(REGION_TYPE_NAME, corpus, null, null, anchorRefs);
    regionType = corpus.getMAIAScheme().getRegionType(REGION_TYPE_NAME);
  }


  public void testGetAnchorWithRole() {
    assertTrue(anchor1 != null);
    assertEquals(region.getAnchorWithRole(ANCHOR1_ROLE), anchor1);
    assertTrue(anchor2 != null);
    assertEquals(region.getAnchorWithRole(ANCHOR2_ROLE), anchor2);
  }

  public void testGetAllAnchors() {
    ATLASElementSet aes = region.getAllAnchors();
    assertTrue(aes != null);
    assertTrue(aes.size() == 2);
    assertTrue(aes.contains(anchor1));
    assertTrue(aes.contains(anchor2));
  }

  public void testGetAllRegions() {
    assertTrue(region.getAllRegions().isEmpty());
  }

  public void testGetAllAnnotations() {
    assertTrue(region.getAllAnnotations().isEmpty());
  }

  public void testAddAnchor() {
    try {
      region.addAnchor(anchor2);
    } catch (ATLASAccessException aae) {
      // expected result since it is not possible to add Anchors in interval regions
      return;
    }
    fail(); // if the test reach this point, the test should fail
  }

  public void testAddRegion() {
    try {
      region.addRegion(region);
    } catch (ATLASAccessException aae) {
      // expected result since it is not possible to add Regions in interval regions
      return;
    }
    fail(); // if the test reach this point, the test should fail
  }

  public void testAddAnnotation() {
    try {
      region.addAnnotation(annotation);
    } catch (ATLASAccessException aae) {
      // expected result since it is not possible to add Annotations in interval regions
      return;
    }
    fail(); // if the test reach this point, the test should fail
  }

//  public void TestInitContainedElementsWith() {
  //region.initContainedElementsWith(AnnotationRef[] annotations, RegionRef[] regions, AnchorRef[] anchors)
//  }

  public void testGetRegionType() {
    assertSame(region.getRegionType(), regionType);
  }

  public static Test suite() {
    return new TestSuite(TestRegion.class);
  }

  public void tearDown() {
    super.tearDown();
    CorporaManager.releaseCorpus(corpus);
  }

  private Corpus corpus;
  private Region region;
  private Annotation annotation;
  Anchor anchor1;
  Anchor anchor2;
  private RegionType regionType;

  private final static String CORPUS_NAME = "TestCorpus.aif.xml";
  private final static String REGION_TYPE_NAME = "interval";
  private final static String PARENT_ANNOTATION_ID = "Ann2";
  private final static String ANCHOR_ID1 = "Anc1";
  private final static String ANCHOR_ID2 = "Anc2";
  private final static String ANCHOR1_ROLE = "start";
  private final static String ANCHOR2_ROLE = "end";

}
