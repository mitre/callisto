/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.test;


import gov.nist.atlas.Anchor;
import gov.nist.atlas.CorporaManager;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Parameter;
import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * TestParameter tests the Parameter interface
 *
 * @author Sylvain Pajot
 */
public class TestParameter extends AbstractATLASTest {

  public TestParameter(String name) {
    super(name);
  }

  public void setUp() {
    super.setUp();
    corpus = loadCorpus(CORPUS_NAME);
    // Get an anchor to be able to init a new parameter
    anchor = corpus.getAnchorWithId(PARENT_ANCHOR_ID1);
    param = factory.createParameter(
        PARAMETER_TYPE,
        anchor,
        "",
        ANCHOR_VALUE1
    );
  }

  public void testSetValue() {
    param.setValue(ANCHOR_VALUE2);
    assertTrue(param.getValueAsString().equals(ANCHOR_VALUE2));
  }

  public void testGetUnit() {
    //assertTrue( param.getUnit().getName().equals(ANCHOR_UNIT) );
  }

  public static Test suite() {
    return new TestSuite(TestParameter.class);
  }

  public void tearDown() {
    super.tearDown();
    CorporaManager.releaseCorpus(corpus);
  }


  private Corpus corpus;
  private Parameter param;
  private Anchor anchor;

  private final static String CORPUS_NAME = "TestCorpus.aif.xml";
  private final static String PARENT_ANCHOR_ID1 = "Anc1";
  private final static String PARENT_ANCHOR_ID2 = "Anc2";
  private final static String ANCHOR_VALUE1 = "23";
  private final static String ANCHOR_VALUE2 = "18";
  private final static String ANCHOR_UNIT = "int";
  private final static String PARAMETER_TYPE = "int";
}
