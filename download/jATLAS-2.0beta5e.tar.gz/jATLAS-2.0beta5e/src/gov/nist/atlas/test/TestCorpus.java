/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.test;

import gov.nist.atlas.*;
import gov.nist.atlas.ref.ATLASRef;
import gov.nist.atlas.ref.AnchorRef;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.ATLASImplementationManager;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * TestCorpus tests the Corpus interface
 *
 * @author Chris Laprun, Sylvain Pajot
 */
public class TestCorpus extends AbstractATLASTest {
  public TestCorpus(String name) {
    super(name);
  }

  public void setUp() {
    super.setUp();
    corpus = loadCorpus(CORPUS_NAME);
    File file = new File(CORPUS_NAME);
    try {
      url = file.toURL();
    } catch (MalformedURLException e) {
    }
  }

  public void testGetCorpusType() {
    assertEquals(corpus.getCorpusType().getName(), CORPUS_TYPE);
  }

  public void testGetLocation() {
    assertEquals(url, corpus.getLocation());
  }

  public void testGetAIFVersion() {
    assertEquals(corpus.getAIFVersion(), CORPUS_AIFVERSION);
  }

  public void testContainsReusableElementWith() {
    assertTrue(corpus.containsReusableElementWith(TestCorpus.ANCHOR_ID));
    assertTrue(corpus.containsReusableElementWith(TestCorpus.ANNOTATION_ID));
  }

  public void testContainsReusableElementWith2() {
    assertTrue(corpus.containsReusableElementWith(ATLASClass.ANCHOR, TestCorpus.ANCHOR_ID));
    assertTrue(corpus.containsReusableElementWith(ATLASClass.ANNOTATION, TestCorpus.ANNOTATION_ID));
  }

  public void testGetReusableElementWith(){
    assertNotNull(corpus.getReusableElementWith(TestCorpus.ANCHOR_ID));
    assertNotNull(corpus.getReusableElementWith(TestCorpus.ANNOTATION_ID));
  }

  public void testGetReusableElementWith2(){
    assertNotNull(corpus.getReusableElementWith(ATLASClass.ANCHOR, TestCorpus.ANCHOR_ID));
    assertNotNull(corpus.getReusableElementWith(ATLASClass.ANNOTATION, TestCorpus.ANNOTATION_ID));
  }

  public void testContainsIdentifiableElementWith(){
    assertTrue(corpus.containsIdentifiableElementWith(TestCorpus.ANALYSIS_ID));
    assertTrue(corpus.containsIdentifiableElementWith(TestCorpus.ANCHOR_ID));
    assertTrue(corpus.containsIdentifiableElementWith(TestCorpus.ANNOTATION_ID));
  }

  public void testGetIdentifiableElementWith(){
    assertNotNull(corpus.getIdentifiableElementWith(TestCorpus.ANALYSIS_ID));
    assertNotNull(corpus.getIdentifiableElementWith(TestCorpus.ANCHOR_ID));
    assertNotNull(corpus.getIdentifiableElementWith(TestCorpus.ANNOTATION_ID));
  }

  public void testGetIdentifiableElementWith2(){
    assertNotNull(corpus.getIdentifiableElementWith(ATLASClass.ANALYSIS, TestCorpus.ANALYSIS_ID));
    assertNotNull(corpus.getIdentifiableElementWith(ATLASClass.ANCHOR, TestCorpus.ANCHOR_ID));
    assertNotNull(corpus.getIdentifiableElementWith(ATLASClass.ANNOTATION, TestCorpus.ANNOTATION_ID));
  }

  public void testGetAnalysisWithId() {
    Analysis analysis = corpus.getAnalysisWithId(ANALYSIS_ID);
    assertNotNull(analysis);
    assertEquals(analysis.getId().getAsString(), ANALYSIS_ID);
  }

  public void testGetAnalysisWithRole() {
    Analysis analysis = corpus.getAnalysisWithRole(ANALYSIS_ROLE);
    assertNotNull(analysis);
    assertEquals(analysis.getId().getAsString(), ANALYSIS_ID);
  }

  public void testGetAllAnalyses() {
    ATLASElementSet set = corpus.getAllAnalyses();
    assertNotNull(set);
    assertEquals(set.size(), NUMBER_ANALYSES);
    assertTrue(set.contains(corpus.getAnalysisWithId(ANALYSIS_ID)));
  }

  public void testGetAnchorWithId() {
    assertNotNull(corpus.getAnchorWithId(ANCHOR_ID));
  }

  public void testGetAnnotationWithId() {
    assertNotNull(corpus.getAnnotationWithId(ANNOTATION_ID));
  }

  public void testGetRegionWithId() {
    assertNotNull(corpus.getRegionWithId(REGION_ID));
  }

  public void testGetSignalWithId() {
    assertNotNull(corpus.getSignalWithId(SIGNAL1_ID));
  }

  public void testGetAllSignals() {
    ATLASElementSet set = corpus.getAllSignals();
    assertNotNull(set);
    assertEquals(set.size(), NUMBER_SIGNALS);
    assertTrue(set.contains(corpus.getSignalWithId(SIGNAL1_ID)));
  }

  public void testAddAnchor() {
    Anchor anchor = factory.createAnchor(ADD_ANCHOR_TYPE, corpus, corpus.getSignalWithId(SIGNAL1_ID));
    Id id = anchor.getId();
    assertNotNull(anchor);
    assertFalse(corpus.addAnchor(anchor)); // anchor is added when created...
    assertTrue(corpus.containsReusableElementWith(ATLASClass.ANCHOR, id.getAsString()));
    assertNotNull(corpus.getAnchorWithId(id.getAsString()));
  }

  public void testRemoveAnchor() {
    Anchor anchor = corpus.getAnchorWithId(REMOVE_ANCHOR_ID);
    assertNotNull(anchor);
    assertTrue(corpus.removeAnchor(anchor));
    assertNull(corpus.getAnchorWithId(REMOVE_ANCHOR_ID));
    assertFalse(corpus.containsReusableElementWith(ATLASClass.ANCHOR, REMOVE_ANCHOR_ID));
  }

  public void testAddRegion() {
    Annotation annotation = corpus.getAnnotationWithId(ANNOTATION_ID); // tested before

    Anchor anchor1 = corpus.getAnchorWithId(ADD_REGION_ANCHOR1_ID);
    Anchor anchor2 = corpus.getAnchorWithId(ADD_REGION_ANCHOR2_ID);
    AnchorRef aref1 = ATLASRef.createAnchorRef(anchor1, ADD_REGION_ANCHOR1_ROLE);
    AnchorRef aref2 = ATLASRef.createAnchorRef(anchor2, ADD_REGION_ANCHOR2_ROLE);
    AnchorRef[] anchorRefs = new AnchorRef[]{aref1, aref2};

    Region region = factory.createRegion(
        ADD_REGION_TYPE,
        annotation,
        null,
        null,
        anchorRefs
    );
    Id id = region.getId();
    assertNotNull(region);
    assertFalse(corpus.addRegion(region)); // region added when created
    assertTrue(corpus.containsReusableElementWith(ATLASClass.REGION, id.getAsString()));
    assertNotNull(corpus.getRegionWithId(id.getAsString()));
  }

  public void testRemoveRegion() {
    Region region = corpus.getRegionWithId(REMOVE_REGION_ID);
    assertNotNull(region);
    assertTrue(corpus.removeRegion(region));
    assertNull(corpus.getRegionWithId(REMOVE_REGION_ID));
    assertFalse(corpus.containsReusableElementWith(ATLASClass.REGION, REMOVE_REGION_ID));
  }

  public void testAddSignal() {
    Signal signal = factory.createSimpleSignal(
        ADD_SIGNAL_TYPE,
        corpus,
        MIMEClass.TEXT,
        ADD_SIGNAL_MIME_TYPE,
        ADD_SIGNAL_ENCODING,
        ADD_SIGNAL_TRACK,
        ADD_SIGNAL_URL
    );
    Id id = signal.getId();
    assertNotNull(signal);
    assertFalse(corpus.addSignal(signal));
    assertTrue(corpus.containsReusableElementWith(ATLASClass.SIGNAL, id.getAsString()));
    assertNotNull(corpus.getSignalWithId(id.getAsString()));
  }

  public void testRemoveSignal() {
    Signal signal = corpus.getSignalWithId(REMOVE_SIGNAL_ID);
    assertNotNull(signal);
    assertTrue(corpus.removeSignal(signal));
    assertNull(corpus.getSignalWithId(REMOVE_SIGNAL_ID));
    assertFalse(corpus.containsReusableElementWith(ATLASClass.SIGNAL, REMOVE_SIGNAL_ID));
  }

  public void testResolveTypeFor() {
    ATLASType type = corpus.resolveTypeFor(
        ATLASCLASS,
        TYPE_NAME
    );
    assertNotNull(type);
    assertEquals(type.getName(), TYPE_NAME);
  }

  public void testResolveIdFor() {
    Id id = corpus.resolveIdFor(ID_TO_RESOLV);
    assertNotNull(id);
    assertEquals(id.getAsString(), ID_TO_RESOLV);
  }

  public void testGetATLASImplementation() {
    ATLASImplementation impl = corpus.getATLASImplementation();
    assertNotNull(impl);
    assertSame(impl, ATLASImplementationManager.getDefaultImplementation());
  }

  public void tearDown() {
    super.tearDown();
    CorporaManager.releaseCorpus(corpus);
  }

  private Corpus corpus;
  private URL url;
  private final static String CORPUS_NAME = "TestCorpus.aif.xml";
  private final static String CORPUS_TYPE = "simple";
  private final static String CORPUS_LOCATION = "file:/TestCorpus.aif.xml";
  private final static String CORPUS_AIFVERSION = "1.1";
  private final static String ANALYSIS_ID = "Ana1";
  private final static String ANALYSIS_ROLE = "sentences";
  private final static int NUMBER_ANALYSES = 2;
  private final static int NUMBER_SIGNALS = 1;
  private final static String SIGNAL1_ID = "Sig1";
  private final static String ANCHOR_ID = "Anc4";
  private final static String ANNOTATION_ID = "Ann6";
  private final static String REGION_ID = "Reg4";

  private final static String ADD_ANCHOR_TYPE = "offset";
  private final static String ADD_ANCHOR_EXPECTED_ID = "Anc7";

  private final static String ADD_REGION_TYPE = "interval";
  private final static String ADD_REGION_ANCHOR1_ID = "Anc2";
  private final static String ADD_REGION_ANCHOR2_ID = "Anc3";
  private final static String ADD_REGION_ANCHOR1_ROLE = "start";
  private final static String ADD_REGION_ANCHOR2_ROLE = "end";
  private final static String ADD_REGION_EXPECTED_ID = "Reg6";
  private final static String ADD_SIGNAL_TYPE = "audio";
  private final static String ADD_SIGNAL_EXPECTED_ID = "Sig2";
  private final static String ADD_SIGNAL_MIME_TYPE = "ogg";
  private final static String ADD_SIGNAL_ENCODING = "null";
  private final static String ADD_SIGNAL_TRACK = "ALL";
  private final static String ADD_SIGNAL_URL = "http://www.signalparadise.com/firstSignal.sig";

  private final static String REMOVE_ANCHOR_ID = "Anc4";
  private final static String REMOVE_REGION_ID = "Reg3";
  private final static String REMOVE_SIGNAL_ID = "Sig1";

  private final static ATLASClass ATLASCLASS = ATLASClass.ANCHOR;
  private final static String TYPE_NAME = "offset";

  private final static String ID_TO_RESOLV = "Anc3";

}
