/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.test;

import gov.nist.atlas.Analysis;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.ATLASElementSetFactory;
import gov.nist.atlas.util.DefaultATLASElementSetFactory;
import gov.nist.atlas.util.MutableATLASElementSet;
import junit.framework.Test;
import junit.framework.TestSuite;

public class TestCorporaManager extends AbstractATLASTest {
  public TestCorporaManager(String name) {
    super(name);
  }

  public static Test suite() {
    return new TestSuite(TestCorporaManager.class);
  }

  public void testMultiLoading() {
    /* the loading of different corpus */
    /*Corpus corpSmall = loadCorpus("TestCorpus.aif.xml");
    Corpus corpGeneric = loadCorpus("Corpus.word.aif.xml");
    Corpus corpMaiaSplit = loadCorpus("c097.aif.xml");
    Corpus corpWeb = loadCorpus("http://www.nist.gov/speech/atlas/TestCorpus.aif.xml");*/


    /* And now all the assert */
    /*assertNotNull("test the nullity of the small corpus after loading", corpSmall);
    assertNotNull("test the nullity of the generic corpus after loading", corpGeneric);
    assertNotNull("test the nullity of the maiaSplit corpus after loading", corpMaiaSplit);
    assertNotNull("test the nullity of the web located corpus after loading", corpWeb);*/
    assertNotNull(corpCross);
  }

  public void testMultiCreation() {
  }

  public void testMultiCreationLoadingBoth() {
  }

  public void testCrossReferences() {
    Annotation ann1 = corpWeb.getAnnotationWithId("Ann1");
    assertNotNull(ann1);
    assertEquals(ann1.getDefiningCorpus(), corpWeb);

    Annotation ann2 = localCorpus.getAnnotationWithId("Ann1");
    assertNotNull(ann2);
    assertEquals(ann2.getDefiningCorpus(), localCorpus);

    ATLASElementSet set = localCorpus.getAnalysisWithRole("words").getAllAnnotations();
    ATLASElementSetFactory setFactory = new DefaultATLASElementSetFactory();
    MutableATLASElementSet children = setFactory.createMutableATLASElementSetFrom(set);
    children.remove(ann2);
    assertTrue(!children.contains(ann2));
    children.add(ann1);
    assertTrue(children.contains(ann1));

    Analysis sentences = localCorpus.getAnalysisWithRole("sentences");
    Annotation ann = factory.createAnnotation("sentence", sentences, children, children);
    assertTrue(sentences.containsAnnotationWithId(ann.getId().getAsString()));
    System.out.println("localCorpus = " + localCorpus.asAIFString());
  }

  public void setUp() {
    super.setUp();
    corpCross = loadCorpus("TestCrossRef.aif.xml");
    localCorpus = loadCorpus("TestCorpus.aif.xml");
    corpWeb = loadCorpus("http://www.nist.gov/speech/atlas/TestCorpus.aif.xml");
  }

  private Corpus corpCross;
  private Corpus localCorpus;
  private Corpus corpWeb;
}
