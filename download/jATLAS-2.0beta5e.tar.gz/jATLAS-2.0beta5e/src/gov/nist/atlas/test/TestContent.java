/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.test;

import gov.nist.atlas.Content;
import gov.nist.atlas.CorporaManager;
import gov.nist.atlas.Corpus;

/**
 * TestContent tests the Content interface.
 *
 * @author Sylvain Pajot
 */
public class TestContent extends AbstractATLASTest {

  public TestContent(String name) {
    super(name);
  }

  public void setUp() {
    super.setUp();
    corpus = loadCorpus(CORPUS_NAME);
    content = corpus.getAnnotationWithId(PARENT_ANNOTATION_ID).getContent();
  }

  public void testGetContentType() {
    assertTrue(content.getContentType().getName().equals(EXPECTED_CONTENT_TYPE));
  }

  // disabled for the testing Corpus ("string" Contents don't have an aligned region)
  /*public void testGetAlignedRegion() {
    System.out.println(content.getAlignedRegion().getId().getAsString());
    assertTrue( content.getAlignedRegion().getId().getAsString().equals(EXPECTED_ALIGNEDREGION_ID) );
  }*/

  public void tearDown() {
    super.tearDown();
    CorporaManager.releaseCorpus(corpus);
  }

  private Corpus corpus;
  private Content content;

  private final static String CORPUS_NAME = "TestCorpus.aif.xml";
  private final static String PARENT_ANNOTATION_ID = "Ann2";
  private final static String EXPECTED_CONTENT_TYPE = "string";
  private final static String EXPECTED_ALIGNEDREGION_ID = "regionAttributes1";

}
