package gov.nist.atlas.util;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * @author Chris Laprun
 * @version $Revision: 1.2 $
 * @since 2.0 Beta 6
 */
public class FilteredIterator implements Iterator {
  public FilteredIterator(Iterator iterator, FilteringStrategy filter) {
    this.iterator = iterator;
    this.filter = filter;
  }

  public boolean hasNext() {
    hasNextCalled = true;
    return getNext() != null;
  }

  public Object next() {
    if(hasNextCalled)
      return next;
    else {
      next = getNext();
      if(next != null)
        return next;
      throw new NoSuchElementException();
    }
  }

  public void remove() {
    throw new UnsupportedOperationException("FilteredIterator doesn't support remove (yet)!");
  }

  private Object getNext() {
    while(iterator.hasNext()) {
      next = iterator.next();
      if(!filter.filter(next))
        return next;
    }
    return null;
  }

  private Iterator iterator;
  private FilteringStrategy filter;
  private Object next;
  private boolean hasNextCalled = false;

  /**
   *
   */
  public static interface FilteringStrategy {
    /**
     * Determines if the specified Object should be filtered.
     *
     * @param object the Object currently being looked at by a FilteredIterator and which filtering status needs to
     *               be decided.
     * @return <code>true</code> if the specified Object needs to be filtered, meaning that it will be skipped by
     *         FilteredIterators using this FilteringStrategy, <code>false</code> otherwise
     * @throws IllegalArgumentException if the specified Object cannot be handled by this FilteringStrategy.
     */
    boolean filter(Object object) throws IllegalArgumentException;
  }
}
