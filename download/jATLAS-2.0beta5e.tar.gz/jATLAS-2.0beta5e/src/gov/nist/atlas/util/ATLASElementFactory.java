/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import gov.nist.atlas.*;
import gov.nist.atlas.ref.ATLASRef;
import gov.nist.atlas.ref.AnchorRef;
import gov.nist.atlas.ref.AnnotationRef;
import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.ref.SignalRef;
import gov.nist.atlas.type.*;
import gov.nist.maia.MAIAScheme;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;


/**
 * ATLASElementFactory provides all methods for ATLASElement creation.
 * <P>Contrary to PrimalATLASElementFactory, it does not create inconsistent
 * elements. Thus, some ATLASElements (that is Content, Feature, Parameter,
 * Metadata) are created with default value for their children elements by
 * only giving the mandatory information, whereas some others (that is Region,
 * SignalGroup, SimpleSignal) must always be created with at least the
 * references or the information they need.
 * <BR>Note that Analysises and Corpora are usually filled step by step. As a
 * consequence, such ATLASElements are valid (consistent) even if empty.
 * <P>ATLASElementFactory does not implement empty ATLASElements creation
 * method inherited from its superclass.
 *
 * @version $Revision: 1.3 $
 * @author Christophe Laprun, Sylvain Pajot
 */
public class ATLASElementFactory extends PrimalATLASElementFactory {

  ATLASElementFactory(ATLASImplementation implementation) {
    super(implementation);
  }

  /**
   * <p>Creates an ATLASElement with a given ATLASType and a given parent
   * ATLASElement. Only ATLASElements that can be created with default values
   * are considered using this method. For others, it will always return null.</p>
   *
   * <p>List of ATLASElements that cannot be created with default values:</p>
   * <ul>
   * <li><code>Anchor</code></li>
   * <li><code>Annotation</code></li>
   * <li><code>Region</code></li>
   * <li><code>Signal</code></li>
   * </ul>
   *
   * @param type the ATLASType of the ATLASElement to create
   * @param parent the parent ATLASElement of the ATLASElement to create
   *
   * @return a new ATLASElement with the specified ATLASType, initialized with
   * defaults values
   */
  public ATLASElement createDefaultATLASElementWith(ATLASType type, ATLASElement parent) {
    if (type == null)
      throw new IllegalArgumentException("You must pass a valid type!");
    ATLASClass c = type.getATLASClass();

    if (ATLASClass.ANCHOR.equals(c) || ATLASClass.ANNOTATION.equals(c)
        || ATLASClass.REGION.equals(c) || ATLASClass.SIGNAL.equals(c))
      return null;

    if (ATLASClass.ANALYSIS.equals(c))
      return createAnalysis(type, parent);

    if (ATLASClass.CHILDREN.equals(c))
      return createChildren(type, parent);

    if (ATLASClass.CONTENT.equals(c))
      return createContent(type, parent);

    if (ATLASClass.CORPUS.equals(c))
      return createCorpus(type);

    if (ATLASClass.FEATURE.equals(c))
      return createFeature(type, parent);

    if (ATLASClass.METADATA.equals(c))
      return createMetadata(type, parent);

    if (ATLASClass.PARAMETER.equals(c))
      return createParameter(type, parent, (Unit) null, ""); // FIX-ME : do something better

    return null; // should never reach this point!
  }

  /**
   * Creates an empty Analysis.
   *
   * @param type the ATLASType of the Analysis to create
   * @param parent the parent ATLASElement of the Analysis to create
   *
   * @return an empty Analysis for the specified ATLASType
   */
  public Analysis createAnalysis(ATLASType type, ATLASElement parent) {
    return createEmptyAnalysis(type, parent, createNewIdFor(type));
  }

  /**
   * Creates an empty Analysis.
   *
   * @param typeAsString the ATLASType's name of the Analysis to create
   * @param parent the parent ATLASElement of the Analysis to create
   *
   * @return an empty Analysis for the specified ATLASType's name
   */
  public Analysis createAnalysis(String typeAsString, ATLASElement parent) {
    return createAnalysis(resolveTypeFor(ATLASClass.ANALYSIS, typeAsString, parent.getDefiningCorpus()), parent);
  }

  /**
   * Creates an Anchor which parameters are initialized with default values.
   *
   * @param type the ATLASType of the Anchor to create
   * @param parent the parent ATLASElement of the Anchor to create
   * @param signal the SignalRef to which the Anchor refers
   *
   * @return an Anchor for the specified ATLASType which parameters are
   * initialized with default values
   *
   * @since 2.0 beta 4
   */
  public Anchor createAnchor(ATLASType type, ATLASElement parent, SignalRef signal) {
    checkType(type, AnchorType.class, ATLASClass.ANCHOR);

    AnchorType at = (AnchorType) type;
    at.checkInitParameters(signal, null, true);

    return createEmptyAnchor(at, parent, createNewIdFor(type), signal);
  }

  /**
   * Creates an Anchor which parameters are initialized with default values.
   *
   * @param typeAsString the ATLASType's name of the Anchor to create
   * @param parent the parent ATLASElement of the Anchor to create
   * @param signal the Signal to which the Anchor refers
   *
   * @return an Anchor for the specified ATLASType which parameters are
   * initialized with default values
   */
  public Anchor createAnchor(String typeAsString, ATLASElement parent, SignalRef signal) {
    return createAnchor(resolveTypeFor(ATLASClass.ANCHOR, typeAsString, parent.getDefiningCorpus()), parent, signal);
  }

  /**
   * Creates an Anchor which parameters are initialized with default values.
   *
   * @param type the ATLASType of the Anchor to create
   * @param parent the parent ATLASElement of the Anchor to create
   * @param signal the Signal to which the Anchor refers
   *
   * @return an Anchor for the specified ATLASType which parameters are
   * initialized with default values
   *
   * @deprecated Use version with SignalRef instead
   */
  public Anchor createAnchor(ATLASType type, ATLASElement parent, Signal signal) {
    checkType(type, AnchorType.class, ATLASClass.ANCHOR);
    AnchorType at = (AnchorType) type;
    return createAnchor(at, parent, ATLASRef.createSignalRef(signal, at.getRoleForSignal()));
  }

  /**
   * Creates an Anchor which parameters are initialized with default values.
   *
   * @param typeAsString the ATLASType's name of the Anchor to create
   * @param parent the parent ATLASElement of the Anchor to create
   * @param signal the Signal to which the Anchor refers
   *
   * @return an Anchor for the specified ATLASType which parameters are
   * initialized with default values
   *
   * @deprecated Use version with SignalRef instead
   */
  public Anchor createAnchor(String typeAsString, ATLASElement parent, Signal signal) {
    AnchorType type = (AnchorType) resolveTypeFor(ATLASClass.ANCHOR, typeAsString, parent.getDefiningCorpus());
    return createAnchor(type, parent, ATLASRef.createSignalRef(signal, type.getRoleForSignal()));
  }

  /**
   * Creates an Annotation which Content and Children are initialized with
   * default values.
   *
   * @param typeAsString the ATLASType's name of the Annotation to create
   * @param parent the parent ATLASElement of the Annotation to create
   * @param region the RegionRef to which the Annotation refers
   *
   * @return an Annotation for the specified ATLASType which Content and
   * Children are initialized with default values
   *
   * @since 2.0 beta 4
   */
  public Annotation createAnnotation(String typeAsString, ATLASElement parent, RegionRef region) {
    return createAnnotation(resolveTypeFor(ATLASClass.ANNOTATION, typeAsString, parent.getDefiningCorpus()), parent, region);
  }

  /**
   * Creates an Annotation which Content is initialized with default values.
   *
   * @param type the ATLASType of the Annotation to create
   * @param parent the parent ATLASElement of the Parameter to create
   * @param region the RegionRef to which the Annotation refers
   *
   * @return an Annotation for the specified ATLASType which Content is
   *         initialized with default values
   */
  public Annotation createAnnotation(ATLASType type, ATLASElement parent, RegionRef region) {
    return createAnnotation(type, parent, createNewIdFor(type), region);
  }

  /**
   * Creates an Annotation which Content is initialized with default values.
   *
   * @param type the ATLASType of the Annotation to create
   * @param parent the parent ATLASElement of the Parameter to create
   * @param id the identifier to assign to the new Annotation
   * @param region the RegionRef to which the Annotation refers
   *
   * @return an Annotation for the specified ATLASType which Content is
   *         initialized with default values
   *
   * @since 2.0 beta 4
   */
  public Annotation createAnnotation(ATLASType type, ATLASElement parent, Id id, RegionRef region) {

    checkType(type, AnnotationType.class, ATLASClass.ANNOTATION);

    AnnotationType at = (AnnotationType) type;
    at.checkInitParameters(region); // FIX-ME?

    Annotation annotation = createPrimalAnnotation(at, parent, id, region);
    return annotation;
  }

  /**
   * Creates an Annotation from the given information.
   *
   * @param typeAsString the ATLASType's name of the Annotation to create
   * @param parent the parent ATLASElement of the Annotation to create
   * @param region the RegionRef to which the Annotation refers
   * @param features a RoleIdentifiedFeature array to initialize
   * the Content with
   * @param parameters a RoleIdentifiedParameter array to initialize
   * the Content with
   * @param alignedRegion the RegionRef referencing the aligned Region of the
   * Annotation to create
   *
   * @return an Annotation for the specified ATLASType filled with the
   * specified information
   *
   * @since 2.0 beta 4
   */
  public Annotation createAnnotation(String typeAsString, ATLASElement parent, RegionRef region, RoleIdentifiedFeature[] features, RoleIdentifiedParameter[] parameters, RegionRef alignedRegion) {
    ATLASType type = resolveTypeFor(ATLASClass.ANNOTATION, typeAsString, parent.getDefiningCorpus());
    return createAnnotation(type, parent, createNewIdFor(type), region, features, parameters, alignedRegion);
  }

  /**
   * Creates an Annotation from the given information.
   *
   * @param type the ATLASType of the Annotation to create
   * @param parent the parent ATLASElement of the Annotation to create
   * @param region the RegionRef to which the Annotation refers
   * @param features a RoleIdentifiedFeature array to initialize
   * the Content with
   * @param parameters a RoleIdentifiedParameter array to initialize
   * the Content with
   * @param alignedRegion the RegionRef referencing the aligned Region of the
   * Annotation to create
   *
   * @return an Annotation for the specified ATLASType filled with the
   * specified information
   */
  public Annotation createAnnotation(ATLASType type, ATLASElement parent, RegionRef region, RoleIdentifiedFeature[] features, RoleIdentifiedParameter[] parameters, RegionRef alignedRegion) {
    return createAnnotation(type, parent, createNewIdFor(type), region, features, parameters, alignedRegion);
  }

  /**
   * Creates an Annotation from the given information.
   *
   * @param type the ATLASType of the Annotation to create
   * @param parent the parent ATLASElement of the Annotation to create
   * @param id the identifier to assign to the new Annotation
   * @param region the RegionRef to which the Annotation refers
   * @param features a RoleIdentifiedFeature array to initialize
   * the Content with
   * @param parameters a RoleIdentifiedParameter array to initialize
   * the Content with
   * @param alignedRegion the RegionRef referencing the aligned Region of the
   * Annotation to create
   *
   * @return an Annotation for the specified ATLASType filled with the
   * specified information
   *
   * @since 2.0 beta 4
   */
  public Annotation createAnnotation(ATLASType type, ATLASElement parent, Id id, RegionRef region, RoleIdentifiedFeature[] features, RoleIdentifiedParameter[] parameters, RegionRef alignedRegion) {
    checkType(type, AnnotationType.class, ATLASClass.ANNOTATION);

    AnnotationType at = (AnnotationType) type;
    at.checkInitParameters(region);

    Annotation annotation = createPrimalAnnotation(at, parent, id, region);
    annotation.initContentWith(features, parameters, alignedRegion);
    return annotation;
  }

  /**
   * Creates an Annotation from the sets of its Content-defining and
   * Region-defining subordinates.
   *
   * @param typeAsString the ATLASType's name of the Annotation to create
   * @param parent the parent ATLASElement of the Annotation to create
   * @param contentDefiningAnnotations an ATLASElementSet containing the
   *        subordinate Annotations that define the new Annotation's Content
   * @param regionDefiningAnnotations an ATLASElementSet containing the
   *        subordinate Annotations that define the new Annotation's Region
   *
   * @return a new Annotation as specified which Content and Region are defined
   * by the specified subordinate Annotations.
   */
  public Annotation createAnnotation(String typeAsString, ATLASElement parent, ATLASElementSet regionDefiningAnnotations, ATLASElementSet contentDefiningAnnotations) {
    return createAnnotation(resolveTypeFor(ATLASClass.ANNOTATION, typeAsString, parent.getDefiningCorpus()), parent, regionDefiningAnnotations, contentDefiningAnnotations);
  }

  /**
   * Creates an Annotation from the sets of its Content-defining and
   * Region-defining subordinates.
   *
   * @param type the ATLASType of the Annotation to create
   * @param parent the parent ATLASElement of the Annotation to create
   * @param regionDefiningAnnotations an ATLASElementSet containing the
   *        subordinate Annotations that define the new Annotation's Region
   * @param contentDefiningAnnotations an ATLASElementSet containing the
   *        subordinate Annotations that define the new Annotation's Content
   *
   * @return a new Annotation as specified which Content and Region are defined
   * by the specified subordinate Annotations.
   */
  public Annotation createAnnotation(ATLASType type, ATLASElement parent, ATLASElementSet regionDefiningAnnotations, ATLASElementSet contentDefiningAnnotations) {
    return createAnnotation(type, parent, createNewIdFor(type), regionDefiningAnnotations, contentDefiningAnnotations);
  }

  /**
   * Creates an Annotation from the sets of its Content-defining and
   * Region-defining subordinates.
   *
   * @param type the ATLASType of the Annotation to create
   * @param parent the parent ATLASElement of the Annotation to create
   * @param id the identifier to assign to the new Annotation
   * @param regionDefiningAnnotations an ATLASElementSet containing the
   *        subordinate Annotations that define the new Annotation's Region
   * @param contentDefiningAnnotations an ATLASElementSet containing the
   *        subordinate Annotations that define the new Annotation's Content
   *
   * @return a new Annotation as specified which Content and Region are defined
   * by the specified subordinate Annotations.
   *
   * @since 2.0 beta 4
   */
  public Annotation createAnnotation(ATLASType type, ATLASElement parent, Id id, ATLASElementSet regionDefiningAnnotations, ATLASElementSet contentDefiningAnnotations) {
    checkType(type, AnnotationType.class, ATLASClass.ANNOTATION);

    Annotation annotation = createPrimalAnnotation(type, parent, id, regionDefiningAnnotations, contentDefiningAnnotations);
    return annotation;
  }

  /**
   *
   * @param type
   * @param parent
   * @return
   *
   * @since 2.0 beta 4
   */
  public Children createChildren(ATLASType type, ATLASElement parent) {
    checkType(type, ChildrenType.class, ATLASClass.CHILDREN);

    Children children = createEmptyChildren(type, parent);
    return children;
  }


  /**
   * Creates an empty Corpus.
   *
   * @param type the ATLASType of the Corpus to create
   *
   * @return an empty Corpus for the specified ATLASType
   */
  public Corpus createCorpus(ATLASType type) {
    checkType(type, CorpusType.class, ATLASClass.CORPUS);

    Corpus corpus = createEmptyCorpus(type, createNewIdFor(type), null); // FIX-ME or not?
    return corpus;
  }

  /**
   * Creates an empty Corpus.
   *
   * @param typeAsString the ATLASType's name of the Corpus to create
   *
   * @return an empty Corpus for the specified ATLASType
   */
  public Corpus createCorpus(String typeAsString, MAIAScheme scheme) {
    return createCorpus(scheme.getATLASType(ATLASClass.CORPUS, typeAsString));
  }

  /**
   * Creates an empty Feature.
   *
   * @param type the ATLASType of the Feature to create
   * @param parent the parent ATLASElement of the Feature to create
   *
   * @return an empty Feature for the specified ATLASType
   */
  public Feature createFeature(ATLASType type, ATLASElement parent) {
    checkType(type, FeatureType.class, ATLASClass.FEATURE);

    Feature feature = createEmptyFeature(type, parent);
    return feature;
  }

  /**
   * Creates an empty Feature.
   *
   * @param typeAsString the ATLASType's name of the Feature to create
   * @param parent the parent ATLASElement of the Feature to create
   *
   * @return an empty Feature for the specified ATLASType
   */
  public Feature createFeature(String typeAsString, ATLASElement parent) {
    return createFeature(resolveTypeFor(ATLASClass.FEATURE, typeAsString, parent.getDefiningCorpus()), parent);
  }

  /**
   * Creates an empty Metadata.
   *
   * @param type the ATLASType of the Metadata to create
   * @param parent the parent ATLASElement of the Metadata to create
   *
   * @return an empty Metadata for the specified ATLASType
   */
  public Metadata createMetadata(ATLASType type, ATLASElement parent) {
    checkType(type, MetadataType.class, ATLASClass.METADATA);

    Metadata metadata = createEmptyMetadata(type, parent);
    return metadata;
  }

  /**
   * Creates an empty Metadata.
   *
   * @param typeAsString the ATLASType's name of the Metadata to create
   * @param parent the parent ATLASElement of the Metadata to create
   *
   * @return an empty MEtadata for the specified ATLASType
   */
  public Metadata createMetadata(String typeAsString, ATLASElement parent) {
    return createMetadata(resolveTypeFor(ATLASClass.METADATA, typeAsString, parent.getDefiningCorpus()), parent);
  }

  /**
   * Creates a Parameter from given information.
   *
   * @param type the ATLASType of the Parameter to create
   * @param parent the parent ATLASElement of the Parameter to create
   * @param unitName the Unit's name of the Parameter to create
   * @param value the value of the Parameter to create
   *
   * @return a Parameter for the specified ATLASType filled with the
   * specified information
   *
   * @deprecated Remove unitName parameter since this information should be
   *             managed by the type.
   */
  public Parameter createParameter(ATLASType type, ATLASElement parent, String unitName, String value) {
    checkType(type, ParameterType.class, ATLASClass.PARAMETER);

    Unit unit = resolveUnitFor(unitName);
    Parameter parameter = createParameter(type, parent, unit, value);
    return parameter;
  }

  /**
   * Creates a Parameter from given information.
   *
   * @param typeAsString the ATLASType's name of the Parameter to create
   * @param parent the parent ATLASElement of the Parameter to create
   * @param unitName the Unit's name of the Parameter to create
   * @param value the value of the Parameter to create
   *
   * @return a Parameter for the specified ATLASType filled with the
   * specified information
   *
   * @deprecated Remove unitName parameter since this information should be
   *             managed by the type.
   */
  public Parameter createParameter(String typeAsString, ATLASElement parent, String unitName, String value) {
    return createParameter(resolveTypeFor(ATLASClass.PARAMETER, typeAsString, parent.getDefiningCorpus()), parent, unitName, value);
  }

  /**
   * Creates a Region from given information.
   *
   * @param type the ATLASType of the Region to create
   * @param parent the parent ATLASElement of the Region to create
   * @param annotations an AnnotationRef array containing the annotations
   * which define the Region to create
   * @param regions an RegionRef array containing the regions which define
   * the Region to create
   * @param anchors an AnchorRef array containing the anchors which define
   * the Region to create
   *
   * @return a Region for the specified ATLASType filled with the
   * specified information
   */
  public Region createRegion(ATLASType type, ATLASElement parent, AnnotationRef[] annotations, RegionRef[] regions, AnchorRef[] anchors) {

    checkType(type, RegionType.class, ATLASClass.REGION);

    RegionType rt = (RegionType) type;
    rt.checkInitParameters(annotations, regions, anchors);

    Region region = createEmptyRegion(type, parent, createNewIdFor(type));
    region.initContainedElementsWith(annotations, regions, anchors);
    return region;
  }

  /**
   * Creates a Region from given information.
   *
   * @param typeAsString the ATLASType's name of the Region to create
   * @param parent the parent ATLASElement of the Region to create
   * @param annotations an AnnotationRef array containing the annotations
   * which define the Region to create
   * @param regions an RegionRef array containing the regions which define
   * the Region to create
   * @param anchors an AnchorRef array containing the anchors which define
   * the Region to create
   *
   * @return a Region for the specified ATLASType filled with the
   * specified information
   */
  public Region createRegion(String typeAsString, ATLASElement parent, AnnotationRef[] annotations, RegionRef[] regions, AnchorRef[] anchors) {
    return createRegion(resolveTypeFor(ATLASClass.REGION, typeAsString, parent.getDefiningCorpus()), parent, annotations, regions, anchors);
  }

  /**
   * Creates a SignalGroup from given information.
   *
   * @param type the ATLASType of the SignalGroup to create
   * @param parent the parent ATLASElement of the SignalGroup to create
   * @param signals a SignalRef array containing the signals which define the
   * SignalGroup to create
   *
   * @return a SignalGroup for the specified ATLASType and signals
   */
  public SignalGroup createSignalGroup(ATLASType type, ATLASElement parent, SignalRef[] signals) {

    checkType(type, SignalType.class, ATLASClass.SIGNAL);

    SignalGroup signalGroup = createEmptySignalGroup(type, parent, createNewIdFor(type));
    signalGroup.initContainedElementsWith(signals);
    return signalGroup;
  }

  /**
   * Creates a SignalGroup from given information.
   *
   * @param typeAsString the ATLASType's name of the SignalGroup to create
   * @param parent the parent ATLASElement of the SignalGroup to create
   * @param signals a SignalRef array containing the signals which define the
   * SignalGroup to create
   *
   * @return a SignalGroup for the specified ATLASType and signals
   */
  public SignalGroup createSignalGroup(String typeAsString, ATLASElement parent, SignalRef[] signals) {
    return createSignalGroup(resolveTypeFor(ATLASClass.SIGNAL, typeAsString, parent.getDefiningCorpus()), parent, signals);
  }

  /**
   * Creates a SimpleSignal from given information.
   *
   * @param type the ATLASType of the SimpleSignal to create
   * @param parent the parent ATLASElement of the SimpleSignal to create
   * @param mimeClass the <CODE>MIMEClass</CODE> of the SimplSignal to create
   * @param mimeType the MIME type of the SimplSignal to create
   * @param encoding the encoding type of the SimplSignal to create
   * @param track the track to which the SimpleSignal to create is related
   * @param urlAsString the URL locating the physical signal to which the
   * SimpleSignal to create is associated
   *
   * @return a SimpleSignal for the specified ATLASType filled with the
   * specified information
   *
   * @deprecated Change to createSimpleSignal(type, parent, track?, location)
   */
  public SimpleSignal createSimpleSignal(ATLASType type, ATLASElement parent, MIMEClass mimeClass, String mimeType, String encoding, String track, String urlAsString) {

    checkType(type, SignalType.class, ATLASClass.SIGNAL);

    URL url = null;
    try {
      url = new URL(urlAsString);
    } catch (MalformedURLException mue) {
      throw new IllegalArgumentException("Must pass a valid URL! Details: " + mue);
    }
    SimpleSignal signal = createSimpleSignal(type, parent, createNewIdFor(type),
        mimeClass, mimeType, encoding, track, url);
    return signal;
  }

  /**
   * Creates a SimpleSignal from given information.
   *
   * @param typeAsString the ATLASType's name of the SimpleSignal to create
   * @param parent the parent ATLASElement of the SimpleSignal to create
   * @param mimeClass the <CODE>MIMEClass</CODE> of the SimplSignal to create
   * @param mimeType the MIME type of the SimplSignal to create
   * @param encoding the encoding type of the SimplSignal to create
   * @param track the track to which the SimpleSignal to create is related
   * @param urlAsString the URL locating the physical signal to which the
   * SimpleSignal to create is associated
   *
   * @return a SimpleSignal for the specified ATLASType filled with the
   * specified information
   *
   * @deprecated Change to createSimpleSignal(type, parent, track?, location)
   */
  public SimpleSignal createSimpleSignal(String typeAsString, ATLASElement parent, MIMEClass mimeClass, String mimeType, String encoding, String track, String urlAsString) {
    return createSimpleSignal(resolveTypeFor(ATLASClass.SIGNAL, typeAsString,
        parent.getDefiningCorpus()), parent, mimeClass, mimeType, encoding,
        track, urlAsString);
  }

  /**
   * Creates an empty Content.
   *
   * @param type the ATLASType of the Content to create
   * @param parent the parent ATLASElement of the Content to create
   *
   * @return an empty Content for the specified ATLASType
   */
  protected Content createContent(ATLASType type, ATLASElement parent) {
    checkType(type, ContentType.class, ATLASClass.CONTENT);

    Content content = createEmptyContent(type, parent);
    return content;
  }

  /**
   * Checks the validity of a given type. It raises an
   * IllegalArgumentException if the specified type either does not refer to
   * the correct ATLASClass or is null.
   *
   * @param type the ATLASType to check
   * @param c the Class of the ATLASType the type should match
   * @param ac the ATLASClass of the expected type
   */
  protected final void checkType(ATLASType type, Class c, ATLASClass ac) {
    if (type == null || !c.isInstance(type))
      throw new IllegalArgumentException(new StringBuffer("A valid ")
          .append(ac.getName()).append("Type must be given to create this ")
          .append(ac.getName()).append(". Was given: ").append(type).toString());
  }

  /**
   * Retrieves the ATLASElementFactory associated with the specified implementation.
   *
   * @param implementation the ATLASImplementation for which an ATLASElementFactory
   *        is to be retrieved
   *
   * @return the ATLASElementFactory associated with the specified implementation
   *
   * @since 2.0 beta 4
   */
  public static ATLASElementFactory getFactoryFor(ATLASImplementation implementation) {
    ATLASElementFactory factory = (ATLASElementFactory) factories.get(implementation);
    if (factory == null) {
      factory = new ATLASElementFactory(implementation);
      factories.put(implementation, factory);
    }
    return factory;
  }

  /**
   *
   * @return
   *
   * @since 2.0 beta 5
   */
  public static ATLASElementFactory getDefaultFactory() {
    return DEFAULT_FACTORY;
  }

  private static final Map factories = new HashMap(5);
  private static final ATLASElementFactory DEFAULT_FACTORY =
      new ATLASElementFactory(ATLASImplementationManager.getDefaultImplementation());
}
