/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Analysis;
import gov.nist.atlas.Feature;
import gov.nist.atlas.Parameter;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;


/**
 * <p>RoleWrapper enhances some elements with a role, by wrapping them together.
 * <P>Such elements include Analysis, Feature, Parameter on the one hand,
 * Anchor, Annotation, Region, Signal on the other hand. The first category
 * groups ATLASElements holding role intrinsically, whereas the second one
 * groups every ReusableATLASElement, which can be combined with role in a
 * referred context.
 * <BR>Depending on the nature of the ATLASElement, RoleWrapper provides static
 * methods to wrap a role to either the element (first category) or a Reference
 * to the element.
 *
 * <P>Using the dynamic proxy mechanism introduced in the 1.3 version of Java,
 * RoleWrapper handles requests to elements by using delagation.
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun, Sylvain Pajot
 *
 * @see java.lang.reflect.InvocationHandler
 * @see RoleAddressable
 * @see <a href='http://java.sun.com/j2se/1.3/docs/guide/reflection/proxy.html'>
 * Dynamic Proxy Introduction</a>
 */
public class RoleWrapper implements InvocationHandler, RoleAddressable {
  protected RoleWrapper() {
  }

  protected RoleWrapper(ATLASElement element, String role) {
    initWith(element, role);
  }

  protected final void initWith(ATLASElement element, String role) {
    delegate = element;
    this.role = role;
  }

  /**
   * Creates a RoleIdentifiedAnalysis.
   *
   * @param analysis the Analysis upon which the RoleIdentifiedAnalysis to
   * create is based
   * @param role the role to be associated with the given Analysis
   * @return the RoleIdentifiedAnalysis which associates analysis and role
   */
  public static RoleIdentifiedAnalysis createRoleIdentifiedAnalysis(Analysis analysis, String role) {
    return (RoleIdentifiedAnalysis) createRoleWrapper(analysis, RoleIdentifiedAnalysis.class, role);
  }

  /**
   * Creates a RoleIdentifiedFeature.
   *
   * @param feature the Feature upon which the RoleIdentifiedFeature to
   * create is based
   * @param role the role to be associated with the given Feature
   * @return the RoleIdentifiedFeature which associates feature and role
   */
  public static RoleIdentifiedFeature createRoleIdentifiedFeature(Feature feature, String role) {
    return (RoleIdentifiedFeature) createRoleWrapper(feature, RoleIdentifiedFeature.class, role);
  }

  /**
   * Creates a RoleIdentifiedParameter.
   *
   * @param parameter the Parameter upon which the RoleIdentifiedParameter
   * to create is based
   * @param role the role to be associated with the given Parameter
   * @return the RoleIdentifiedParameter which associates parameter and role
   */
  public static RoleIdentifiedParameter createRoleIdentifiedParameter(Parameter parameter, String role) {
    return (RoleIdentifiedParameter) createRoleWrapper(parameter, RoleIdentifiedParameter.class, role);
  }

  /**
   * Gets the role associated to this wrapper's element.
   *
   * @return the role associated to this wrapper's element
   */
  public final String getRole() {
    return role;
  }

  /**
   * Gets the element of this wrapper.
   *
   * @return the element of this wrapper
   */
  public ATLASElement getElement() {
    return delegate;
  }

  /**
   * Dynamic proxy implementation
   */
  public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
    try {
      if (m.equals(GET_ROLE))
        return getRole();
      if (m.equals(GET_ELEMENT))
        return getElement();
      return m.invoke(delegate, args);
    } catch (InvocationTargetException e) {
      throw e.getTargetException();
    } catch (Exception e) {
      throw e;
    }
  }

  /**
   * Dynamic proxy instanciation
   */
  protected static Object createRoleWrapper(ATLASElement element, Class clazz, String role) {
    return Proxy.newProxyInstance(element.getClass().getClassLoader(), new Class[]{clazz}, new RoleWrapper(element, role));
  }

  /** Dynamic proxy implentation: this object's delegate*/
  protected ATLASElement delegate;
  /** the role associated to this object's delegate */
  protected String role;

  // Dynamic proxy related initializations
  private static Method GET_ROLE;
  private static Method GET_ELEMENT;

  static {
    try {
      GET_ROLE = RoleAddressable.class.getMethod("getRole", null);
      GET_ELEMENT = RoleAddressable.class.getMethod("getElement", null);
    } catch (NoSuchMethodException e) {
      // should never happen
    }
  }
}
