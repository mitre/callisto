/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * <p>A Map which keys, values and entries can be iterated over according to an
 * ordering specified by a Comparator.</p>
 *
 * <p>The current implementation is not really efficient since it creates
 * intermediate SortedSets in order to return the ordered iterators!</p>
 *
 * @author Christophe Laprun
 * @version $Revision: 1.2 $
 *
 * @since 2.0 beta 2
 */
public class SortableMap extends TreeMap {
  /**
   * Returns an iterator over this SortableMap's keys, ordered by the specified
   * Comparator.
   *
   * @param comparator the Comparator to use to sort this Map's keys.
   * @return an ordered iterator over this Map's keys
   */
  public Iterator sortedKeys(Comparator comparator) {
    return sortedIteratorFor(keySet(), comparator);
  }

  /**
   * Returns an iterator over this SortableMap's unique values (duplicate values
   * are omitted), ordered by the specified Comparator.
   *
   * @param comparator the Comparator to use to sort this Map's values.
   * @return an ordered iterator over this Map's values
   */
  public Iterator sortedUniqueValues(Comparator comparator) {
    return sortedIteratorFor(values(), comparator);
  }

  /**
   * Returns an iterator over this SortableMap's entries, ordered by the
   * specified Comparator.
   *
   * @param comparator the Comparator to use to sort this Map's entries
   * @return an ordered Iterator over this Map's entries
   */
  public Iterator sortedEntries(Comparator comparator) {
    return sortedIteratorFor(entrySet(), comparator);
  }

  /**
   * Returns an Iterator ordered as specified by the given Comparator over the
   * elements of the specifed Collection.
   *
   * @param collection a Collection containing the elements over which an
   *        ordered Iterator is desired
   * @param comparator a Comparator providing the ordering for the elements
   * @return an Iterator over the elements of the specified Collection, ordered
   *         according to the ordering specified by the given Comparator
   */
  private final Iterator sortedIteratorFor(Collection collection, Comparator comparator) {
    SortedSet result = new TreeSet(comparator);
    result.addAll(collection);
    return result.iterator();
  }
}
