/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Id;
import gov.nist.atlas.IdentifiableATLASElement;
import gov.nist.atlas.Region;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.type.ATLASType;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.Set;


/**
 * AbstractATLASElementSet does not
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public abstract class AbstractATLASElementSet implements ATLASElementSet, Mutable {
  /**
   * Constructs a new AbstractATLASElementSet with a given size and guarded by
   * a given ATLASType
   *
   * @param componentType the guarding ATLASType of the
   * AbstractATLASElementSet to create
   * @param size the size the AbstractATLASElementSet to create
   */
  public AbstractATLASElementSet(ATLASType componentType, int size) {
    this((Object) componentType, size, null);
  }

  /**
   * Constructs a new AbstractATLASElementSet with a given size and guarded by
   * a given ATLASClass
   *
   * @param componentClass the guarding ATLASClass of the
   * AbstractATLASElementSet to create
   * @param size the size the AbstractATLASElementSet to create
   */
  public AbstractATLASElementSet(ATLASClass componentClass, int size) {
    this((Object) componentClass, size, null);
  }

  public AbstractATLASElementSet(Object guard, int size, ATLASElementSetProperties properties) {
    if (guard instanceof ATLASClass) {
      GUARDED = CLASS_GUARDED;
    } else if (guard instanceof ATLASType) {
      GUARDED = TYPE_GUARDED;
    } else
      throw new IllegalArgumentException("An ATLASElementSet can only be guarded by an ATLASClass or an ATLASType");
    this.guard = guard;
    this.properties = properties;
    initContainer(size, properties);
  }

  public boolean contains(Id id) {
    if (containsIdentifiableElements())
      return get(id) != null;
    return false;
  }

  /**
   * Sub-classes should override this method if they can perform the retrieval
   * more efficiently.
   */
  public IdentifiableATLASElement get(Id id) {
    if (containsIdentifiableElements()) {
      while (iterator().hasNext()) {
        IdentifiableATLASElement element = (IdentifiableATLASElement) iterator().next();
        if (element.getId().equals(id))
          return element;
      }
      return null;
    }
    return null;
  }

  /**
   * Sub-classes should override this method if they can perform the retrieval
   * more efficiently.
   */
  public Iterator iteratorOverIds() {
    if (containsIdentifiableElements()) {
      // create a new Iterator over the ids
      return new Iterator() {
        private Iterator elements = iterator();

        public boolean hasNext() {
          return elements.hasNext();
        }

        public Object next() {
          if (!hasNext())
            throw new NoSuchElementException();
          return ((IdentifiableATLASElement) elements.next()).getId();
        }

        public void remove() {
          throw new UnsupportedOperationException();
        }
      };
    }
    return EmptyIterator.getInstance();
  }

  public boolean containsIdentifiableElements() {
    return getComponentATLASClass().isIdentifiable();
  }

  public ATLASElementSetProperties getProperties() {
    return properties;
  }

  public void toAIFBuffer(StringBuffer sb, String indent, String role, ATLASElement context) {
    if (!isTypeGuarded())
      throw new UnsupportedOperationException("asAIFString can only be called on a type guarded set");
    sb.append(indent).append("<");

    String name = getName(context instanceof Region); // FIX-ME

    sb.append(name).append(" containedType='")
        .append(getComponentATLASType().getName());

    if (role != null)
      sb.append("' role='").append(role);
    sb.append("'>\n");

    ATLASElement element = null;
    for (Iterator i = iterator(); i.hasNext();) {
      element = (ATLASElement) i.next();
      element.toAIFBuffer(sb, indent + AIFExportConstants.INDENT, role, context);
    }

    sb.append(indent).append("</").append(name).append(">\n");
  }

  public String asAIFString() {
    StringBuffer sb = new StringBuffer(DEFAULT_BUFFER_SIZE);
    toAIFBuffer(sb, AIFExportConstants.INDENT, "", null);
    return sb.toString();
  }

  /**
   * Formats and returns the ATLASElementSet element's name wether this
   * ATLASElementSet is a reference in the calling background or not.
   *
   * @param asRef true if this ATLASElementSet is actually referenced in the
   * calling background
   * @return the formatted name for the given boolean indicating wether this
   * ATLASElementSet is a reference in the calling background or not
   */
  protected String getName(boolean asRef) {
    if (name == null) {
      name = getComponentATLASClass().getName();
      if (asRef)
        name += "RefSet";
      else
        name += "Set";
    }
    return name;
  }

  public void setAIFName(String name) {
    this.name = name;
  }


  public final boolean isTypeGuarded() {
    return GUARDED == TYPE_GUARDED;
  }

  /**
   * <p>Determines if this ATLASElementSet contains exactly the same
   * ATLASElements than the given ATLASElementSet.</p>
   *
   * <p>Note that this method is fast-failing in case <code>other</code> is not
   * and ATLASElementSet or this ATLASElementSet's size or guard is not equal to
   * that of <code>other</code></p>
   *
   * @param other the reference object with which to compare
   *
   * @return <code>true</code> if other containes the same ATLASElements than
   *         this ATLASElementSet, <code>false</code> otherwise.
   */
  public boolean equals(Object other) {
    if (other == this)
      return true;
    if (!(other instanceof ATLASElementSet))
      return false;
    ATLASElementSet set = (ATLASElementSet) other;
    if (set.size() != this.size())
      return false;
    return containsAll(set); // containsAll also checks guard information
  }

  public int hashCode() {
    if (!hasChanged)
      return hash;
    Object obj;
    Iterator i = iterator();
    while (i.hasNext()) {
      obj = i.next();
      if (obj != null)
        hash += obj.hashCode();
    }
    hasChanged = false;
    return hash;
  }

  /**
   * <p>Compares and returns the result of the lexicographical comparison between
   * this ATLASElementSet and a given ATLASElementSet.</p>
   *
   * <p>The result of the comparison of two ATLASElementSets is the same as the
   * comparison between their first different contained elements. If all their
   * contained elements are compared equal, then the larger ATLASElementSet is
   * considered greater than the other one.</p>
   *
   * @param other the ATLASElementSet to compare this ATLASElementSet to
   *
   * @return a strictly positive <code>int</code> if this ATLASElementSet is
   * greater than the given ATLASElementSet, a strictly
   * negative <code>int</code> if it is smaller and <code>0</code> if both
   * ATLASElementSets are equal.
   *
   * @see java.lang.Comparable#compareTo(Object)
   */
  public int compareTo(Object other) {
    ATLASElementSet set = (ATLASElementSet) other;
    if (!isSetOK(set)) {
      throw new ClassCastException("Cannot compare an ATLASElementSet containing "
          + set.getComponentATLASClass().getName()
          + " elements with this ATLASElementSet (containing "
          + getComponentATLASClass().getName() + " elements).");
    } else {
      Iterator i = iterator();
      Iterator j = set.iterator();

      int s = size();
      int os = set.size();

      Iterator smaller = (s <= os) ? i : j;

      int result = 0;
      while (smaller.hasNext()) {
        result = ((Comparable) i.next()).compareTo(j.next());
        if (result != 0)
          return result;
      }

      if (s != os)
        return (s > os) ? 1 : -1;

      return result;
    }
  }

  public String toString() {
    StringBuffer desc = new StringBuffer("ATLASElementSet [");
    desc.append(GUARDED).append("] class: ").append(getClass().getName());
    if (!isEmpty()) {
      desc.append(" containing:\n");
      Iterator i = iterator();
      while (i.hasNext())
        desc.append(i.next()).append('\n');
    } else
      desc.append(" EMPTY");
    return desc.toString();
  }

  public boolean add(ATLASElement element) {
    if (isElementOK(element) && !contains(element))
      return specificAdd(element);
    return false;
  }

  /**
   * Encapsulates the adding logic specific to the underlying data structure.
   * Does not perform any validation checks since these are done in
   * <code>add</code>.
   *
   * @param element the ATLASElement to be added to this ATLASElementSet
   *
   * @return <code>true</code> if the operation was successful, <code>false</code>
   *         otherwise
   *
   * @see #add(ATLASElement)
   *
   * @since 2.0 beta 4
   *
   * @deprecated Move to SPI
   */
  protected abstract boolean specificAdd(ATLASElement element);

  public boolean addAll(ATLASElementSet set) {
    if (!isSetOK(set))
      return false;
    return addAll(set.iterator(), set.size());
  }

  public boolean addAll(Iterator elements, int numberOfElements) {
    if (elements == null)
      return false;
    ATLASElement el;
    if (numberOfElements < 0)
      numberOfElements = 7;
    HashSet added = new HashSet(numberOfElements);
    while (elements.hasNext()) {
      el = (ATLASElement) elements.next();
      if (add(el))
        added.add(el);
      else {
        fastRemoveAll(added);
        added = null;
        return false;
      }
    }
    el = null;
    added = null;
    elements = null;
    return true;
  }


  public boolean remove(ATLASElement element) {
    if (isElementOK(element) && contains(element))
      return specificRemove(element);
    return false;
  }

  /**
   * Encapsulates the removing logic specific to the underlying data structure.
   * Does not perform any validation checks since these are done in
   * <code>remove</code>.
   *
   * @param element the ATLASElement to be removed to this ATLASElementSet
   *
   * @return <code>true</code> if the operation was successful, <code>false</code>
   *         otherwise
   *
   * @see #remove(ATLASElement)
   *
   * @since 2.0 beta 4
   *
   * @deprecated Move to SPI
   */
  protected abstract boolean specificRemove(ATLASElement element);

  public boolean removeAll(ATLASElementSet set) {
    if (!isSetOK(set))
      return false;
    Iterator i = set.iterator();
    ATLASElement el;
    // need to store list of already removed elements for potential undo
    HashSet removed = new HashSet(set.size());
    while (i.hasNext()) {
      el = (ATLASElement) i.next();
      if (remove(el))
        removed.add(el); // successfull removal: add to removed list
      else {
        fastAddAll(removed); // re-add already removed elements
        removed = null;
        return false;
      }
    }
    el = null;
    i = null;
    removed = null;
    return true;
  }

  public boolean containsAll(ATLASElementSet set) {
    if (!isSetOK(set))
      return false;
    Iterator i = set.iterator();
    ATLASElement el;
    while (i.hasNext()) {
      el = (ATLASElement) i.next();
      if (!contains(el))
        return false;
    }
    el = null;
    i = null;
    return true;
  }

  public ListIterator orderedIterator(Comparator comparator) {
    ATLASElement[] array = toArray();
    Arrays.sort(array, comparator);
    return Arrays.asList(array).listIterator();
  }

  public final ATLASType getComponentATLASType() {
    if (!isTypeGuarded())
      throw new UnsupportedOperationException("getComponentATLASType is only available if this ATLASElementSet is type guarded!");
    return (ATLASType) guard;
  }

  public final ATLASClass getComponentATLASClass() {
    if (isTypeGuarded())
      return ((ATLASType) guard).getATLASClass();
    return (ATLASClass) guard;
  }

  public Object getGuard() {
    return guard;
  }

  /**
   * Creates and initializes the actual ATLASElement container with a given size.
   *
   * @param size the size of the container to create
   * @param properties the properties the user has in mind for this ATLASElementSet
   */
  protected abstract void initContainer(int size, ATLASElementSetProperties properties);


  /**
   * Checks if a given ATLASElement has the same ATLASClass (or ATLASType if
   * this ATLASElementSet is ATLASType guarded) than this contained
   * ATLASElementSet's ATLASClass (or ATLASType if this ATLASElementSet is
   * ATLASType guarded)
   *
   * @param element the ATLASElement to check
   * @return true if the specified ATLASElement has the same ATLASClass (or
   * ATLASType if this ATLASElementSet is ATLASType guarded) than this
   * contained ATLASElementSet's ATLASClass (or ATLASType if this
   * ATLASElementSet is ATLASType guarded)
   */
  protected boolean isElementOK(ATLASElement element) {
    return (element != null
        && getComponentATLASClass().equals(element.getATLASType().getATLASClass())
        && ((isTypeGuarded()) ? // is this also type guarded?
        // yes: check ATLASType also
        getComponentATLASType().equals(element.getATLASType()) :
        // no: element is already valid
        true));
  }

  /**
   * Checks if a given ATLASElementSet has the same contained ATLASClass (or
   * ATLASType if this ATLASElementSet is ATLASType guarded) than this
   * contained ATLASElementSet's ATLASClass (or ATLASType if this
   * ATLASElementSet is ATLASType guarded)
   *
   * @param set the ATLASElementSet to check
   * @return true if the specified ATLASElementSet has the same contained
   * ATLASClass (or ATLASType if this ATLASElementSet is ATLASType guarded)
   * than this contained ATLASElementSet's ATLASClass (or ATLASType if this
   * ATLASElementSet is ATLASType guarded)
   */
  protected boolean isSetOK(ATLASElementSet set) {
    return (set != null
        && getComponentATLASClass().equals(set.getComponentATLASClass())
        && ((set.isTypeGuarded() && isTypeGuarded()) ? // are both sets also type guarded?
        // yes : check component type
        getComponentATLASType().equals(set.getComponentATLASType()) :
        // no: then set is already OK
        true));
  }

  /**
   * Method only used to recover from an error situation in addAll. The given
   * set contains elements that have successfully been added to this
   * ATLASElementSet during addAll. They are therefore valid with respect to
   * constraints and no checks are required.
   */
  private final void fastRemoveAll(Set set) {
    if (set.isEmpty())
      return;
    Iterator i = set.iterator();
    while (i.hasNext())
      specificRemove((ATLASElement) i.next());
  }

  /**
   * Method only used to recover from an error situation in removeAll. The given
   * set contains elements that have successfully been added to this
   * ATLASElementSet during removeAll. They are therefore valid with respect to
   * constraints and no checks are required.
   */
  private final void fastAddAll(Set set) {
    if (set.isEmpty())
      return;
    Iterator i = set.iterator();
    while (i.hasNext())
      specificAdd((ATLASElement) i.next());
  }

  /**
   * The class that guards this ATLASElementSet. It is either an ATLASClass
   * or an ATLASType
   */
  private final Object guard;

  /**
   * Hash code for this ATLASElementSet.
   */
  private int hash;

  /**
   * The name used to print this ATLASElementSet to AIF.
   */
  private String name;

  /**
   * Indicates whether this ATLASElementSet has changed since last hash code
   * computation.
   */
  private boolean hasChanged = false;

  private ATLASElementSetProperties properties;

  private final String GUARDED;
  private final static String TYPE_GUARDED = "type-guarded";
  private final static String CLASS_GUARDED = "class-guarded";
  private final int DEFAULT_BUFFER_SIZE = 2500;
}


