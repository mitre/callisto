/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.type.ATLASType;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


/**
 * ATLASElementSetFactory is the abtract definition that provides the
 * signature of the creation methods for every ATLASElementSet implementations
 * designed for the ATLAS framework.
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun, Sylvain Pajot
 *
 * @see gov.nist.atlas.util.ATLASElementSet
 */
public abstract class ATLASElementSetFactory {
  ATLASElementSetFactory() {
    this.implementation = ATLASImplementationManager.getDefaultImplementation();
  }

  ATLASElementSetFactory(ATLASImplementation implementation) {
    this.implementation = implementation;
  }

  /**
   *
   * @param guard
   * @param numberOfElements
   * @param properties
   * @return
   *
   * @since 2.0 beta 5
   */
  public abstract MutableATLASElementSet createMutableATLASElementSet(Object guard, int numberOfElements, ATLASElementSetProperties properties);

  /**
   *
   * @param guard
   * @param elements
   * @param properties
   * @return
   *
   * @since 2.0 beta 5
   */
  public ATLASElementSet createATLASElementSetFrom(Object guard, Collection elements, ATLASElementSetProperties properties) {
    if (elements != null && !elements.isEmpty()) {
      return createMutableATLASElementSetFrom(guard, elements.iterator(), elements.size(), properties);
    }
    return getEmptyATLASElementSet(guard);
  }

  /**
   *
   * @param elements
   * @return
   *
   * @since 2.0 beta 5
   */
  public ATLASElementSet createATLASElementSetFrom(ATLASElementSet elements) {
    return createATLASElementSetFrom(null, elements, elements.getProperties());
  }

  /**
   *
   * @param guard
   * @param elements
   * @param properties
   * @return
   *
   * @since 2.0 beta 5
   */
  public ATLASElementSet createATLASElementSetFrom(Object guard, ATLASElementSet elements, ATLASElementSetProperties properties) {
    if (elements != null && !elements.isEmpty()) {
      if (guard == null)
        guard = elements.getGuard();
      return createMutableATLASElementSetFrom(guard, elements.iterator(), elements.size(), properties);
    }
    return getEmptyATLASElementSet(guard);
  }

  /**
   *
   * @param guard
   * @param elements
   * @param properties
   * @return
   *
   * @since 2.0 beta 5
   */
  public ATLASElementSet createATLASElementSetFrom(Object guard, ATLASElement[] elements, ATLASElementSetProperties properties) {
    if (elements != null) {
      return createMutableATLASElementSetFrom(guard, new ArrayIterator(elements), elements.length, properties);
    }
    return getEmptyATLASElementSet(guard);
  }

  /**
   *
   * @param guard
   * @param elements
   * @param numberOfElements
   * @param properties
   * @return
   *
   * @since 2.0 beta 5
   */
  public ATLASElementSet createATLASElementSetFrom(Object guard, Iterator elements, int numberOfElements, ATLASElementSetProperties properties) {
    return createMutableATLASElementSetFrom(guard, elements, numberOfElements, properties);
  }

  /**
   *
   * @param guard
   * @param elements
   * @param properties
   * @return
   *
   * @since 2.0 beta 5
   */
  public MutableATLASElementSet createMutableATLASElementSetFrom(Object guard, Collection elements, ATLASElementSetProperties properties) {
    if (elements == null)
      return createMutableATLASElementSet(guard, DEFAULT_SIZE, properties);
    return createMutableATLASElementSetFrom(guard, elements.iterator(),
        elements.size(), properties);
  }

  /**
   *
   * @param elements
   * @return
   *
   * @since 2.0 beta 5
   */
  public MutableATLASElementSet createMutableATLASElementSetFrom(ATLASElementSet elements) {
    return createMutableATLASElementSetFrom(null, elements, elements.getProperties());
  }

  /**
   *
   * @param guard
   * @param elements
   * @param properties
   * @return
   *
   * @since 2.0 beta 5
   */
  public MutableATLASElementSet createMutableATLASElementSetFrom(Object guard, ATLASElementSet elements, ATLASElementSetProperties properties) {
    if (elements == null)
      return createMutableATLASElementSet(guard, DEFAULT_SIZE, properties);
    if (guard == null)
      guard = elements.getGuard();
    return createMutableATLASElementSetFrom(guard, elements.iterator(), elements.size(), properties);
  }

  /**
   *
   * @param guard
   * @param elements
   * @param properties
   * @return
   *
   * @since 2.0 beta 5
   */
  public MutableATLASElementSet createMutableATLASElementSetFrom(Object guard, ATLASElement[] elements, ATLASElementSetProperties properties) {
    if (elements == null)
      return createMutableATLASElementSet(guard, DEFAULT_SIZE, properties);
    return createMutableATLASElementSetFrom(guard, new ArrayIterator(elements),
        elements.length, properties);
  }

  /**
   *
   * @param guard
   * @param elements
   * @param numberOfElements
   * @param properties
   * @return
   *
   * @since 2.0 beta 5
   */
  public MutableATLASElementSet createMutableATLASElementSetFrom(Object guard, Iterator elements, int numberOfElements, ATLASElementSetProperties properties) {
    if (elements == null)
      elements = EmptyIterator.getInstance();
    MutableATLASElementSet set = createMutableATLASElementSet(guard, numberOfElements, properties);
    set.addAll(elements, numberOfElements);
    return set;
  }

  /**
   *
   * @param guard
   * @return
   *
   * @since 2.0 beta 5
   */
  public ATLASElementSet getEmptyATLASElementSet(Object guard) {
    return new ArrayListATLASElementSet(guard, 0, null);
  }

  /**
   *
   * @param type
   * @return
   *
   * @since 2.0 beta 5
   */
  public ATLASElementSet getEmptyATLASElementSet(ATLASType type) {
    return getEmptyATLASElementSet((Object) type);
  }

  /**
   *
   * @param clazz
   * @return
   *
   * @since 2.0 beta 5
   */
  public ATLASElementSet getEmptyATLASElementSet(ATLASClass clazz) {
    return getEmptyATLASElementSet((Object) clazz);
  }

  /**
   * Retrieves the ATLASElementSetFactory associated with the specified
   * implementation. If no factory has already been associated to the given
   * implementation, the default factory is used and associated with this
   * implementation.
   *
   * @param implementation the ATLASImplementation for which an ATLASElementSetFactory
   *        is to be retrieved
   *
   * @return the ATLASElementSetFactory associated with the specified implementation
   *
   * @since 2.0 beta 5
   */
  public static ATLASElementSetFactory getFactoryFor(ATLASImplementation implementation) {
    ATLASElementSetFactory factory = (ATLASElementSetFactory) factories.get(implementation);
    if (factory == null) {
      factory = DEFAULT_FACTORY;
      factories.put(implementation, factory);
    }
    return factory;
  }

  /**
   * Retrieves the default ATLASElementSetFactory.
   *
   * @return the default ATLASElementSetFactory
   *
   * @since 2.0 beta 5
   */
  public static ATLASElementSetFactory getDefaultFactory() {
    return DEFAULT_FACTORY;
  }

  protected static class MutableWrapper implements InvocationHandler {
    private MutableWrapper(ATLASElementSet set) {
      if (set instanceof Mutable)
        this.delegate = set;
      else
        throw new IllegalArgumentException("MutableWrapper error: the delegate set is NOT Mutable");
    }

    protected static MutableATLASElementSet createMutableWrapper(ATLASElementSet set) {
      return (MutableATLASElementSet) Proxy.newProxyInstance(
          set.getClass().getClassLoader(),
          new Class[]{MutableATLASElementSet.class}, new MutableWrapper(set));
    }

    public boolean add(ATLASElement element) {
      return ((Mutable) delegate).add(element);
    }

    public boolean addAll(ATLASElementSet set) {
      return ((Mutable) delegate).addAll(set);
    }

    public boolean remove(ATLASElement element) {
      return ((Mutable) delegate).remove(element);
    }

    public boolean removeAll(ATLASElementSet set) {
      return ((Mutable) delegate).removeAll(set);
    }

    public void clear() {
      ((Mutable) delegate).clear();
    }

    public String toString() {
      return delegate.toString();
    }

    public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
      try {
        if (m.equals(ADD)) {
          boolean result = add((ATLASElement) args[0]);
          return (result) ? Boolean.TRUE : Boolean.FALSE;
        }
        if (m.equals(REMOVE)) {
          boolean result = remove((ATLASElement) args[0]);
          return (result) ? Boolean.TRUE : Boolean.FALSE;
        }
        if (m.equals(ADD_ALL)) {
          boolean result = addAll((ATLASElementSet) args[0]);
          return (result) ? Boolean.TRUE : Boolean.FALSE;
        }
        if (m.equals(REMOVE_ALL)) {
          boolean result = removeAll((ATLASElementSet) args[0]);
          return (result) ? Boolean.TRUE : Boolean.FALSE;
        }
        if (m.equals(CLEAR)) {
          clear();
          return null;
        }
        return m.invoke(delegate, args);
      } catch (InvocationTargetException e) {
        throw e.getTargetException();
      } catch (Exception e) {
        throw e;
      }
    }

    private ATLASElementSet delegate;
    // Dynamic proxy related initializations
    private static Method ADD;
    private static Method ADD_ALL;
    private static Method REMOVE;
    private static Method REMOVE_ALL;
    private static Method CLEAR;

    static {
      try {
        ADD = Mutable.class.getMethod("add", new Class[]{ATLASElement.class});
        ADD_ALL = Mutable.class.getMethod("addAll", new Class[]{ATLASElementSet.class});
        REMOVE = Mutable.class.getMethod("remove", new Class[]{ATLASElement.class});
        REMOVE_ALL = Mutable.class.getMethod("removeAll", new Class[]{ATLASElementSet.class});
        CLEAR = Mutable.class.getMethod("clear", null);
      } catch (NoSuchMethodException e) {
        // should never happen
      }
    }
  }

  private static final Map factories = new HashMap(5);
  protected ATLASImplementation implementation;
  private static final int DEFAULT_SIZE = 17;
  private static final ATLASElementSetFactory DEFAULT_FACTORY = new DefaultATLASElementSetFactory();
}


