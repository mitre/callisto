/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;


import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.ReusableATLASElement;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Manages references.
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public class ReferentManager {
  private ReferentManager() {
  }

  public static final boolean addReferentTo(ReusableATLASElement element, ATLASElement referent) {
    if (element == null || referent == null)
      return false;
    String id = element.getIdAsURL();
    if (referentsTable.containsKey(id)) {
      ReferentSet referents = (ReferentSet) referentsTable.get(id);
      if (referent.equals(referents.getParent()))
        return false; // parent handled separately
      return referents.addReferent(referent);
    } else {
      ReferentSet set = new ReferentSet();
      set.addReferent(referent);
      referentsTable.put(id, set);
      return true;
    }
  }

  public static final boolean removeReferentFrom(ReusableATLASElement element, ATLASElement referent) {
    String id = element.getIdAsURL();
    if (referentsTable.containsKey(id))
      return ((ReferentSet) referentsTable.get(id)).removeReferent(referent);
    throw new IllegalArgumentException(referent + " is not a referent for " + element);
  }

  public static final Set getReferentsFor(ReusableATLASElement element) {
    String id = element.getIdAsURL();
    if (referentsTable.containsKey(id))
      return ((ReferentSet) referentsTable.get(id)).getReferents();
    return Collections.EMPTY_SET;
  }

  public static final boolean setParentFor(ReusableATLASElement element, ATLASElement parent) {
    String id = element.getIdAsURL();
    if (referentsTable.containsKey(id)) {
      ReferentSet set = ((ReferentSet) referentsTable.get(id));
      if (set.getParent() != null) // the element already exists in the table: we cannot change its parent!
        throw new IllegalArgumentException("The element: " + element + " has already a parent!");
      else
        set.setParent(parent);
    } else
      referentsTable.put(id, new ReferentSet(parent));
    return true;
  }

  public static final ATLASElement getParentFor(ReusableATLASElement element) {
    String id = element.getIdAsURL();
    if (!referentsTable.containsKey(id))
      return null; // throw exception?
    return ((ReferentSet) referentsTable.get(id)).getParent();
  }

  /**
   * FIX-ME: DOES NOT WORK
   * @param corpus
   */
  public static void releaseCorpus(Corpus corpus) {
    Iterator i = referentsTable.entrySet().iterator();
    while (i.hasNext()) {
      String key = (String) ((Map.Entry) i.next()).getKey();
      if (key.startsWith(corpus.getLocation().toExternalForm())) {
        i.remove();
      }
    }
  }

  private final static Map referentsTable = new HashMap();

  private static class ReferentSet {
    ReferentSet() {
    }

    ReferentSet(ATLASElement parent) {
      this();
      this.parent = parent;
    }

    public String toString() {
      return new String("\nParent: " + parent + "\nReferents: " + referents + "\n");
    }

    ATLASElement getParent() {
      return parent;
    }

    void setParent(ATLASElement parent) {
      this.parent = parent;
    }

    boolean addReferent(ATLASElement referent) {
      return referents.add(referent);
    }

    boolean removeReferent(ATLASElement referent) {
      return referents.remove(referent);
    }

    Set getReferents() {
      return Collections.unmodifiableSet(referents);
    }

    ATLASElement parent;
    Set referents = new HashSet();
  }
}


