/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.util;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.type.ATLASType;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;


/**
 * <p>AbstractListBasedATLASElementSet is a skeletal implementation of the
 * ListBasedATLASElementSet interface.</p>
 *
 * <p>To implement the ListBasedATLASElementSet interface, the user only
 * needs to create a class that inherits from AbstractListBasedATLASElementSet
 * and to implement the initContainerWith method (usually used to set the
 * initial List capacity) and the appropriate constructor(s).</p>
 *
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun, Sylvain Pajot
 *
 * @see ListBasedATLASElementSet
 */
abstract public class AbstractListBasedATLASElementSet extends AbstractATLASElementSet implements ListBasedATLASElementSet {
  public AbstractListBasedATLASElementSet(ATLASType componentType, int size) {
    this(componentType, size, null);
  }

  public AbstractListBasedATLASElementSet(ATLASClass clazz, int size) {
    this(clazz, size, null);
  }

  public AbstractListBasedATLASElementSet(Object guard, int size, ATLASElementSetProperties properties) {
    super(guard, size, properties);
  }

  public void sort() {
    Collections.sort(elements);
  }

  public void sort(Comparator comparator) {
    Collections.sort(elements, comparator);
  }

  public ListIterator listIterator() {
    return elements.listIterator();
  }

  public ListIterator listIterator(int index) {
    return elements.listIterator(index);
  }

  public ATLASElement get(int index) {
    return (ATLASElement) elements.get(index);
  }

  public int size() {
    return elements.size();
  }

  public boolean isEmpty() {
    return elements.isEmpty();
  }

  public boolean contains(ATLASElement element) {
    return elements.contains(element);
  }

  public Iterator iterator() {
    return elements.iterator();
  }

  public ATLASElement[] toArray() {
    return (ATLASElement[]) elements.toArray(new ATLASElement[elements.size()]);
  }

  public void clear() {
    elements.clear();
  }

  protected boolean specificAdd(ATLASElement element) {
    return elements.add(element);
  }

  protected boolean specificRemove(ATLASElement element) {
    return elements.remove(element);
  }

  protected abstract void initContainer(int size, ATLASElementSetProperties properties);

  /** The List containing the ATLASElements */
  protected List elements;
}

