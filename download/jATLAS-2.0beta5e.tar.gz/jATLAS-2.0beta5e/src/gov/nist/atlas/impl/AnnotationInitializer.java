/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.Annotation;
import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.type.AnnotationChildrenType;
import gov.nist.atlas.type.AnnotationType;
import gov.nist.atlas.type.ContentType;
import gov.nist.atlas.util.ATLASElementFactory;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.LogManager;

/**
 * @author Christophe Laprun
 * @version $Revision: 1.2 $
 */
public abstract class AnnotationInitializer {
  protected AnnotationInitializer() {
  }

  public static AnnotationInitializer getInitializer(RegionRef region) {
    withRegion.setRegion(region);
    return withRegion;
  }

  public static AnnotationInitializer getInitializer(ATLASElementSet regionDefiningAnnotations, ATLASElementSet contentDefiningAnnotations) {
    withChildren.setChildren(regionDefiningAnnotations, contentDefiningAnnotations);
    return withChildren;
  }

  public static AnnotationInitializer getInitializer(ATLASElementSet regionDefiningAnnotations) {
    withRegionChildren.setRegionChildren(regionDefiningAnnotations);
    return withRegionChildren;
  }

  protected final void setAnnotation(Annotation annotation) {
    this.annotation = annotation;
  }

  abstract void initRegionAndContent();

  protected final void initRegion(RegionRef region) {
    if (region == null)
      throw new IllegalArgumentException("Passing null for RegionRef is NOT supported anymore in Annotation.initWith(). Fix your code! You must pass a valid region for this annotation.");
    annotation.setSubordinateWithRole(region.getElement(), region.getRole());
  }

  protected final void initContent() {
    AnnotationType annotationType = annotation.getAnnotationType();
    ContentType type = annotationType.getTypeForContent();
    ATLASElementFactory factory = ATLASElementFactory.getFactoryFor(annotation.getDefiningCorpus().getATLASImplementation());
    annotation.setSubordinateWithRole(factory.createEmptyContent(type, annotation), annotationType.getRoleForContent());
  }

  protected final void initChildren(ATLASElementSet annotations, AnnotationChildrenType.SubType kind) {
    if (annotations != null && annotations.isEmpty()) // avoids complex work for nothing
      return;
    if (!annotation.addToDefiningChildren(annotations, kind))
      LogManager.log(this, LogManager.WARNING, annotations + " couldn't be added to " + annotation);
  }

  protected Annotation annotation;
  private static final RegionAnnotationInitializer withRegion = new RegionAnnotationInitializer();
  private static final ChildrenAnnotationInitializer withChildren = new ChildrenAnnotationInitializer();
  private static final RegionChildrenAnnotationInitializer withRegionChildren = new RegionChildrenAnnotationInitializer();

  private static class RegionAnnotationInitializer extends AnnotationInitializer {
    RegionAnnotationInitializer() {
    }

    void setRegion(RegionRef region) {
      this.region = region;
    }

    void initRegionAndContent() {
      initRegion(region);
      initContent();
    }

    RegionRef region;
  }


  private static class ChildrenAnnotationInitializer extends AnnotationInitializer {
    ChildrenAnnotationInitializer() {
    }

    void setChildren(ATLASElementSet regionDefiningAnnotations, ATLASElementSet contentDefiningAnnotations) {
      // FIX-ME : test if params are null and throw exception ?
      this.regionDefiningAnnotations = regionDefiningAnnotations;
      this.contentDefiningAnnotations = contentDefiningAnnotations;
    }


    void initRegionAndContent() {
//      if (regionDefiningAnnotations != null) { // FIX-ME this screams SPI!
      initChildren(regionDefiningAnnotations, AnnotationChildrenType.REGION_DEFINING);
      annotation.replaceRegionByChildrenRegion();
//      }
      // if both sets are identical, it's useless to try to add the children again
      if (regionDefiningAnnotations != contentDefiningAnnotations)
        initChildren(contentDefiningAnnotations, AnnotationChildrenType.CONTENT_DEFINING);
      annotation.replaceContentByChildrenContent();
    }

    ATLASElementSet regionDefiningAnnotations;
    ATLASElementSet contentDefiningAnnotations;
  }


  private static class RegionChildrenAnnotationInitializer extends AnnotationInitializer {
    RegionChildrenAnnotationInitializer() {
    }

    void setRegionChildren(ATLASElementSet regionDefiningAnnotations) {
      /*if (regionDefiningAnnotations == null)   // FIX-ME this screams SPI!
        System.err.println("RegionChildrenAnnotationInitializer.setRegionChildren called without a valid set of children Annotations.");*/
      this.regionDefiningAnnotations = regionDefiningAnnotations;
    }

    void initRegionAndContent() {
      if (regionDefiningAnnotations != null) {
        initChildren(regionDefiningAnnotations, AnnotationChildrenType.REGION_DEFINING);
        annotation.replaceRegionByChildrenRegion();
      }
      initContent();
    }

    ATLASElementSet regionDefiningAnnotations;

  }
}