/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Analysis;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.Id;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.AnalysisType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.MapATLASElementSet;

import java.util.Iterator;


/**
 * @version $Revision: 1.2 $
 * @author Christophe Laprun, Sylvain Pajot
 */
public class AnalysisImpl extends ATLASMetadataHolder implements Analysis {
  protected AnalysisImpl(ATLASType type, ATLASElement parent, Id id, ImplementationDelegate delegate) {
    super(type, parent, id, delegate);
  }

  public final AnalysisType getAnalysisType() {
    return (AnalysisType) getATLASType();
  }

  public final boolean isTypeValid(ATLASType type) {
    return super.isTypeValid(type) && (type instanceof AnalysisType);
  }

  public void toAIFBuffer(StringBuffer sb, String indent, String role, ATLASElement context) {
    if (sb == null) {
      throw new IllegalArgumentException("toAIFBuffer (Analysis) requires non-null StringBuffer");
    }
    if (role == null) {
      throw new IllegalArgumentException("toAIFBuffer (Analysis) requires non-null role");
    }

    sb.append(indent).append(AIFExportConstants.ANALYSIS_S)
        .append(getId().getAsString()).append(AIFExportConstants.TYPE_ATT)
        .append(getATLASType().getName()).append(AIFExportConstants.ROLE_ATT)
        .append(role).append(AIFExportConstants.CLOSE);

    subordinateSetsToAIFBuffer(sb, newIndent(indent), context);

    sb.append(indent).append(AIFExportConstants.ANALYSIS_E);
  }

  public boolean addAnnotations(ATLASElementSet annotationsToAdd) {
    // we can do this because annotations uses a redefined version of
    // isElementOK
    if (!annotations.addAll(annotationsToAdd))
      return false;
    // at this point, we know that all elements are safe to be added so we could
    // maybe optimize...
    Iterator i = annotations.iterator();
    while (i.hasNext())
      addAnnotation((Annotation) i.next());
    return true;
  }

  public Annotation getAnnotationWithId(String id) {
    return (Annotation) annotations.get(getDefiningCorpus().resolveIdFor(id));
  }

  public boolean containsAnnotationWithId(String stringId) {
    return annotations.contains(getDefiningCorpus().resolveIdFor(stringId));
  }

  public ATLASElementSet getAllAnnotations() {
    return getAllChildrenWith(ATLASClass.ANNOTATION);
  }

  public boolean addAnnotation(Annotation annotation) {
    if (annotations.contains(annotation))
      return false;
    boolean added = addToSubordinateSet(annotation);
    if (added)
      annotations.add(annotation);
    return added;
  }

  public ATLASElementSet getAnnotationsWithType(String strType) {
    ATLASType type = getDefiningCorpus().resolveTypeFor(ATLASClass.ANNOTATION, strType);
    return getAllChildrenWith(type);
  }

  public boolean removeAnnotation(Annotation annotation) {
    if (!annotations.contains(annotation))
      return false;
    boolean removed = removeFromSubordinateSet(annotation);
    if (removed)
      annotations.remove(annotation);
    return removed;
  }

  /**
   * allows fast access to annotations by Id. We redefine the isElementOK
   * method to adapt it to the specific need here. We need to be able to check
   * if the element is of appropriate with respect to this Analysis' type for
   * addAnnotations.
   */
  private MapATLASElementSet annotations = new MapATLASElementSet(ATLASClass.ANNOTATION, 87) {
    protected boolean isElementOK(ATLASElement element) {
      return super.isElementOK(element) && getATLASType().canAddToSubordinateSet(element);
    }
  };
}


