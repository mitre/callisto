/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl.bundled;

import gov.nist.atlas.ATLASAccessException;
import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Children;
import gov.nist.atlas.impl.MinimalImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.ATLASElementSetFactory;
import gov.nist.atlas.util.ATLASElementSetProperties;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.MutableATLASElementSet;

import java.util.Iterator;

public class DefaultImplementationDelegate extends MinimalImplementationDelegate {
  public DefaultImplementationDelegate(ATLASType type, ATLASImplementation implementation) {
    super(type, implementation);

    // perform implementation specific initialization
    requiredChildren = new ATLASElement[type.getSubordinateNumber()];
    optionalChildrenSets = new MutableATLASElementSet[type.getSubordinateSetNumber()];

    // initialization of the container elements
    Iterator types = type.getContainedTypesInSubordinateSets();
    while (types.hasNext()) {
      ATLASType containedType = (ATLASType) types.next();
      int i = typeAsImpl().getIndexForMultiple(containedType);
      optionalChildrenSets[i] = type.createSubordinateSetFor(containedType); // FIX-ME
    }
  }

  public boolean specificAddToSubordinate(ATLASElement subordinate) throws ATLASAccessException {
    return getSubordinateSet(subordinate.getATLASType()).add(subordinate);
  }

  public boolean specificRemoveFromSubordinateSet(ATLASElement subordinate) throws ATLASAccessException {
    return getSubordinateSet(subordinate.getATLASType()).remove(subordinate);
  }

  public MutableATLASElementSet getSubordinateSet(ATLASType containedSubordinateType) throws ATLASAccessException {
    try {
      return optionalChildrenSets[typeAsImpl().getIndexForMultiple(containedSubordinateType)];
    } catch (Exception e) {
      throw new ATLASAccessException("There is no subordinate set containining " + containedSubordinateType, e);
    }
  }

  public ATLASElement getSubordinateWithRole(String role) {
    return getElementAt(typeAsImpl().getIndexForRequired(role));
  }

  public ATLASElementSet getAllChildrenWith(ATLASClass clazz) {
    ATLASElementSet multiplElements = getAllSubordinatesFromSubordinateSetsWith(clazz);
    int fs = requiredChildren.length;
    int ms = multiplElements.size();
    MutableATLASElementSet result =
        ATLASElementSetFactory.getFactoryFor(getATLASImplementation())
        .createMutableATLASElementSet(clazz, fs + ms,
            ATLASElementSetProperties.SAME_AS_GROWABLE_ARRAY);
    // addition is not performed if elements are not of the right ATLASClass!
    for (int i = 0; i < fs; i++)
      result.add(requiredChildren[i]);
    result.addAll(multiplElements);
    return result;
  }

  // FIX-ME
  public ATLASElementSet getAllChildrenWith(ATLASType type) {
    for (int i = 0; i < optionalChildrenSets.length; i++) {
      MutableATLASElementSet multipleElement = optionalChildrenSets[i];
      if (multipleElement.getComponentATLASType().equals(type))
        return multipleElement;
    }
    return super.getAllChildrenWith(type);
  }

  public boolean specificAddToChildrenWithRole(ATLASElement element, String role) {
    ATLASElement potentialChildren = getSubordinateWithRole(role);
    if (potentialChildren instanceof Children) {
      Children children = (Children) potentialChildren;
      return children.addToSubordinateSet(element);
    }
    throw new ATLASAccessException("There is no Children with role " + role + " in this " + this);
  }

  public boolean specificAddUnnamedSubordinate(ATLASElement newSubordinate) {
    MutableATLASElementSet set = getSetFor(newSubordinate.getATLASType());
    if (set == null)
      return false;
    return set.add(newSubordinate);
  }

  public boolean specificRemoveFromChildrenWithRole(ATLASElement element, String role) {
    ATLASElement potentialChildren = getSubordinateWithRole(role);
    if (potentialChildren instanceof Children) {
      Children children = (Children) potentialChildren;
      return children.removeFromSubordinateSet(element);
    }
    throw new ATLASAccessException("There is no Children with role " + role + " in this " + this);
  }

  public boolean specificSetSubordinateWithRole(ATLASElement element, String role) {
    int index = typeAsImpl().getIndexForRequired(role);
    ATLASElement ae = getElementAt(index);
    if (ae != null && ae.equals(element))
      return false;
    requiredChildren[index] = element;
    return true;
  }

  public ATLASElementSet getAllSubordinatesFromSubordinateSetsWith(ATLASClass atlasClass) {
    int ms = optionalChildrenSets.length;
    MutableATLASElementSet result =
        ATLASElementSetFactory.getFactoryFor(getATLASImplementation())
        .createMutableATLASElementSet(atlasClass, 0, ATLASElementSetProperties.SAME_AS_LINKED_LIST);
    for (int i = 0; i < ms; i++) {
      result.addAll(optionalChildrenSets[i]);
    }
    return result;
  }

  private DefaultTypeImplementationDelegate typeAsImpl() {
    return (DefaultTypeImplementationDelegate) typeDelegate;
  }

  private ATLASElement getElementAt(int index) {
    try {
      return requiredChildren[index]; // NEEDS INITIALIZATION????
    } catch (Exception e) {
      return null;
    }
  }

  /**
   * Returns the subordinate set containing elements with the given type.
   *
   * @param type the type of the contained ATLASElements
   *
   * @return the internal ATLASElementSet containing elements of the given type
   */
  private final MutableATLASElementSet getSetFor(ATLASType type) {
    return optionalChildrenSets[typeAsImpl().getIndexForMultiple(type)];
  }

  private ATLASElement[] requiredChildren;
  private MutableATLASElementSet[] optionalChildrenSets;
}
