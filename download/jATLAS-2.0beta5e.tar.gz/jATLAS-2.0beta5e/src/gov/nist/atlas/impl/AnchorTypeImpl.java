/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Signal;
import gov.nist.atlas.spi.TypeImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.AbstractATLASType;
import gov.nist.atlas.type.AnchorSpecificExtension;
import gov.nist.atlas.type.AnchorType;
import gov.nist.atlas.type.SignalType;
import gov.nist.atlas.util.RoleIdentifiedParameter;
import gov.nist.maia.MAIAScheme;

/**
 * @author Christophe Laprun
 * @version $Revision: 1.2 $
 */
public class AnchorTypeImpl extends AbstractATLASType implements AnchorType {
  public AnchorTypeImpl(ATLASType superType, String name, MAIAScheme scheme, TypeImplementationDelegate delegate) {
    super(superType, name, scheme, delegate);
  }

  public ATLASClass getATLASClass() {
    return ATLASClass.ANCHOR;
  }

  public boolean isParentValid(ATLASElement parent) {
    return parent instanceof Corpus;
  }

  public SignalType getSignalType() {
//    return extension.getSignalType();
    return (SignalType) getTypeOfSubordinateWith(getRoleForSignal());
  }

  public boolean setSignalType(SignalType signalType) {
    return extension.setSignalType(signalType);
  }

  public String getRoleForSignal() {
    return (String) getRolesForRequiredChildrenWith(ATLASClass.SIGNAL).get(0);
  }

  // put this in AnchorSpecificExtension?
  public void checkInitParameters(Signal signal, RoleIdentifiedParameter[] parameters, boolean withDefaults) {
//    System.out.println("signal.getATLASType().getName() = " + signal.getATLASType().getName());
//    System.out.println("getSignalType().getName() = " + getSignalType().getName());
    if (signal == null || !signal.getATLASType().equals(getSignalType()))
      throw new IllegalArgumentException(
          new StringBuffer("Error: invalid signal for Anchors of type '").
          append(getName()).append("'. Expected type was: '").
          append(getSignalType().getName()).append("'. Given signal was: ").
          append(signal.getSignalType().getName()).toString());

    if (!withDefaults) {
      checkNumber(ATLASClass.PARAMETER, parameters);
      checkRoles(parameters);
    }
  }

  private AnchorSpecificExtension extension = new AnchorSpecificExtension(this);
}



