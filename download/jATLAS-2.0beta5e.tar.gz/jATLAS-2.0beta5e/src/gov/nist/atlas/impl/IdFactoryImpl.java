/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.Id;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.IdFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public class IdFactoryImpl extends IdFactory {
  public IdFactoryImpl() {
    List idClasses = ATLASClass.getIdentifiableClasses();
    int length = idClasses.size();
    // to prevent Map size == even number
    int adjusted = (length % 2 == 0) ? length + 1 : length;
    class2Infos = new HashMap(adjusted);
    prefix2Class = new HashMap(adjusted);
    ATLASClass c = null;
    String prefix = null;
    for (int i = 0; i < length; i++) {
      c = (ATLASClass) idClasses.get(i);
      prefix = createPrefixFor(c.getName());
      class2Infos.put(c, new IdInfo(0, prefix));
      prefix2Class.put(prefix, c);
    }
    idClasses = null;
  }

  private String getPrefixFor(String stringId) {
    MATCHER.reset(stringId);
    if (MATCHER.matches())
      return MATCHER.group(1);
    return null;
  }

  private String createPrefixFor(String className) {
    return className.substring(0, 3);
  }

  protected Id createNewIdFor(ATLASType type) {
    ATLASClass clazz = type.getATLASClass();
    IdInfo info = null;
    if (class2Infos.containsKey(clazz)) {
      info = (IdInfo) class2Infos.get(clazz);
      info.counter++;
      return createNewIdFor(info.toString());
    }
    return createNewIdFor(DEFAULT_PREFIX + defaultCounter);
  }

  protected Id createNewIdFor(String stringId) {
    Id id = resolveIdFor(stringId);
    updateIdInfoIfNeeded(stringId);
    if (id == null) {
      id = new IdImpl(stringId);
      addId(id);
    }
    return id;
  }

  private boolean updateIdInfoIfNeeded(String stringId) {
    String prefix = getPrefixFor(stringId);
    IdInfo info = (IdInfo) class2Infos.get(getATLASClassFor(prefix));
    if (info == null)
      return false;
    int suffix = Integer.parseInt(stringId.substring(PREFIX_LENGTH));
    int max = Math.max(info.counter, suffix);
    info.counter = max++;
    return true;
  }

  private ATLASClass getATLASClassFor(String prefix) {
    return (ATLASClass) prefix2Class.get(prefix);
  }

  private Map class2Infos;
  private Map prefix2Class;
  private static final String DEFAULT_PREFIX = "DEF";
  private static int defaultCounter = 1;
  private static int PREFIX_LENGTH = 3;
  private final static Pattern ATLAS_ID_PATTERN = Pattern.compile("^(\\w{3})\\d*");
  private final static Matcher MATCHER = ATLAS_ID_PATTERN.matcher("");

  private static class IdInfo {
    IdInfo(int counter, String prefix) {
      this.counter = counter;
      this.prefix = prefix;
    }

    /**
     * Two IdInfo are equal if their prefix are are equal.
     */
    public boolean equals(Object other) {
      if (other == this)
        return true;
      return ((IdInfo) other).prefix.equals(prefix);
    }

    public String toString() {
      return prefix + counter;
    }

    public int setCounter(int newValue) {
      int old = counter;
      counter = newValue;
      return old;
    }

    private String prefix;
    private int counter;
  }
}