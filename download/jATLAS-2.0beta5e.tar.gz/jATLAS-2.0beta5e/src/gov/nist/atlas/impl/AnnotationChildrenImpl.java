/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.AnnotationChildren;
import gov.nist.atlas.Content;
import gov.nist.atlas.Region;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASElementSet;


/**
 * @version $Revision: 1.2 $
 * @author Sylvain Pajot, Christophe Laprun, Nicolas Radde
 */
public class AnnotationChildrenImpl extends ChildrenImpl implements AnnotationChildren {

  protected AnnotationChildrenImpl(ATLASType type, ATLASElement parent, ImplementationDelegate delegate) {
    super(type, parent, delegate);
  }

  public Region getDefinedRegion() {
    throw new UnsupportedOperationException("Children.getDefinedRegion: NOT YET IMPLEMENTED");
  }

  public Content getDefinedContent() {
    throw new UnsupportedOperationException("Children.getDefinedContent: NOT YET IMPLEMENTED");
  }

  public boolean addAnnotations(ATLASElementSet annotations) {
    return addToSubordinateSet(annotations, ATLASClass.ANNOTATION);
  }

  public ATLASElementSet getAllAnnotations() {
    return getContainedElements();
  }

  public boolean addAnnotation(Annotation annotation) {
    return addToSubordinateSet(annotation);
  }

  public ATLASElementSet getAnnotationsWithType(String strType) {
    ATLASType containedType = getContainedElementsType();
    if (containedType.equals(containedType.getMAIAScheme().getAnnotationType(strType)))
      return getSubordinateSet(containedType);
    return null; // FIX-ME
  }

  public boolean removeAnnotation(Annotation annotation) {
    return removeFromSubordinateSet(annotation);
  }
}