/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.*;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.CorpusType;
import gov.nist.atlas.util.ATLASElementFactory;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.ATLASElementSetFactory;
import gov.nist.atlas.util.ATLASElementSetProperties;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.MutableATLASElementSet;
import gov.nist.maia.MAIAScheme;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


/**
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public class CorpusImpl extends ATLASMetadataHolder implements Corpus {
  protected CorpusImpl(ATLASType type, Id id, ImplementationDelegate delegate, URL location) {
    super(type, null, id, delegate);
    initLocation(location);
  }

  private final void initLocation(URL location) {
    if (location != null)
      this.location = location;
    else
      try {
        this.location = new URL("inmem", "localhost", 8080, "/" + getId().getAsString());
      } catch (MalformedURLException e) {
        // should never happen
        e.printStackTrace(System.err);
      }
  }

  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj instanceof Corpus) {
      Corpus corpus = (Corpus) obj;
      return getId().equals(corpus.getId()) && location.equals(corpus.getLocation());
    }
    return false;
  }

  public MAIAScheme getMAIAScheme() {
    return getCorpusType().getMAIAScheme();
  }

  public boolean isShallow() {
    return shallow;
  }

  public boolean setShallow(boolean shallow) {
    boolean old = this.shallow;
    this.shallow = shallow;
    return old;
  }

  public final URL getLocation() {
    return location;
  }

  public final CorpusType getCorpusType() {
    return (CorpusType) getATLASType();
  }

  public final boolean isTypeValid(ATLASType type) {
    return super.isTypeValid(type) && (type instanceof CorpusType);
  }

  public Corpus getDefiningCorpus() {
    return this;
  }

  public final String getAIFVersion() {
    return getATLASImplementation().getAIFVersion();
  }

  public void setLocation(URL location) {
    if (location == null)
      throw new IllegalArgumentException("setLocation cannot be called with a null location!");
    CorporaManager.updateLocationFor(this, location);
    this.location = location;
  }

  public ATLASType resolveTypeFor(ATLASClass aClass, String typeName) {
    return getMAIAScheme().getATLASType(aClass, typeName);
  }

  public Id resolveIdFor(String stringId) {
    return getElementFactory().resolveIdFor(stringId);
  }

  private final ATLASElementFactory getElementFactory() {
    return ATLASElementFactory.getFactoryFor(getATLASImplementation());
  }

  public ATLASImplementation getATLASImplementation() {
    return delegate.getATLASImplementation();
  }

  public boolean setSignalWithRole(Signal signal, String role) {
    throw new UnsupportedOperationException("Not currently supported!");
//    return setSubordinateWithRole(signal, role); // FIX-ME: do something to manage Id?
  }

  public Signal getSignalWithRole(String role) {
    throw new UnsupportedOperationException("Not currently supported!");
//    return (Signal) getSubordinateWithRole(role);
  }

  public boolean setAnalysisWithRole(Analysis analysis, String role) {
    return setSubordinateWithRole(analysis, role);
  }

  public Analysis getAnalysisWithRole(String role) {
    return (Analysis) getSubordinateWithRole(role);
  }

  public Analysis getAnalysisWithId(String id) {
    Iterator i = getAllAnalyses().iterator();
    Analysis analysis;
    while (i.hasNext()) {
      analysis = (Analysis) i.next();
      if (id.equals(analysis.getId().getAsString())) return analysis;
    }
    return null;
  }

  public ATLASElementSet getAllAnalyses() {
    return getAllChildrenWith(ATLASClass.ANALYSIS);
  }

  public Anchor getAnchorWithId(String id) {
    return (Anchor) getReusableElementWith(ATLASClass.ANCHOR, id);
  }

  public ATLASElementSet getAllAnchors() {
    return getAllSubordinatesInSubordinateSetsWith(ATLASClass.ANCHOR);
  }

  public Annotation getAnnotationWithId(String id) {
    Iterator analyses = getAllAnalyses().iterator();
    Analysis analysis = null;
    Annotation annotation = null;
    while (analyses.hasNext()) {
      analysis = (Analysis) analyses.next();
      annotation = analysis.getAnnotationWithId(id);
      if (annotation != null)
        return annotation;
      continue;
    }
    /*if(annotation == null)
      annotation = (Annotation) getFromRefNow(ATLASClass.ANNOTATION, id);*/
    return annotation;
  }

  public ATLASElementSet getAllAnnotations() {
    Iterator analyses = getAllAnalyses().iterator();
    ATLASElementSetFactory factory = ATLASElementSetFactory.getFactoryFor(getATLASImplementation());
    MutableATLASElementSet annotations =
        factory.createMutableATLASElementSet(ATLASClass.ANNOTATION, 257, ATLASElementSetProperties.SAME_AS_LINKED_LIST);
    while (analyses.hasNext()) {
      annotations.addAll(((Analysis) analyses.next()).getAllAnnotations());
    }
    return annotations;
  }

  public Region getRegionWithId(String id) {
    return (Region) getReusableElementWith(ATLASClass.REGION, id);
  }

  public ATLASElementSet getAllRegions() {
    return getAllSubordinatesInSubordinateSetsWith(ATLASClass.REGION);
  }

  public boolean addAnchor(Anchor anchor) {
    return addToSubordinateSet(anchor);
  }

  public boolean removeAnchor(Anchor anchor) {
    return removeFromSubordinateSet(anchor);
  }

  public boolean addRegion(Region region) {
    return addToSubordinateSet(region);
  }

  public boolean removeRegion(Region region) {
    return removeFromSubordinateSet(region);
  }

  public boolean addSignal(Signal signal) {
    String strId = (signal != null) ? signal.getId().getAsString() : null;
    if (signals.containsKey(strId))
      return false; // signal already present: what should we do??
    if (getCorpusType().canAddSignal(signal)) {
      signals.put(strId, signal);
      return true;
    }
    return false;
//    return addToSubordinateSet(signal); // FIX-ME: do this eventually!
  }

  public boolean removeSignal(Signal signal) {
    String strId = (signal != null) ? signal.getId().getAsString() : null;
    if (!signals.containsKey(strId))
      return false; // signal is not contained in this Corpus
    signals.remove(strId);
    return true;
//    return removeFromSubordinateSet(signal); // FIX-ME: do this eventually!
  }

  public Signal getSignalWithId(String id) {
    return (Signal) signals.get(id);
//    return (Signal) getReusableElementWith(ATLASClass.SIGNAL, id);  // FIX-ME: do this eventually!
  }

  public ATLASElementSet getAllSignals() {
//    return getAllChildrenWith(ATLASClass.SIGNAL); // FIX-ME: do this eventually!
    return ATLASElementSetFactory.getFactoryFor(getATLASImplementation())
        .createATLASElementSetFrom(ATLASClass.SIGNAL, signals.values(),
            ATLASElementSetProperties.FAST_ID_ACCESS_UNSORTABLE);
  }

  public ATLASElementSet getNonValidatedElements() {
    return null; // FIX-ME
  }

  public void toAIFBuffer(StringBuffer sb, String indent, String role, ATLASElement context) {
    sb.append(AIFExportConstants.CORPUS_S).append(getId().getAsString())
        .append(AIFExportConstants.AIFVERSION_ATT)
        .append(getAIFVersion()).append(AIFExportConstants.TYPE_ATT)
        .append(getATLASType().getName())
        .append(AIFExportConstants.SCHEMELOC_ATT)
        .append(getCorpusType().getMAIAScheme().getLocation())
        .append(AIFExportConstants.NAMESPACE_INFO);

    String newIndent = newIndent(indent);

    Metadata metadata = getMetadata();
    if (metadata != null)
      metadata.toAIFBuffer(sb, newIndent, ATLASType.NULL_ROLE, this);
    else
      sb.append(indent).append(AIFExportConstants.EMPTY_METADATA); // FIX-ME

    Iterator i = signals.values().iterator();
    Signal signal = null;
    while (i.hasNext()) {
      signal = (Signal) i.next();
      signal.toAIFBuffer(sb, newIndent, ATLASType.NULL_ROLE, this);
    }

    sb.append(AIFExportConstants.BR);

    subordinateSetsToAIFBuffer(sb, newIndent, this);

    subordinatesToAIFBuffer(sb, newIndent, this);

    sb.append(AIFExportConstants.CORPUS_E);
  }

  protected StringBuffer initBuffer() {
    return new StringBuffer(10000);
  }

  public boolean containsReusableElementWith(String stringId) {
    // A ReusableATLASElement is an IdentifiableATLASElement that is NOT an Analysis...
    return containsIdentifiableElementWith(stringId) && getAnalysisWithId(stringId) == null;
  }

  public final boolean containsReusableElementWith(ATLASClass aClass, String stringId) {
    if(!containsReusableElementWith(stringId))
      return false;

    if (aClass != null && aClass.isReusable()) {
      if (ATLASClass.ANNOTATION.equals(aClass)) {
        Iterator i = getAllAnalyses().iterator();
        while (i.hasNext()) {
          Analysis analysis = (Analysis) i.next();
          if (analysis.containsAnnotationWithId(stringId))
            return true;
        }
        return false;
      }
      if (ATLASClass.SIGNAL.equals(aClass))
        return signals.containsKey(stringId);
      return (elements.containsKey(stringId)
          && ((ATLASElement) elements.get(stringId)).getATLASClass().equals(aClass));
    }
    return false;
  }

  public final ReusableATLASElement getReusableElementWith(ATLASClass aClass, String stringId) {
    if (aClass != null && aClass.isReusable()) {
      if (ATLASClass.SIGNAL.equals(aClass))
        return getSignalWithId(stringId);
      if (ATLASClass.ANNOTATION.equals(aClass))
        return getAnnotationWithId(stringId);
      ReusableATLASElement element = (ReusableATLASElement) elements.get(stringId);
      return (element != null &&
          element.getATLASType().getATLASClass().equals(aClass)) ? element : null;
    }
    throw new IllegalArgumentException(aClass + " is not a reusable ATLASClass!");
  }

  public final ReusableATLASElement getReusableElementWith(String stringId) {
    if(!containsReusableElementWith(stringId))
      return null;
    Iterator reusableClasses = ATLASClass.getReusableClasses().iterator();
    while (reusableClasses.hasNext()) {
      ReusableATLASElement result = getReusableElementWith((ATLASClass) reusableClasses.next(), stringId);
      if(result != null)
        return result;
    }
    return null;
  }

  public final boolean containsIdentifiableElementWith(String stringId) {
    return resolveIdFor(stringId) != null;
  }

  public final IdentifiableATLASElement getIdentifiableElementWith(ATLASClass aClass, String stringId) {
    if(ATLASClass.ANALYSIS.equals(aClass))
      return getAnalysisWithId(stringId);
    return getReusableElementWith(aClass, stringId);
  }

  public final IdentifiableATLASElement getIdentifiableElementWith(String stringId) {
    // First check that an ATLASElement with the given ID exists within the corpus
    if (!containsIdentifiableElementWith(stringId))
      return null;

    // Then try to get the element as an Analysis
    IdentifiableATLASElement element = getAnalysisWithId(stringId);

    // If getAnalysisWithId returns null, try to get the element as a ReusableATLASElement
    if(element == null)
      element = getReusableElementWith(stringId);

    return element;
  }

  public boolean addToSubordinateSet(ATLASElement subordinate) throws ATLASAccessException {
    if (super.addToSubordinateSet(subordinate) && (subordinate instanceof IdentifiableATLASElement)) {
      elements.put(((IdentifiableATLASElement) subordinate).getId().getAsString(), subordinate);
      return true;
    }
    return false;
  }

  public boolean removeFromSubordinateSet(ATLASElement subordinate) throws ATLASAccessException {
    if (super.removeFromSubordinateSet(subordinate) && (subordinate instanceof IdentifiableATLASElement)) {
      elements.remove(((IdentifiableATLASElement) subordinate).getId().getAsString());
      return true;
    }
    return false;
  }

  /**
   *  Maybe should use the Strategy pattern to make the code cleaner and share
   * it with signal operations??? (for add and remove, below)
   */
  /*private final boolean add(ReusableATLASElement element, ATLASClass clazz) {
    String strId = prepareOperation(element, clazz);
    if (strId == null) {
      System.err.println("Couldn't add: " + element);
      return false; // element already present: what should we do??
    }
    elements.put(strId, element);
    addToSubordinateSet(element);
    return true;
  }

  private final boolean remove(ReusableATLASElement element, ATLASClass clazz) {
    String strId = prepareOperation(element, clazz);
    if (strId == null)
      return false; // element different than the one we want to remove: what should we do??
    elements.remove(strId);
    removeFromSubordinateSet(element);
    return true;
  }

  private final String prepareOperation(IdentifiableATLASElement element, ATLASClass clazz) {
    if (element == null)
      return null;
    String strId = element.getId().getAsString();
    Object o = getReusableElementWith(clazz, strId);
    if (o != null && o != element) {
      o = null;
      strId = null;
    }
    return strId;
  }*/

  private Map elements = new HashMap();
  private Map signals = new HashMap();
//  private ATLASImplementation implementation;
  private URL location;
  private boolean shallow = false;
}