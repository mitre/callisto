/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Anchor;
import gov.nist.atlas.Id;
import gov.nist.atlas.Parameter;
import gov.nist.atlas.Region;
import gov.nist.atlas.Signal;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.ref.SignalRef;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.AnchorType;
import gov.nist.atlas.util.ATLASElementSet;
import gov.nist.atlas.util.RoleIdentifiedParameter;


/**
 * @version $Revision: 1.2 $
 * @author Sylvain Pajot, Christophe Laprun
 */
public class AnchorImpl extends ReusableATLASElementImpl implements Anchor {
  protected AnchorImpl(ATLASType type, ATLASElement parent, Id id, ImplementationDelegate delegate, SignalRef signal) {
    super(type, parent, id, delegate);
    setSubordinateWithRole(signal, signal.getRole()); // do this ultimately!!
    // add this anchor to the parent corpus
    getDefiningCorpus().addAnchor(this); // do something
  }

  public void initContainedElementsWith(RoleIdentifiedParameter[] parameters) {
    // temporary variables for parameters addition
    int numberOfParameters = parameters.length;
    RoleIdentifiedParameter iteParameter;
    String iteRole;
    // parameters addition
    for (int i = 0; i < numberOfParameters; i++) {
      iteParameter = parameters[i];
      iteRole = iteParameter.getRole();
      setSubordinateWithRole(iteParameter.getElement(), iteRole);
    }

  }

  public final AnchorType getAnchorType() {
    return (AnchorType) getATLASType();
  }

  public final boolean isTypeValid(ATLASType type) {
    return super.isTypeValid(type) && (type instanceof AnchorType);
  }

  public Signal getSignal() {
    return (Signal) (((SignalRef) getSubordinateWithRole(getAnchorType().getRoleForSignal())).getElement());
    // FIX-ME: do something about role
//    return (Signal) getSubordinateWithRole(getAnchorType().getRoleForSignal()); // FIX-ME: do something about role
  }

  public boolean setValueOfParameterWithRole(String value, String role) {
    return getParameterWithRole(role).setValue(value);
  }

  public String getStringValueOfParameterWithRole(String role) {
    return getParameterWithRole(role).getValueAsString();
  }

  public Object getObjectValueOfParameterWithRole(String role) {
    return getParameterWithRole(role).getValueAsObject();
  }

  public ATLASElementSet getAllParameters() {
    return getAllChildrenWith(ATLASClass.PARAMETER);
  }

  public Parameter getParameterWithRole(String role) {
    return (Parameter) getSubordinateWithRole(role);
  }

  public void toAIFBuffer(StringBuffer sb, String indent, String role, ATLASElement context) {
    if (context instanceof Region) {
      toAIFBufferAsRef(sb, indent, role, context);
      return;
    }

    sb.append(indent).append(AIFExportConstants.ANCHOR_S)
        .append(getId().getAsString()).append(AIFExportConstants.TYPE_ATT)
        .append(getATLASType().getName()).append(AIFExportConstants.CLOSE);

    subordinatesToAIFBuffer(sb, newIndent(indent), this);

    sb.append(indent).append(AIFExportConstants.ANCHOR_E);
  }
}


