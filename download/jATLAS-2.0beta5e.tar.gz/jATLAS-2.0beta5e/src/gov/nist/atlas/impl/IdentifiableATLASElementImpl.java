/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Id;
import gov.nist.atlas.IdentifiableATLASElement;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;


/**
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public class IdentifiableATLASElementImpl extends ATLASElementImpl implements IdentifiableATLASElement {
  protected IdentifiableATLASElementImpl(ATLASType type, ATLASElement parent, Id id, ImplementationDelegate delegate) {
    initWith(type, parent, id, delegate);
  }

  protected void initWith(ATLASType type, ATLASElement parent, Id id, ImplementationDelegate delegate) {
    initId(id);
    super.initWith(type, parent, delegate);
  }

  private final void initId(Id id) {
    if (id != null)
      this.id = id;
    else
      this.id = new IdFactoryImpl().createNewIdFor(getATLASType()); // FIX-ME?
  }

  public boolean equals(Object obj) {
    if (obj == this)
      return true;
    if (obj instanceof IdentifiableATLASElement) {
      IdentifiableATLASElement element = (IdentifiableATLASElement) obj;
      return id.equals(element.getId())
          && getDefiningCorpus().equals(element.getDefiningCorpus());
    }
    return false;
  }

  public final Id getId() {
    return id;
  }

  public String toString() {
    return super.toString() + ID + id.getAsString();
  }

  private Id id;
  private final static String ID = " id=";
}



