/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASAccessException;
import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Analysis;
import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.spi.TypeImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.AbstractATLASType;
import gov.nist.atlas.type.AnnotationChildrenType;
import gov.nist.atlas.type.AnnotationType;
import gov.nist.atlas.type.ContentType;
import gov.nist.atlas.type.RegionType;
import gov.nist.maia.MAIAScheme;

/**
 * FIX-ME: remove dependency on ATMultipleKey
 *
 * @author Christophe Laprun
 * @version $Revision: 1.2 $
 */
public class AnnotationTypeImpl extends AbstractATLASType implements AnnotationType {
  public AnnotationTypeImpl(ATLASType superType, String name, MAIAScheme scheme, TypeImplementationDelegate delegate) {
    super(superType, name, scheme, delegate);
  }

  public ATLASClass getATLASClass() {
    return ATLASClass.ANNOTATION;
  }

  public boolean isParentValid(ATLASElement parent) {
    return parent instanceof Analysis;
  }

  public String getRoleForRegion() {
    return (String) getRolesForRequiredChildrenWith(ATLASClass.REGION).get(0); // FIX-ME: set role with MAIA?
  }

  public String getRoleForContent() {
    return (String) getRolesForRequiredChildrenWith(ATLASClass.CONTENT).get(0); // FIX-ME: set role with MAIA?
  }

  public ContentType getTypeForContent() {
    return (ContentType) getTypeOfSubordinateWith(getRoleForContent());
  }

  public RegionType getTypeForRegion() {
    return (RegionType) getTypeOfSubordinateWith(getRoleForRegion());
  }

  public void checkInitParameters(RegionRef region) {

    /*if(contentIsDefinedByChildren && !canContentBeDefinedByChildren())
      throw new IllegalArgumentException(
        "Content cannot be defined by Children for this Annotation type: "
        + getName());

    if(regionIsDefinedByChildren && !canRegionBeDefinedByChildren())
      throw new IllegalArgumentException(
        "Region cannot be defined by Children for this Annotation type: "
        + getName());*/

    if (!canRegionBeDefinedByChildren()) {
      if (region == null || !region.getATLASType().equals(getTypeOfSubordinateWith(region.getRole()))) // FIX-ME:
      // how to deal with role?
        throw new IllegalArgumentException("The given Region is not valid for this Annotation type! Given region: " + region);
    }

  }

  public boolean canRegionBeDefinedByChildren() {
    return roleForRegionDefiningChildren != NOT_CHILDREN_DEFINED;
  }

  public boolean canContentBeDefinedByChildren() {
    return roleForContentDefiningChildren != NOT_CHILDREN_DEFINED;
  }

  public boolean canBeDefinedByChildren(AnnotationChildrenType.SubType kind) {
    return (kind == AnnotationChildrenType.CONTENT_DEFINING) ?
        canContentBeDefinedByChildren() : canRegionBeDefinedByChildren();
  }

  public void setContentDefiningChildren(ContentType definedContentType, String childrenRole) {
    roleForContentDefiningChildren = childrenRole; // FIX-ME: do something with definedContentType
  }

  public void setRegionDefiningChildren(RegionType definedRegionType, String childrenRole) {
    roleForRegionDefiningChildren = childrenRole; // FIX-ME: do something with definedRegionType
  }

  public String getRoleForRegionDefiningChildren() {
    return getRoleForChildrenWith(AnnotationChildrenType.REGION_DEFINING);
  }

  public String getRoleForContentDefiningChildren() {
    return getRoleForChildrenWith(AnnotationChildrenType.CONTENT_DEFINING);
  }

  public AnnotationChildrenType getTypeOfAnnotationChildrenWithRole(String role) {
    return (AnnotationChildrenType) getTypeOfChildrenWith(role);
  }

  public RegionType getDefinedRegionType() {
    if (canRegionBeDefinedByChildren())
      return getTypeOfAnnotationChildrenWithRole(getRoleForRegionDefiningChildren()).getDefinedRegionType();
    throw new ATLASAccessException("This AnnotationType [" + getName()
        + "] does not allow the Region to be defined by a Children element.");
  }

  public ContentType getDefinedContentType() {
    if (canContentBeDefinedByChildren())
      return getTypeOfAnnotationChildrenWithRole(getRoleForRegionDefiningChildren()).getDefinedContentType();
    throw new ATLASAccessException("This AnnotationType [" + getName()
        + "] does not allow the Content to be defined by a Children element.");
  }

  // FIX-ME?
  public String getRoleForChildrenWith(AnnotationChildrenType.SubType kind) {
    if (kind == AnnotationChildrenType.CONTENT_DEFINING) {
      if (canContentBeDefinedByChildren())
        return roleForContentDefiningChildren;
      throw new ATLASAccessException("This AnnotationType [" + getName()
          + "] does not allow the Content to be defined by a Children element.");
    } else {
      if (canRegionBeDefinedByChildren())
        return roleForRegionDefiningChildren;
      throw new ATLASAccessException("This AnnotationType [" + getName()
          + "] does not allow the Region to be defined by a Children element.");
    }
  }

  private String roleForRegionDefiningChildren = NOT_CHILDREN_DEFINED;
  private String roleForContentDefiningChildren = NOT_CHILDREN_DEFINED;
  private final static String NOT_CHILDREN_DEFINED = "_||_".intern();
}



