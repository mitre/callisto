/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Metadata;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.MetadataType;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;


/**
 * parent ATTRIBUTE IS NEVER INITIALIZED
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public class MetadataImpl extends MinimalATLASElementImpl implements Metadata {
  protected MetadataImpl(ATLASType type, ATLASElement parent, ImplementationDelegate delegate) {
    super(type, parent, delegate);
    elements = new HashMap(11);
  }

  public final MetadataType getMetadataType() {
    return (MetadataType) getATLASType();
  }

  public final boolean isTypeValid(ATLASType type) {
    return super.isTypeValid(type) && (type instanceof MetadataType);
  }

  public void toAIFBuffer(StringBuffer sb, String indent, String role, ATLASElement context) {
    sb.append(indent).append(AIFExportConstants.METADATA_S)
        .append(getATLASType().getName())
        .append(AIFExportConstants.EMPTY_CLOSE); // FIX-ME
  }

  public String getValueFor(String key) {
    return (String) elements.get(key);
  }

  public boolean setOrCreatePair(String key, String value) {
    if (key == null || value == null)
      return false;
    String old = (String) elements.put(key, value);
    if (old != null && old.equals(value)) {
      old = null;
      return false;
    }
    old = null;
    return true;
  }

  public Set getKeys() {
    return elements.keySet();
  }

  private Map elements;
}