/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl.bundled;

import gov.nist.atlas.spi.TypeImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.AbstractATLASType;
import gov.nist.atlas.type.OptionalChildrenDefinition;
import gov.nist.atlas.type.RequiredChildDefinition;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.atlas.util.MutableATLASElementSet;

import java.util.Iterator;


/**
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 */
public class DefaultTypeImplementationDelegate implements TypeImplementationDelegate {
  private ATLASImplementation implementation;

  protected DefaultTypeImplementationDelegate(ATLASType associatedType, ATLASImplementation implementation) {
    this(implementation);
    setAssociatedType(associatedType);
  }

  public DefaultTypeImplementationDelegate(ATLASImplementation implementation) {
    this.implementation = implementation;
  }

  public void setAssociatedType(ATLASType type) {
    this.associatedType = type;
  }

  public ATLASImplementation getATLASImplementation() {
    return implementation;
  }

  /* -- TypeImplementationDelegate implementation -- */

  public boolean isRequiredChildDefinitionValid(RequiredChildDefinition fragment) {
    if (fragment instanceof DefaultRequiredChildDefinition) {
      DefaultRequiredChildDefinition atsf = (DefaultRequiredChildDefinition) fragment;
      // check if the index already exists
      Iterator i = associatedType.getDefinedRolesForSubordinates();
      while (i.hasNext()) {
        if (((DefaultRequiredChildDefinition) i.next()).getIndex() == atsf.getIndex())
          return false;
      }
      return true;
    } else
      return false;
  }

  public boolean isOptionalChildrenDefinitionValid(OptionalChildrenDefinition fragment) {
    if (fragment instanceof DefaultOptionalChildrenDefinition) {
      DefaultOptionalChildrenDefinition atmf = (DefaultOptionalChildrenDefinition) fragment;
      // check if the index already exists
      Iterator i = associatedType.getContainedTypesInSubordinateSets();
      while (i.hasNext()) {
        if (((DefaultOptionalChildrenDefinition) i.next()).getIndex() == atmf.getIndex())
          return false;
      }
      return true;
    } else
      return false;
  }

  public RequiredChildDefinition createRequiredChildDefinition(ATLASType typeOfRequiredChild) {
    return new DefaultRequiredChildDefinition(typeOfRequiredChild, this);
  }

  public OptionalChildrenDefinition createOptionalChildrenDefinition(ATLASType typeOfOptionalChildren, boolean canAdd, boolean canRemove, boolean sortable, boolean byId) {
    return new DefaultOptionalChildrenDefinition(typeOfOptionalChildren, canAdd, canRemove, sortable, byId, this);
  }

  public MutableATLASElementSet createContainerForMultipleSubordinates(ATLASType containedType) {
    return ((AbstractATLASType) associatedType).createSubordinateSetFor(containedType); // FIX-ME
  }


  /**
   * Returns the index in ATLASElementImpl's internal array for the contained
   * ATLASElement with the given ATLASClass and role.
   * @param role
   * @return
   */
  int getIndexForRequired(String role) {
    DefaultRequiredChildDefinition atf = getATSFImpl(role);
    if (atf == null) // EH: Move error up
      throw new IllegalArgumentException("This " + associatedType
          + " cannot contain a required child with role '" + role + "'");
    return atf.getIndex();
  }

  /**
   * Returns the index in ATLASElementImpl's internal array for the
   * MutableATLASElementSet that stores ATLASElements of the given ATLASType,
   * identified by the given role in case the ATLASElementImpl (for which this
   * DefaultTypeImplementationDelegate is the type) can contains several different sets of
   * ATLASElements of the same ATLASType (e.g. Annotations and
   * their children).
   * @param type
   * @return
   */
  int getIndexForMultiple(ATLASType type) {
    DefaultOptionalChildrenDefinition atm = getATMFImpl(type);
    if (atm == null) // EH: Move error up
      throw new IllegalArgumentException("This ATLASType "
          + " does not define a set of optional children with role '"
          + type + "'");
    return atm.getIndex();
  }

  int getNextIndexForSimpleFragment() {
    return simpleCount++;
  }

  int getNextIndexForMultipleFragment() {
    return multipleCount++;
  }


  protected DefaultRequiredChildDefinition getATSFImpl(String role) {
    return (DefaultRequiredChildDefinition) associatedType.getSubordinateDefinitionFor(role);
  }

  protected DefaultOptionalChildrenDefinition getATMFImpl(ATLASType type) {
    return (DefaultOptionalChildrenDefinition) associatedType.getSubordinateSetDefinitionFor(type);
  }

  private int simpleCount = 0;
  private int multipleCount = 0;
  private ATLASType associatedType;
}