/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Id;
import gov.nist.atlas.ReusableATLASElement;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ReferentManager;

import java.util.Set;


/**
 * @version $Revision: 1.3 $
 * @author Christophe Laprun
 */
public class ReusableATLASElementImpl extends IdentifiableATLASElementImpl implements ReusableATLASElement {
  public ReusableATLASElementImpl(ATLASType type, ATLASElement parent, Id id, ImplementationDelegate delegate) {
    super(type, parent, id, delegate);
    getIdAsURL();
  }


  /*public void initWith(ATLASType type, ATLASElement parent) {
    super.initWith(type, parent);
  }

  public void initWith(ATLASType type, ATLASElement parent, Id id) {
    super.initWith(type, parent, id);
  }*/

  public Set getReferentElements() {
    return ReferentManager.getReferentsFor(this);
  }

  public boolean addReferentElement(ATLASElement element) {
    return ReferentManager.addReferentTo(this, element);
  }

  public boolean removeReferentElement(ATLASElement element) {
    return ReferentManager.removeReferentFrom(this, element);
  }

  public ATLASElement getParent() {
    return ReferentManager.getParentFor(this);
  }

  protected void setParent(ATLASElement parent) {
    super.setParent(parent);
    ReferentManager.setParentFor(this, parent);
  }

  // move to ATLASRef... Check toAIFBuffer as well
  /**
   * <p>Prints this ReusableATLASElement as an AIF reference to the specified
   * buffer. Note that this method is not meant to be called directly but
   * rather in the context of a parent element since context information
   * is passed. This allows, in particular, recursive calls in
   * AIFXMLExport.</p> <p>This method is called by AIFSerializable.toAIFBuffer
   * when the asRef parameter is <code>true</code>.</p>
   *
   * @param buffer the StringBuffer to which the AIF reference of this
   * ReusableATLASElement should be printed
   * @param indent a String containing white spaces, providing the indentation
   * to be used for this ReusableATLASElement with respect to its parent
   * @param role   the role of this ReusableATLASElement in the
   * context of its parent
   *
   * @see gov.nist.atlas.AIFSerializable#toAIFBuffer(StringBuffer,String,String,ATLASElement)
   */
  public void toAIFBufferAsRef(StringBuffer buffer, String indent, String role, ATLASElement context) {
    buffer.append(indent).append("<").append(getATLASType().getATLASClass().getName()).append("Ref xlink:href=\'");
    if (!context.getDefiningCorpus().equals(getDefiningCorpus()))
      buffer.append(getIdAsURL());
    else
      buffer.append("#").append(getId().getAsString());
    buffer.append("\' role=\'").append(role).append("\'/>\n");
  }

  public String getIdAsURL() {
    if (idAsURL == null) {
      idAsURL = getDefiningCorpus().getLocation().toExternalForm() + "#" + getId().getAsString();
    }
    return idAsURL;
  }

  private String idAsURL = null;
}
