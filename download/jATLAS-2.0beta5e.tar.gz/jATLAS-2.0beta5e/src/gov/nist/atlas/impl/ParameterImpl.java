/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.impl;

import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Parameter;
import gov.nist.atlas.Unit;
import gov.nist.atlas.event.ValueChangeEvent;
import gov.nist.atlas.event.ValueChangeListener;
import gov.nist.atlas.event.ValueChangedVetoException;
import gov.nist.atlas.event.ValueWillChangeListener;
import gov.nist.atlas.io.xml.AIFExportConstants;
import gov.nist.atlas.spi.ImplementationDelegate;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.ParameterType;

import java.util.Vector;


/**
 * @version $Revision: 1.3 $
 * @author Christophe Laprun, Sylvain Pajot, Nicolas Radde
 */
public class ParameterImpl extends MinimalATLASElementImpl implements Parameter {
  protected ParameterImpl(ATLASType type, ATLASElement parent, ImplementationDelegate delegate, String value, Unit unit) {
    super(type, parent, delegate);
    setValue(value);
    this.unit = unit;
  }

  public boolean equals(Object obj) {
    if (obj == this)
      return true;
    if (obj instanceof Parameter)
      return getValueAsObject().equals(((Parameter) obj).getValueAsObject());
    return false;
  }

  public final ParameterType getParameterType() {
    return (ParameterType) getATLASType();
  }

  public final boolean isTypeValid(ATLASType type) {
    return super.isTypeValid(type) && (type instanceof ParameterType);
  }

  public Unit getUnit() {
    return unit;
  }

  public Object getValueAsObject() {
    return value;
  }

  public String getValueAsString() {
    return value;
  }

  public boolean setValue(String value) {
    ValueChangeEvent vEvent = new ValueChangeEvent(this, this.value, value);
    try {
      fireValueWillChange(vEvent);
      this.value = value;
    } catch (ValueChangedVetoException e) {
      System.err.println("Parameter.setValue: Vetoed!\n" + e.getMessage());
      return false;
    }
    this.value = value;
    fireValueChange(vEvent);
    return true;
  }

  public void toAIFBuffer(StringBuffer sb, String indent,
                          String role, ATLASElement context) {
    if (value == null)
      return;
    sb.append(indent).append(AIFExportConstants.PARAMETER_S)
        .append(getATLASType().getName()).append(AIFExportConstants.UNIT_ATT);
    if (unit == null)
      sb.append("NULL_UNIT");
    else
      sb.append(unit.getName());
    sb.append(AIFExportConstants.ROLE_ATT).append(role)
        .append(AIFExportConstants.CLOSE_NOBR).append(value)
        .append(AIFExportConstants.PARAMETER_E);
  }

  public synchronized void removeValueChangeListener(ValueChangeListener l) {
    if (valueChangeListeners != null && valueChangeListeners.contains(l)) {
      Vector v = (Vector) valueChangeListeners.clone();
      v.removeElement(l);
      valueChangeListeners = v;
    }
  }

  public synchronized void addValueChangeListener(ValueChangeListener l) {
    Vector v = valueChangeListeners == null ? new Vector(2) : (Vector) valueChangeListeners.clone();
    if (!v.contains(l)) {
      v.addElement(l);
      valueChangeListeners = v;
    }
  }

  public synchronized void removeValueWillChangeListener(ValueWillChangeListener l) {
    if (valueWillChangeListeners != null && valueWillChangeListeners.contains(l)) {
      Vector v = (Vector) valueWillChangeListeners.clone();
      v.removeElement(l);
      valueWillChangeListeners = v;
    }
  }

  public synchronized void addValueWillChangeListener(ValueWillChangeListener l) {
    Vector v = valueWillChangeListeners == null ? new Vector(2) : (Vector) valueWillChangeListeners.clone();
    if (!v.contains(l)) {
      v.addElement(l);
      valueWillChangeListeners = v;
    }
  }

  protected void fireValueChange(ValueChangeEvent e) {
    if (valueChangeListeners != null) {
      Vector listeners = valueChangeListeners;
      int count = listeners.size();
      for (int i = 0; i < count; i++) {
        ((ValueChangeListener) listeners.elementAt(i)).valueChange(e);
      }
    }
  }

  protected void fireValueWillChange(ValueChangeEvent e) throws ValueChangedVetoException {
    if (valueWillChangeListeners != null) {
      Vector listeners = valueWillChangeListeners;
      int count = listeners.size();
      for (int i = 0; i < count; i++) {
        ((ValueWillChangeListener) listeners.elementAt(i)).valueWillChange(e);
      }
    }
  }

  private String value;
  private Unit unit;

  /*
   * listeners
   */
  private transient Vector valueChangeListeners;
  private transient Vector valueWillChangeListeners;

}


