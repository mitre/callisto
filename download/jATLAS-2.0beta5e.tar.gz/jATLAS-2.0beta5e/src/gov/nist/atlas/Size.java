/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas;


/**
 * <p>Size is an abstraction that encapsulates dimensionality information for
 * Signal classes thus allowing ATLAS to handle arbitrary Signal classes. It
 * basically provides meta-information about a vectorial space common to
 * a class of Signals.</p>
 *
 * <p>For example, a Signal representing video data could have the following Size
 * information associated to it:</p> <ul>
 * <li><code>getNumberOfDimensions</code> could return <code>3</code></li>
 * <li><code>getDimensionNames</code> could return <code>{ heigth, width, time
 * }</code></li>
 * <li><code>getRangeForDimension(heigth)</code> could return a Range object valued <code>[0, 640]</code></li>
 * <li><code>getUnitForDimension(time)</code> could return a Unit object named "millisecond"</li>
 * </ul>
 *
 * <p><strong>NOT YET SUPPORTED.</strong></p>
 *
 * @version $Revision: 1.2 $
 * @author Christophe Laprun
 *
 * @deprecated Remove and move methods to either SignalType or Signal
 */
public interface Size {
  /**
   * Returns the range of possible values associated with the
   * specified dimension.
   *
   * @param name the name of the dimension which range is to be retrieved
   *
   * @return the range associated with the specified dimension
   *
   * @see Size.Range
   *
   * @deprecated move to Signal
   */
  Range getRangeForDimension(String name);

  /**
   * A range of values...
   *
   * @deprecated Decide what to do about it, maybe move to Signal
   */
  public static interface Range {
    /**
     *  Returns the maximum value associated with this Range.
     *
     * @return the maximum value associated with this Range
     */
    double getMaximumValue();

    /**
     *  Returns the minimum value associated with this Range.
     *
     * @return the minimum value associated with this Range
     */
    double getMinimumValue();
  }
}


