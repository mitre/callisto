package gov.nist.atlas.io;


/**
 * @deprecated  was used in ATLAS versions previous than 2
 */
final public class PersistenceMethod {
  public final static PersistenceMethod XML = new PersistenceMethod();
  public final static PersistenceMethod JDBC = new PersistenceMethod();

  private PersistenceMethod() {
  }
}



