/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */


package gov.nist.atlas.io;

import gov.nist.atlas.Corpus;
import gov.nist.atlas.util.ATLASImplementation;

import java.net.URL;


/**
 * <p>ATLASImport is a placeholder for any data that is intended to be imported
 * as a Corpus.</p>
 * <p>An ATLASImport implementation is responsible for parsing an ATLAS Corpus
 * from input data found at a given URL, no matter what the persistence modality
 * (XML files, RDBMS...) and format (such as AIF or any other proprietary
 * formats) are.<p>
 * <p>NOTE: Implementations <strong>MUST</strong> provide a public no-argument
 * constuctor so that the import module can be dynamically loaded.</p>
 *
 * @author Sylvain Pajot, Chris Laprun
 * @version $Revision: 1.2 $
 *
 * @see gov.nist.atlas.io.ImportedElement
 * @see gov.nist.atlas.io.AbstractATLASImport
 */
public interface ATLASImport {
  /**
   * Loads a corpus from the associated input data this ATLASImport is the
   * placeholder for.
   *
   * @return the corpus retrieved from the input data associated with this
   * ATLASImport
   *
   * @deprecated use load(boolean) instead
   */
  Corpus load();

  /**
   * Loads the Corpus defined in the resource this ATLASImport is associated to.
   * This Corpus can be loaded shallowly (meaning minimally built to be valid
   * with respect to its ATLASType) or fully.
   *
   * @param shallowly <code>true</code> if the Corpus should be built shallowly,
   *                  <code>false</code> if the Corpus should be completely built
   *
   * @return the Corpus loaded from the input data located in the resource this
   * ATLASImport is associated to.
   */
  Corpus load(boolean shallowly);

  /**
   * Sets the source URL for this ATLASImport.
   *
   * @param source the URL from which Corpora will be imported
   *
   * @since 2.0 beta 5
   */
  void setSourceURL(URL source);

  /**
   * Sets the implementation to use for importing data.
   *
   * @param implementation the ATLASImplementation to use to import data
   *
   * @since 2.0 beta 5
   */
  void setATLASImplementation(ATLASImplementation implementation);
}



