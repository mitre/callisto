/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.io;

import gov.nist.atlas.ATLASAccessException;
import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.Anchor;
import gov.nist.atlas.Annotation;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Id;
import gov.nist.atlas.Region;
import gov.nist.atlas.io.xml.AIFConstants;
import gov.nist.atlas.ref.ATLASRef;
import gov.nist.atlas.ref.RegionRef;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASImplementation;

import java.util.Iterator;
import java.util.List;

/**
 * ImportedRegionBuilder builds a Region from a matching ImportedElement
 *
 * Note that the ImportedElement well-defining the Region to create well is a prerequisite.
 * If the ImportedElement is not eligible for creating a Region, an IllegalArgumentException is
 * raised.
 *
 * @author Sylvain Pajot
 * @see ImportedElementBuilder
 */
public class ImportedRegionBuilder extends ImportedElementBuilder {

  public ImportedRegionBuilder(ATLASImplementation implementation, ImportedElementBuilderFactory parentFactory) {
    super(implementation, parentFactory);
  }

  public Region buildRegion(ImportedElement ieRegion, Corpus definingCorpus) {

    Region region;
    String regionID = ieRegion.getAttributeValue(AIFConstants.ID),
        regionType = ieRegion.getAttributeValue(AIFConstants.TYPE);
    if (regionID == null)
      throw new IllegalArgumentException("Can't find id attribute in region element");
    if (regionType == null)
      throw new IllegalArgumentException("Can't find type attribute in region element");
    /*if (!regionType.equals(type))
      throw new IllegalArgumentException("Incompatible RegionSet/Region type");*/

    Id id = getATLASElementFactory().resolveIdFor(regionID);
    if (id == null) id = getATLASElementFactory().createNewIdFor(regionID);
    region = getATLASElementFactory().createEmptyRegion(definingCorpus.resolveTypeFor(ATLASClass.REGION, regionType), definingCorpus, id);
    if (region == null)
      throw new IllegalArgumentException("Can't create region, id=" + regionID);

    // fixed AnchorRefs
    Iterator i = ieRegion.getChildren(AIFConstants.ANCHORREF).iterator();
    ImportedElement ieTemp;
    String role;
    Anchor tempAnchor;
    ATLASType t;
    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      // FIX-ME : is addition done the right way ?
      role = ieTemp.getAttributeValue(AIFConstants.ROLE);
      if (role == null)
        throw new IllegalArgumentException("Can't find role attribute in AnchorRef element");
      t = region.getATLASType().getTypeOfSubordinateWith(role);
      tempAnchor = getBuilderFactory().getImportedAnchorBuilder().getAnchorFromAnchorRef(ieTemp, definingCorpus, t);
      if (!region.setSubordinateWithRole(tempAnchor, role))
        throw new IllegalArgumentException("Can't add anchor to region");

    }

    // fixed RegionRefs
    i = ieRegion.getChildren(AIFConstants.REGIONREF).iterator();
    Region tempRegion;
    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      role = ieTemp.getAttributeValue(AIFConstants.ROLE);
      if (role == null)
        throw new IllegalArgumentException("Can't find role attribute in RegionRef element");
      t = region.getATLASType().getTypeOfSubordinateWith(role);
      tempRegion = getRegionFromRegionRef(ieTemp, definingCorpus, t);
      if (!region.setSubordinateWithRole(tempRegion, role))
        throw new IllegalArgumentException("Can't add region to region");
    }

    // fixed AnnotationRefs
    i = ieRegion.getChildren(AIFConstants.ANNOTATIONREF).iterator();
    Annotation tempAnnotation;
    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      role = ieTemp.getAttributeValue(AIFConstants.ROLE);
      if (role == null)
        throw new IllegalArgumentException("Can't find role attribute in AnnotationRef element");
      t = region.getATLASType().getTypeOfSubordinateWith(role);
      tempAnnotation = getBuilderFactory().getImportedAnnotationBuilder().getAnnotationFromAnnotationRef(ieTemp, definingCorpus, t);
      if (!region.setSubordinateWithRole(tempAnnotation, role))
        throw new IllegalArgumentException("Can't add annotation to region");
    }

    // multiple AnchorRefs
    i = ieRegion.getChildren(AIFConstants.ANCHORREFSET).iterator();
    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      getBuilderFactory().getImportedAnchorBuilder().addAnchorsFromAnchorRefSetTo(region, ieTemp);
    }

    // multiple RegionRefs
    i = ieRegion.getChildren(AIFConstants.REGIONREFSET).iterator();
    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      addRegionsFromRegionRefSetTo(region, ieTemp);
    }

    // multiple AnnotationRefs
    i = ieRegion.getChildren(AIFConstants.ANNOTATIONREFSET).iterator();
    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      getBuilderFactory().getImportedAnnotationBuilder().addAnnotationsFromAnnotationRefSetTo(region, ieTemp);
    }

    return region;

  }


  public RegionRef getRegionFromRegionRef(ImportedElement ieRegionRef, Corpus corpus, ATLASType regionType) {
    String href = ieRegionRef.getAttributeValueWithNamespace(AIFConstants.XLINKHREF, AIFConstants.XLINK);
    if (href == null)
      throw new IllegalArgumentException("Can't find href attribute in RegionRef element");
    if (href.equals(""))
      throw new IllegalArgumentException("Found empty href attribute in RegionRef element");
    String role = ieRegionRef.getAttributeValue(AIFConstants.ROLE);
    if (role == null)
      throw new IllegalArgumentException("Can't find role attribute in RegionRef element");
    // FIX-ME : test for empty role ?
    return ATLASRef.createRegionRef(href, regionType, corpus, role);
  }


  private void addRegionsFromRegionRefSetTo(Region parentRegion, ImportedElement ieRegionRefSet) {
    Region region;
    List list = ieRegionRefSet.getChildren(AIFConstants.REGIONREF);
    if (list.size() == 0)
      throw new IllegalArgumentException("Can't find RegionRef elements in RegionRefSet element");
    Iterator i = list.iterator();
    ImportedElement ieTemp;
    String role;
    String type = ieRegionRefSet.getAttributeValue(AIFConstants.CONTAINEDTYPE);
    if (type == null)
      throw new IllegalArgumentException("Can't find containedType attribute in RegionRefSet element");
    if (type.equals(""))
      throw new IllegalArgumentException("Found empty type attribute in RegionRefSet element");
    ATLASType t = parentRegion.getDefiningCorpus().resolveTypeFor(ATLASClass.REGION, type);

    while (i.hasNext()) {
      ieTemp = (ImportedElement) i.next();
      region = getRegionFromRegionRef(ieTemp, parentRegion.getDefiningCorpus(), t);
      // Never supposed to be null
      //if (region == null) throw new IllegalArgumentException("Can't find
      // region from RegionRef");

      // Not compatible with lazy instanciation
      // >> put the knowledge of the type on the ref
      //if (! region.getATLASType().getName().equals(type)) throw new
      // IllegalArgumentException("Incompatible type for RegionRefSet/Region");

      if (!parentRegion.addRegion(region))
        throw new ATLASAccessException("Can't add region to region");

    }
  }
}
