/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.io;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.ATLASElement;
import gov.nist.atlas.Analysis;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Id;
import gov.nist.atlas.io.xml.AIFConstants;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASImplementation;

import java.util.Iterator;

/**
 * ImportedAnalysisBuilder builds an Analysis from a matching ImportedElement
 *
 * Note that the ImportedElement well-defining the Analysis to create is a prerequisite.
 * If the ImportedElement is not eligible for creating an Analysis, an IllegalArgumentException is
 * raised.
 *
 * @author Sylvain Pajot
 * @see ImportedElementBuilder
 */
public class ImportedAnalysisBuilder extends ImportedElementBuilder {

  public ImportedAnalysisBuilder(ATLASImplementation implementation, ImportedElementBuilderFactory parentFactory) {
    super(implementation, parentFactory);
  }

  public Analysis buildAnalysis(ImportedElement ieAnalysis, Corpus definingCorpus, boolean shallowly) {
    Analysis analysis;
    String analysisID = ieAnalysis.getAttributeValue(AIFConstants.ID),
        analysisType = ieAnalysis.getAttributeValue(AIFConstants.TYPE),
        analysisRole = ieAnalysis.getAttributeValue(AIFConstants.ROLE);

    Id id = getOrCreateId(analysisID);

    ATLASType analysisATLASType
      = resolveType(definingCorpus, analysisType, ATLASClass.ANALYSIS);

    analysis = getATLASElementFactory().createEmptyAnalysis(analysisATLASType, definingCorpus, id);
    definingCorpus.setAnalysisWithRole(analysis, analysisRole);

    // create optional Metadata
    ImportedElement ieTemp = ieAnalysis.getChild(AIFConstants.METADATA);
    //YOUHOU if (ieTemp != null) analysis.setMetadata(buildMetadata(ieTemp));
    if (ieTemp != null) analysis.setMetadata(getBuilderFactory().getImportedMetadataBuilder().buildMetadata(ieTemp));


    // create annotations
    if (!shallowly) {
      Iterator i = ieAnalysis.getChildren(AIFConstants.ANNOTATIONSET).iterator();
      while (i.hasNext()) {
        ieTemp = (ImportedElement) i.next();
        getBuilderFactory().getImportedAnnotationBuilder().buildAnnotationsFromAnnotationSet(ieTemp, analysis);
      }
    }

    return analysis;
  }

  public ATLASElement buildATLASElement(ImportedElement importedElement,
                                        ATLASElement parent,
                                        Object[] otherParameters) {
    ATLASElement element = null;
    String type = importedElement.getAttributeValue("type");
    return element;
  }
}
