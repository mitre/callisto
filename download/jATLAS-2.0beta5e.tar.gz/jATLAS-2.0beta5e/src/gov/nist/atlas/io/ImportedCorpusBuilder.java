/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.io;

import gov.nist.atlas.Corpus;
import gov.nist.atlas.Id;
import gov.nist.atlas.SignalGroup;
import gov.nist.atlas.SimpleSignal;
import gov.nist.atlas.io.xml.AIFConstants;
import gov.nist.atlas.type.CorpusType;
import gov.nist.atlas.util.ATLASImplementation;
import gov.nist.maia.MAIALoader;
import gov.nist.maia.MAIAScheme;

import java.net.URL;
import java.util.Iterator;

/**
 * ImportedCorpusBuilder builds a Corpus from a matching ImportedElement
 *
 * Note that the ImportedElement well-defining the Corpus to create is a prerequisite.
 * If the ImportedElement is not eligible for creating a Corpus, an IllegalArgumentException is
 * raised.
 *
 * @author Sylvain Pajot
 * @see ImportedElementBuilder
 */
public class ImportedCorpusBuilder extends ImportedElementBuilder {

  public ImportedCorpusBuilder(ATLASImplementation implementation, ImportedElementBuilderFactory parentFactory) {
    super(implementation, parentFactory);
    impl = implementation;
  }

  public Corpus buildCorpus(ImportedElement ieCorpus, URL url, boolean shallowly) {

    // FIX-ME : better handling of the following...
    //if (url == null) throw new IllegalArgumentException("No URL has been assigned to the ImportedCorpusBuilder");

    String corpusID,
        corpusType;

    MAIALoader loader = new MAIALoader(impl); // implementation from AbstractATLASImport
    String schemeLocation = ieCorpus.getAttributeValue(AIFConstants.SCHEMELOC);
    if (schemeLocation == null)
      throw new IllegalArgumentException("invalid scheme location");
    URL urlMaia = null;
    try {
      urlMaia = new URL(schemeLocation);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    MAIAScheme scheme = loader.loadTypeDefinitionsFrom(urlMaia);

    corpusID = ieCorpus.getAttributeValue(AIFConstants.ID);
    if (corpusID == null)
      throw new IllegalArgumentException("Can't find id attribute in corpus element");
    if (corpusID.equals(""))
      throw new IllegalArgumentException("Found empty id attribute in corpus element");
    corpusType = ieCorpus.getAttributeValue(AIFConstants.TYPE);
    if (corpusType == null)
      throw new IllegalArgumentException("Can't find type attribute in corpus element");
    if (corpusType.equals(""))
      throw new IllegalArgumentException("Found empty type attribute in corpus element");

    Id tempId = getATLASElementFactory().resolveIdFor(corpusID);
    if (tempId == null) tempId = getATLASElementFactory().createNewIdFor(corpusID);

    CorpusType type = scheme.getCorpusType(corpusType);
    Corpus corpus = getATLASElementFactory().createEmptyCorpus(type, tempId, url);
    if (corpus == null)
      throw new IllegalArgumentException("Can't create corpus");

    // create mandatory metadata
    ImportedElement temp = ieCorpus.getChild(AIFConstants.METADATA);
    if (temp == null)
      throw new IllegalArgumentException("Can't find Metadata element in Corpus");
    //YOUHOU corpus.setMetadata(buildMetadata(temp));
    corpus.setMetadata(getBuilderFactory().getImportedMetadataBuilder().buildMetadata(temp));

    // create simple signals
    Iterator i = ieCorpus.getChildren(AIFConstants.SIMPLESIGNAL).iterator();
    SimpleSignal simpleSignal;
    while (i.hasNext()) {
      temp = (ImportedElement) i.next();
      //YOUHOU simpleSignal = buildSimpleSignal(temp, corpus);
      simpleSignal = getBuilderFactory().getImportedSignalBuilder().buildSimpleSignal(temp, corpus);
    }

    // create signal groups
    i = ieCorpus.getChildren(AIFConstants.SIGNALGROUP).iterator();
    SignalGroup signalGroup;
    while (i.hasNext()) {
      temp = (ImportedElement) i.next();
      //YOUHOU signalGroup = buildSignalGroup(temp, corpus);
      signalGroup = getBuilderFactory().getImportedSignalBuilder().buildSignalGroup(temp, corpus);
    }

    if (!shallowly) {
      // create anchors
      i = ieCorpus.getChildren(AIFConstants.ANCHORSET).iterator();
      while (i.hasNext()) {
        temp = (ImportedElement) i.next();
        buildAnchorsFromAnchorSet(temp, corpus);
      }

      // create regions
      i = ieCorpus.getChildren(AIFConstants.REGIONSET).iterator();
      while (i.hasNext()) {
        temp = (ImportedElement) i.next();
        buildRegionsFromRegionSet(temp, corpus);
      }
    }

    // create analyses
    i = ieCorpus.getChildren(AIFConstants.ANALYSIS).iterator();
    while (i.hasNext()) {
      temp = (ImportedElement) i.next();
      getBuilderFactory().getImportedAnalysisBuilder().buildAnalysis(temp, corpus, shallowly);
    }

    corpus.setShallow(shallowly);
    return corpus;
  }

  private void buildAnchorsFromAnchorSet(ImportedElement ieAnchorSet,
                                         Corpus definingCorpus) {
    Iterator i = ieAnchorSet.getChildren(AIFConstants.ANCHOR).iterator();
    ImportedElement eAnchor;
    String type = ieAnchorSet.getAttributeValue(AIFConstants.CONTAINEDTYPE);
    if (type == null)
      throw new IllegalArgumentException("Can't find containedType attribute in AnchorSet element");
    if (type.equals(""))
      throw new IllegalArgumentException("Found empty string for containedType in AnchorSet element");

    while (i.hasNext()) {
      eAnchor = (ImportedElement) i.next();
      //YOUHOU buildAnchor(eAnchor, definingCorpus, type);
      getBuilderFactory().getImportedAnchorBuilder().buildAnchor(eAnchor, definingCorpus);
    }
  }


  private void buildRegionsFromRegionSet(ImportedElement ieRegionSet, Corpus definingCorpus) {
    Iterator i = ieRegionSet.getChildren(AIFConstants.REGION).iterator();
    ImportedElement eRegion;
    String type = ieRegionSet.getAttributeValue(AIFConstants.CONTAINEDTYPE);
    if (type == null)
      throw new IllegalArgumentException("Can't find containedType attribute in RegionSet element");
    if (type.equals(""))
      throw new IllegalArgumentException("Found empty string for containedType in RegionSet element");
    while (i.hasNext()) {
      eRegion = (ImportedElement) i.next();
      //YOUHOU buildRegion(eRegion, definingCorpus, type);
      getBuilderFactory().getImportedRegionBuilder().buildRegion(eRegion, definingCorpus);
    }
  }


//  public void setUrl(URL url) {
//    this.url = url;
//  }


  private ATLASImplementation impl;
//  private URL url = null;
}
