/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.io.xml;

import gov.nist.atlas.io.ImportedElement;
import org.dom4j.Element;
import org.dom4j.Node;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * XMLImportedElement is an implementation of the ImportedElement interface
 * targeted at handling XML elements.
 *
 * @version $Revision: 1.2 $
 * @author Sylvain Pajot, Chris Laprun
 *
 * @see gov.nist.atlas.io.ImportedElement
 * @see gov.nist.atlas.io.xml.XMLImportedElementLoader
 */
public class XMLImportedElement implements ImportedElement {

  /**
   * Creates an XMLImportedElement from an Element (of the Dom4J framework)
   *
   * @param element The Element from which to create the XMLImportedElement
   */
  public XMLImportedElement(Element element) {
    this.element = element;
  }

  /**
   * Gets the name of this XMLImportedElement
   *
   * @return Tthe name of this XMLImportedElement
   */
  public String getName() {
    return element.getName();
  }

  /**
   * Gets the value of a given attribute in this XMLImportedElement
   *
   * @param name The name of the attribute
   * @return The value (as String) of the specified attribute in this
   * XMLImportedElement
   */
  public String getAttributeValue(String name) {
    String value = element.attributeValue(name);
    // removed for MITRE use KLUDGE
    //if (value == null || value.equals(""))
    //throw new IllegalArgumentException("No attribute '" + name + "' was found for element " + element.getName());
    return value;
  }

  /**
   * Gets the value of a given attribute and a given namespace in this
   * XMLImportedElement <P>NOT YET IMPLEMENTED. It behaves like the
   * <CODE>getAttributeValue</CODE> method.
   *
   * @param name The name of the attribute
   * @param nsPrefix The prefix of the namespace
   * @return The value of the specified attribute and the specified namespace
   * in this XMLImportedElement
   */
  public String getAttributeValueWithNamespace(String name, String nsPrefix) {
    //return element.attributeValue(nsPrefix+":"+name);
    return getAttributeValue(name);
  }

  /**
   * Gets the trimmed content of this XMLImportedElement
   *
   * @return The trimmed content of this XMLImportedElement
   */
  public String getTextTrim() {
    // Check if getTextTrim provides what is expected
    return element.getTextTrim();
  }


  /**
   * Gets a List of this XMLImportedElement's children matching a given name
   *
   * @param name The name of the children to get
   * @return A List of this XMLImportedElement's children matching the
   * specified name
   */
  public List getChildren(String name) {
    if (name == null || name.equals(""))
      return Collections.EMPTY_LIST;

    int size = element.nodeCount();
    List children = new ArrayList(size);

    for (int i = 0; i < size; i++) {
      Node node = element.node(i);
      if (node instanceof Element && name.equals(node.getName()))
        children.add(new XMLImportedElement((Element) node));
    }
    return children;
  }

  /**
   * Gets a List of all this XMLImportedElement's children
   *
   * @return A List of all this XMLImportedElement's children
   */
  public List getAllChildren() {
    int size = element.nodeCount();
    List children = new ArrayList(size);

    for (int i = 0; i < size; i++) {
      Node node = element.node(i);
      if (node instanceof Element)
        children.add(new XMLImportedElement((Element) node));
    }
    return children;
  }

  /**
   * Gets the first child of this XMLImportedElement which
   * matches a given name
   *
   * @param name The name of the first child to get
   * @return The first child of this XMLImportedElement which matches the
   * specified name
   */
  public ImportedElement getChild(String name) {
    Element child = element.element(name);
    if (child != null)
      return new XMLImportedElement(child);
    return null;
  }

  /**
   * Returns a String representation of this XMLImportedElement
   *
   * @return The String representation of this XMLImportedElement
   */
  public String toString() {
    return DESCRIPTION + element.toString();
  }

  /**
   * Sets The namespace to which this XMLImportedElement refers.
   *
   * @param prefix The namespace's prefix
   * @param value The namespace's value
   */
  static void setNamespace(String prefix, String value) {
    XMLImportedElement.nsPrefix = prefix;
    XMLImportedElement.nsValue = value;
  }


  private final Element element;
  private static String nsPrefix;
  private static String nsValue;

  private static final String DESCRIPTION = "XMLImportedElement: ";

}

