/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.io;

import java.util.List;


/**
 * ImportedElements represent in a generic hierarchical way information that has been
 * extracted from persistent data. More formally, an ImportedElement is an
 * element from such a hierarchy.
 * <BR>The idea behind such an ImportedElement tree (which mapping to a DOM tree is
 * very close) is to perform some logic to turn it into a Corpus. Thus, it is an
 * ATLAS common data structure used to build a corpus from any kind of data
 * (provided that the semantics of that data are mappable to the ATLAS concepts).
 *
 * <P>As it is only designed for browsing purposes, an ImportedElement is not
 * expected to perform the logic mentionned above. Rather, it is dedicated
 * to know about the storage means nature (to be able to navigate between the
 * relations of a DBMS, for example).
 * <BR>Is also has - similarly to XML elements - attributes, a textual content
 * and children, and the methods it defines simply allow to get information
 * about itself (that is, its attributes and textual content) and to retrieve
 * its children ImportedElements.
 *
 * <P>Note that it is only intended to be used by ATLASImport implementations,
 * in which the logic is performed.
 *
 * @version $Revision: 1.2 $
 * @author Sylvain Pajot, Chris Laprun
 * @see ATLASImport
 */
public interface ImportedElement {
  /**
   * Gets the name of the element.
   *
   * @return The name of the element
   * @version 1.0
   */
  String getName();

  /**
   * Gets the value of the element's attribute for the given name
   *
   * @version 1.0
   * @param name the name of the attribute
   * @return the value of the given name attribute
   */
  String getAttributeValue(String name);

  /**
   * Gets the value of the element's attribute for the given name with the
   * specified namespace
   *
   * @version 1.0
   * @param name the name of the attribute
   * @param namespace the namespace associated to the attribute
   * @return the value of the element's attribute for the given name with the
   * specified namespace
   */
  String getAttributeValueWithNamespace(String name, String namespace);

  /**
   * Gets the trimmed value of the textual content
   *
   * @version 1.0
   * @return the trimmed value of the textual content
   */
  String getTextTrim();

  /**
   * Gets the children elements with the given name
   *
   * @version 1.0
   * @param name the name of the elements to retrieve
   * @return the children elements matching the given name, wrapped in a List
   */
  List getChildren(String name);

  /**
   * Gets all the children elements of this element
   *
   * @return all the children elements of this element, wrapped in a List
   * @version 1.0
   */
  List getAllChildren();

  /**
   * Gets the first occurence of the child element with the given name
   *
   * @version 1.0
   * @param name the name of the elements to retrieve
   * @return the child element matching the given name
   */
  ImportedElement getChild(String name);
}

