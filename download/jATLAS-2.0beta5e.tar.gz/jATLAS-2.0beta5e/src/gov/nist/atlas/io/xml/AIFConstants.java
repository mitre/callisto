/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.atlas.io.xml;


/**
 * This interface wraps the reserved keywords for an AIF file,
 * according to the DTD.
 *
 * @author Chris Laprun, Sylvain Pajot
 * @version $Revision: 1.2 $
 */
public interface AIFConstants {
  String CORPUS = "Corpus";
  String CONTENT = "Content";
  String FEATURE = "Feature";
  String CHILDREN = "Children";
  String METADATA = "Metadata";
  String SIMPLESIGNAL = "SimpleSignal";
  String SIGNALGROUP = "SignalGroup";
  String SIGNAL = "Signal";
  String ANALYSIS = "Analysis";
  String ANNOTATIONSET = "AnnotationSet";
  String ANNOTATION = "Annotation";
  String ANCHORSET = "AnchorSet";
  String ANCHOR = "Anchor";
  String REGIONSET = "RegionSet";
  String REGION = "Region";
  String PARAMETER = "Parameter";
  String SIGNALREF = "SignalRef";
  String ANCHORREF = "AnchorRef";
  String REGIONREF = "RegionRef";
  String ANNOTATIONREF = "AnnotationRef";
  String ANCHORREFSET = "AnchorRefSet";
  String REGIONREFSET = "RegionRefSet";
  String ANNOTATIONREFSET = "AnnotationRefSet";
  String REGIONDEFINEDBYCHILDREN = "RegionDefinedByChildren";
  String CONTENTDEFINEDBYCHILDREN = "ContentDefinedByChildren";

  String AIFVERSION = "AIFVersion";
  String SCHEMELOC = "schemeLocation";
  String ID = "id";
  String TYPE = "type";
  String MIMECLASS = "mimeClass";
  String MIMETYPE = "mimeType";
  String ENCODING = "encoding";
  String TRACK = "track";
  String XLINKHREF = "href";
  String XLINKTYPE = "type";
  String ROLE = "role";
  String UNIT = "unit";
  String CONTAINEDTYPE = "containedType";
  String WITHCONTAINEDTYPE = "withContainedType";
  String WITHROLE = "withRole";

  String XLINK = "xlink";
}



