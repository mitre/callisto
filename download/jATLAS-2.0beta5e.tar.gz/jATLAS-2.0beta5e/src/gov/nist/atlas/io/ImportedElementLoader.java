/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.io;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * An ImportedElementLoader is in charge to extract corpus-to-be data from
 * a given ressource and build the corresponding ImportedElement hierarchy.
 * For now, ImportedElementLoader is only intended to return the ImportedElement
 * corresponding to the Corpus itself. (Reusable) sub-element retrieval is not yet
 * supported but should be in a next release.
 *
 * @see gov.nist.atlas.io.ImportedElement
 */
public abstract class ImportedElementLoader {

  protected ImportedElementLoader(URL url) {
    this.url = url;
  }

  protected ImportedElementLoader(File file) {
    try {
      this.url = file.toURL();
    } catch (MalformedURLException mue) {
      mue.printStackTrace();
      System.exit(-1); // FIX-ME : better error handling
    }
  }

  /**
   * Gets the root ImportedElement for the Corpus defined by the resource this
   * ImportedElementLoader is associated to
   *
   * @return the root ImportedElement of the hierarchy which defines the corpus
   */
  public abstract ImportedElement getImportedCorpus();

  /**
   * Gets the URL locating the resource from which this ImportedElement imports
   * a corpus
   *
   * @return the URL locating the resource
   */
  public URL getURL() {
    return url;
  }

  /** the URL locating the resource from which the corpus is imported */
  private URL url;

}
