/*
 * ATLAS
 * Architecture and Tools for Linguistic Analysis Systems
 * Author: Chris Laprun, Sylvain Pajot
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMPLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */
package gov.nist.atlas.io;

import gov.nist.atlas.ATLASClass;
import gov.nist.atlas.Corpus;
import gov.nist.atlas.Id;
import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.util.ATLASElementFactory;
import gov.nist.atlas.util.ATLASImplementation;

/**
 * ImportedElementBuilder is the abstract class for builder classes
 * that create ATLASElements from ImportedElements.
 * It only provides access to the ATLASElementFactories needed to achieve the
 * building process and to the other ImportedElementBuilder (via the
 * ImportedElementBuilder), whereas the method which builds the ATLASElements
 * had to be moved at its own subclasses' level, because of the different
 * requirements for the parameters to be passed for a given ImportedElementBuilder.
 *
 * Despite the signature of this specific method has not been introduced at this
 * level yet, raising an exception from such a method must be assumed, in case the
 * ImportedElement that is supposed to well-define the ATLASElement to build is not
 * eligible for creating it (ex: missing attributes, etc...).
 *
 *
 * <STRONG>This class will be renamed, due to misleading naming issues</STRONG>
 *
 * @author Sylvain Pajot
 * @see ImportedElementBuilderFactory
 */
public abstract class ImportedElementBuilder {

  /**
   * Creates an ImportedElementBuilder that will use the ATLASFactory associated to the given
   * ATLASImplementation to build the actual ATLASElements, and the given
   * ImportedElementBuilderFactory to get access to the other useful ImportedElementBuilder
   * @param implementation the ATLASImplementation which defines the ATLASElementFactory to use
   * @param parentFactory the ImportedElementBuilderFactory to get the needed ImportedElementBuilder
   *        from
   */
  ImportedElementBuilder(ATLASImplementation implementation, ImportedElementBuilderFactory parentFactory) {
    aeFactory = ATLASElementFactory.getFactoryFor(implementation);
    this.builderFactory = parentFactory;
  }

  /**
   * Gets the ATLASElementFactory used to instanciate ATLASElement
   * @return the ATLASElementFactory used by this ImportedElementBuilder
   */
  public final ATLASElementFactory getATLASElementFactory() {
    return aeFactory;
  }

  /**
   * Gets the ImportedElementBuilderFactory which is necessary to get any
   * builder.
   *
   * @see #builderFactory
   * @return the ImportedElementBuilderFactory used by this ImportedElementBuilder
   */
  public ImportedElementBuilderFactory getBuilderFactory() {
    return builderFactory;
  }

  protected ATLASType resolveType(Corpus definingCorpus, String typeName,
                                  ATLASClass aClass) {
    ATLASType type = definingCorpus.resolveTypeFor(aClass, typeName);
    if (type == null)
      throw new IllegalArgumentException("Can't find ATLASType for "
                                         + aClass.getName() + " type '"
                                         + typeName + "'");
    return type;
  }
  
  protected Id getOrCreateId(String idAsString) {
    Id id = getATLASElementFactory().resolveIdFor(idAsString);
    if (id == null)
      id = getATLASElementFactory().createNewIdFor(idAsString);
    return id;
  }
  
  /** the ATLASElementFactory used to instanciate ATLASElement */
  private ATLASElementFactory aeFactory;

  /** the referenced ImportedElementBuilderFactory providing access to any
   * specific builder to be able to create ATLASElements from any
   * ImportedElements.
   * For instance, Features are built within ImportedAnnotationBuilders. An
   * ImportedFeatureBuilder can be retrieved via this parentFactory.
   */
  private ImportedElementBuilderFactory builderFactory;

}
