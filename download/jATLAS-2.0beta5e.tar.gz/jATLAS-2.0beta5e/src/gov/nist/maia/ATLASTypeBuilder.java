/*
 * MAIA
 * Meta-Annotation Infrastructure for ATLAS
 * Author: Chris Laprun
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.maia;

import gov.nist.atlas.type.ATLASType;
import gov.nist.atlas.type.ATLASTypeFactory;
import gov.nist.atlas.util.ATLASImplementation;
import org.dom4j.Element;

import java.util.Iterator;

class ATLASTypeBuilder {
  ATLASTypeBuilder(ATLASImplementation implementation, ATLASTypeBuilderFactory builderFactory, MAIAScheme scheme) {
    factory = ATLASTypeFactory.getFactoryFor(implementation);
    this.builderFactory = builderFactory;
    this.scheme = scheme;
  }

  ATLASType build(Element element) {
    return null;
  }

  protected String getNameOrRef(Element element) {
    String nor = element.attributeValue(MAIALoader.NAME);
    return (nor != null) ? nor : element.attributeValue(MAIALoader.REF);
  }

  protected void addFragments(Iterator subTypes, ATLASTypeBuilder builder, boolean accessByIdRequired, ATLASType parentType) {
    Element e2;
    String role;
    String multiple;
    while (subTypes.hasNext()) {
      e2 = (Element) subTypes.next();
      role = getRole(e2);
      multiple = e2.attributeValue(MAIALoader.MULTIPLE);
      ATLASType type = builder.build(e2);
      if (multiple == null)
        factory.addSimpleFragmentTo(type, role, parentType);
      else
        factory.addMultipleFragmentTo(type, role, true, true, true, accessByIdRequired, parentType);
    }
  }

  protected final void buildMultipleFor(Iterator subTypes, ATLASTypeBuilder builder, ATLASType parentType) {
    while (subTypes.hasNext()) {
      Element element = (Element) subTypes.next();
      factory.addMultipleFragmentTo(builder.build(element), getRole(element), true, true, true, false, parentType); // FIX-ME: remove role
    }
  }

  protected final void buildSimpleFor(Iterator subTypes, ATLASTypeBuilder builder, ATLASType parentType) {
    while (subTypes.hasNext())
      buildSimpleFor((Element) subTypes.next(), builder, parentType);
  }

  protected ATLASType buildSimpleFor(Element e, ATLASTypeBuilder builder, ATLASType parentType) {
    if (e != null) {
      ATLASType type = builder.build(e);
      factory.addSimpleFragmentTo(type, getRole(e), parentType);
      return type;
    }
    return null;
  }

  protected String getRole(Element e) {
    String role;
    role = e.attributeValue(MAIALoader.ROLE);
    if (role == null)
      role = createRoleFrom(e); // if no role has been assigned, create one
    return role;
  }

  protected void resetScheme(MAIAScheme scheme) {
    this.scheme = scheme;
  }

  protected final String createRoleFrom(Element element) {
    String role = getNameOrRef(element);
    if (role == null)
      role = element.attributeValue("containedType");
    return role; // FIX-ME: should probably perform more complex checks
  }

  protected ATLASTypeFactory factory;
  protected ATLASTypeBuilderFactory builderFactory;
  protected MAIAScheme scheme;
}
