/*
 * MAIA
 * Meta-Annotation Infrastructure for ATLAS
 * Author: Chris Laprun
 *
 * This software was developed at the National Institute of Standards and Technology by
 * employees of the Federal Government in the course of their official duties.  Pursuant to
 * Title 17 Section 105 of the United States Code this software is not subject to copyright
 * protection within the United States and is in the public domain. jATLAS is
 * an experimental system.  NIST assumes no responsibility whatsoever for its use by any party.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS."  With regard to this software, NIST MAKES NO EXPRESS
 * OR IMLIED WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING MERCHANTABILITY,
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 */

package gov.nist.maia;

import gov.nist.atlas.util.ATLASImplementation;

class DefaultATLASTypeBuilderFactory extends ATLASTypeBuilderFactory {
  DefaultATLASTypeBuilderFactory(ATLASImplementation implementation) {
    this.implementation = implementation;
  }

  AnalysisTypeBuilder getAnalysisTypeBuilder(MAIAScheme scheme) {
    if (analysisTypeBuilder == null)
      analysisTypeBuilder = new AnalysisTypeBuilder(implementation, this, scheme);
    else
      analysisTypeBuilder.resetScheme(scheme);
    return analysisTypeBuilder;
  }

  AnchorTypeBuilder getAnchorTypeBuilder(MAIAScheme scheme) {
    if (anchorTypeBuilder == null)
      anchorTypeBuilder = new AnchorTypeBuilder(implementation, this, scheme);
    else
      anchorTypeBuilder.resetScheme(scheme);
    return anchorTypeBuilder;
  }

  AnnotationTypeBuilder getAnnotationTypeBuilder(MAIAScheme scheme) {
    if (annotationTypeBuilder == null)
      annotationTypeBuilder = new AnnotationTypeBuilder(implementation, this, scheme);
    else
      annotationTypeBuilder.resetScheme(scheme);
    return annotationTypeBuilder;
  }

  ChildrenTypeBuilder getChildrenTypeBuilder(MAIAScheme scheme) {
    if (childrenTypeBuilder == null)
      childrenTypeBuilder = new ChildrenTypeBuilder(implementation, this, scheme);
    else
      childrenTypeBuilder.resetScheme(scheme);
    return childrenTypeBuilder;
  }

  ContentTypeBuilder getContentTypeBuilder(MAIAScheme scheme) {
    if (contentTypeBuilder == null)
      contentTypeBuilder = new ContentTypeBuilder(implementation, this, scheme);
    else
      contentTypeBuilder.resetScheme(scheme);
    return contentTypeBuilder;
  }

  CorpusTypeBuilder getCorpusTypeBuilder(MAIAScheme scheme) {
    if (corpusTypeBuilder == null)
      corpusTypeBuilder = new CorpusTypeBuilder(implementation, this, scheme);
    else
      corpusTypeBuilder.resetScheme(scheme);
    return corpusTypeBuilder;
  }

  FeatureTypeBuilder getFeatureTypeBuilder(MAIAScheme scheme) {
    if (featureTypeBuilder == null)
      featureTypeBuilder = new FeatureTypeBuilder(implementation, this, scheme);
    else
      featureTypeBuilder.resetScheme(scheme);
    return featureTypeBuilder;
  }

  ParameterTypeBuilder getParameterTypeBuilder(MAIAScheme scheme) {
    if (parameterTypeBuilder == null)
      parameterTypeBuilder = new ParameterTypeBuilder(implementation, this, scheme);
    else
      parameterTypeBuilder.resetScheme(scheme);
    return parameterTypeBuilder;
  }

  RegionTypeBuilder getRegionTypeBuilder(MAIAScheme scheme) {
    if (regionTypeBuilder == null)
      regionTypeBuilder = new RegionTypeBuilder(implementation, this, scheme);
    else
      regionTypeBuilder.resetScheme(scheme);
    return regionTypeBuilder;
  }

  SignalTypeBuilder getSignalTypeBuilder(MAIAScheme scheme) {
    if (signalTypeBuilder == null)
      signalTypeBuilder = new SignalTypeBuilder(implementation, this, scheme);
    else
      signalTypeBuilder.resetScheme(scheme);
    return signalTypeBuilder;
  }

  SignalGroupTypeBuilder getSignalGroupTypeBuilder(MAIAScheme scheme) {
    if (signalGroupTypeBuilder == null)
      signalGroupTypeBuilder = new SignalGroupTypeBuilder(implementation, this, scheme);
    else
      signalGroupTypeBuilder.resetScheme(scheme);
    return signalGroupTypeBuilder;
  }

  private AnalysisTypeBuilder analysisTypeBuilder;
  private AnchorTypeBuilder anchorTypeBuilder;
  private AnnotationTypeBuilder annotationTypeBuilder;
  private ChildrenTypeBuilder childrenTypeBuilder;
  private ContentTypeBuilder contentTypeBuilder;
  private FeatureTypeBuilder featureTypeBuilder;
  private ParameterTypeBuilder parameterTypeBuilder;
  private RegionTypeBuilder regionTypeBuilder;
  private SignalTypeBuilder signalTypeBuilder;
  private SignalGroupTypeBuilder signalGroupTypeBuilder;
  private CorpusTypeBuilder corpusTypeBuilder;
  private final ATLASImplementation implementation;
}
